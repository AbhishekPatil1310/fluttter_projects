#!/usr/bin/env python3
"""Command-aware UDP telemetry simulator for the Flutter application."""

from __future__ import annotations

import argparse
import json
import math
import select
import socket
import time
from dataclasses import dataclass
from datetime import datetime, timezone


METERS_PER_DEGREE_LAT = 111_320.0
CRUISE_SPEED = 40.2


@dataclass
class Telemetry:
    battery: int = 76
    satellites: int = 14
    connection: int = 90
    speed: float = 0.0
    heading: int = 84
    armed: bool = False
    latitude: float = 18.01915726783933
    longitude: float = 77.00772518934573

    def advance(self, seconds: float) -> None:
        if not self.armed:
            return

        meters = CRUISE_SPEED * seconds
        radians = math.radians(self.heading)
        self.latitude += meters * math.cos(radians) / METERS_PER_DEGREE_LAT
        self.longitude += meters * math.sin(radians) / (
            METERS_PER_DEGREE_LAT * math.cos(math.radians(self.latitude))
        )

    def tick(self, elapsed_seconds: float) -> None:
        now = datetime.now(timezone.utc)
        self.battery = self.battery - 1 if self.battery > 15 else 76
        self.satellites = 12 + (now.second % 4)
        self.connection = 82 + (now.second % 16)
        self.speed = CRUISE_SPEED if self.armed else 0.0
        self.advance(elapsed_seconds)

    def to_packet(self) -> dict[str, object]:
        return {
            "battery": self.battery,
            "satellites": self.satellites,
            "connection": self.connection,
            "speed": self.speed,
            "heading": self.heading,
            "armed": self.armed,
            "position": {
                "latitude": self.latitude,
                "longitude": self.longitude,
            },
            "timestamp": datetime.now(timezone.utc)
            .isoformat()
            .replace("+00:00", "Z"),
        }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Send simulated UGV telemetry and receive vehicle commands."
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Flutter host/IP. Default: 127.0.0.1",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=5001,
        help="Flutter telemetry port. Default: 5001",
    )
    parser.add_argument(
        "--listen-host",
        default="127.0.0.1",
        help="Local command listener host. Default: 127.0.0.1",
    )
    parser.add_argument(
        "--listen-port",
        type=int,
        default=5002,
        help="Local command listener port. Default: 5002",
    )
    parser.add_argument(
        "--interval",
        type=float,
        default=2.0,
        help="Seconds between telemetry packets. Default: 2",
    )
    parser.add_argument(
        "--armed",
        action="store_true",
        help="Start the simulated vehicle armed.",
    )
    parser.add_argument(
        "--heading",
        type=int,
        default=84,
        help="Initial heading in degrees. Default: 84",
    )
    return parser.parse_args()


def handle_commands(command_socket: socket.socket, telemetry: Telemetry) -> None:
    while True:
        readable, _, _ = select.select([command_socket], [], [], 0)
        if not readable:
            return

        payload, sender = command_socket.recvfrom(4096)
        try:
            command = json.loads(payload.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            print(f"RX invalid command from {sender}: {error}")
            continue

        if (
            not isinstance(command, dict)
            or command.get("type") != "vehicle_command"
            or command.get("command") != "set_armed"
            or not isinstance(command.get("armed"), bool)
        ):
            print(f"RX ignored unsupported command from {sender}: {command}")
            continue

        telemetry.armed = command["armed"]
        print(f"RX set_armed={telemetry.armed} from {sender[0]}:{sender[1]}")


def main() -> None:
    args = parse_args()
    telemetry = Telemetry(armed=args.armed, heading=args.heading % 360)
    destination = (args.host, args.port)

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as command_socket:
        command_socket.bind((args.listen_host, args.listen_port))
        command_socket.setblocking(False)

        print("NOMAD Telemetry UDP Simulator")
        print(f"Telemetry target: udp://{args.host}:{args.port}")
        print(
            f"Command listener: udp://{args.listen_host}:{args.listen_port}"
        )
        print(f"Interval        : {args.interval:.2f}s")
        print(f"Armed           : {telemetry.armed}")
        print("Press Ctrl+C to stop.\n")

        previous = time.monotonic()
        try:
            while True:
                started = time.monotonic()
                elapsed = started - previous
                previous = started

                handle_commands(command_socket, telemetry)
                telemetry.tick(elapsed)
                payload = json.dumps(
                    telemetry.to_packet(), separators=(",", ":")
                ).encode("utf-8")

                command_socket.sendto(payload, destination)
                print(
                    f"TX {len(payload):3d} bytes | "
                    f"battery={telemetry.battery:3d}% | "
                    f"sat={telemetry.satellites:2d} | "
                    f"conn={telemetry.connection:3d}% | "
                    f"speed={telemetry.speed:4.1f} m/s | "
                    f"heading={telemetry.heading:3d}° | "
                    f"armed={telemetry.armed} | "
                    f"pos=({telemetry.latitude:.6f}, "
                    f"{telemetry.longitude:.6f})"
                )

                remaining = max(
                    0.0, args.interval - (time.monotonic() - started)
                )
                time.sleep(remaining)
        except KeyboardInterrupt:
            print("\nTelemetry simulator stopped.")


if __name__ == "__main__":
    main()
