import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../state/alert_state.dart';
import '../view_models/alerts_view_model.dart';

final alertsViewModelProvider =
    NotifierProvider<AlertsViewModel, AlertsState>(AlertsViewModel.new);
