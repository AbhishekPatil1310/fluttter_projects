import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../di/data_providers.dart';
import '../../../domain/entities/alert.dart';
import '../../../domain/repositories/alert_repository.dart';
import '../state/alert_state.dart';

class AlertsViewModel extends Notifier<AlertsState> {
  late final AlertRepository _repository;
  StreamSubscription<List<Alert>>? _historySubscription;

  @override
  AlertsState build() {
    _repository = ref.read(alertRepositoryProvider);
    _historySubscription?.cancel();
    _historySubscription = _repository.historyStream.listen((history) {
      if (ref.mounted) {
        state = state.copyWith(history: history);
      }
    });
    ref.onDispose(() => _historySubscription?.cancel());
    return AlertsState(history: _repository.history);
  }

  void triggerLowBattery() =>
      _trigger(AlertLevel.warning, 'Battery below 50%');

  void triggerGpsLost() => _trigger(AlertLevel.critical, 'GPS signal lost');

  void triggerGeofenceBreach() =>
      _trigger(AlertLevel.emergency, 'Geofence breach detected');

  void acknowledge(String id) => _repository.acknowledge(id);

  void clearPendingCriticalAlert() {
    state = state.copyWith(clearPendingCriticalAlert: true);
  }

  void clearNotice() {
    state = state.copyWith(clearNotice: true);
  }

  void _trigger(AlertLevel level, String message) {
    final alert = _repository.emit(message, level);
    state = alert.requiresAcknowledgement
        ? state.copyWith(pendingCriticalAlert: alert)
        : state.copyWith(notice: message);
  }
}
