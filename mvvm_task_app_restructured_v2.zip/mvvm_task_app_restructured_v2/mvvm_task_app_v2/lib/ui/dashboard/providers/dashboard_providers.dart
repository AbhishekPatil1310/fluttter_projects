import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../state/dashboard_state.dart';
import '../view_models/dashboard_view_model.dart';

final dashboardViewModelProvider =
    NotifierProvider<DashboardViewModel, DashboardState>(
  DashboardViewModel.new,
);
