import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../di/data_providers.dart';
import '../../../domain/entities/telemetry.dart';
import '../../../domain/repositories/vehicle_control_repository.dart';
import '../../settings/providers/settings_providers.dart';
import '../state/dashboard_state.dart';

class DashboardViewModel extends Notifier<DashboardState> {
  static const _onlineThreshold = 50;

  late final VehicleControlRepository _controls;
  StreamSubscription<Telemetry>? _telemetrySubscription;
  bool _telemetryEnabled = true;

  @override
  DashboardState build() {
    _controls = ref.read(vehicleControlRepositoryProvider);
    _telemetryEnabled = ref.read(telemetryEnabledProvider);

    _telemetrySubscription?.cancel();
    _telemetrySubscription = ref
        .read(telemetryRepositoryProvider)
        .watchTelemetry()
        .listen(_onTelemetry);

    ref.listen<bool>(telemetryEnabledProvider, (_, enabled) {
      setTelemetryEnabled(enabled);
    });
    ref.onDispose(() => _telemetrySubscription?.cancel());

    return DashboardState(
      telemetry: Telemetry.initial(),
      isOnline: false,
      telemetryPaused: !_telemetryEnabled,
    );
  }

  void setTelemetryEnabled(bool enabled) {
    _telemetryEnabled = enabled;
    state = state.copyWith(telemetryPaused: !enabled);
  }

  void arm() => _controls.setArmed(true);

  void disarm() => _controls.setArmed(false);

  void _onTelemetry(Telemetry telemetry) {
    if (!_telemetryEnabled || !ref.mounted) return;

    state = DashboardState(
      telemetry: telemetry,
      isOnline: telemetry.connection > _onlineThreshold,
      telemetryPaused: false,
    );
  }
}
