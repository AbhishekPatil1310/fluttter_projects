import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../state/settings_state.dart';
import '../view_models/settings_view_model.dart';

final settingsViewModelProvider =
    NotifierProvider<SettingsViewModel, SettingsState>(SettingsViewModel.new);

final telemetryEnabledProvider = Provider<bool>((ref) {
  return ref.watch(
    settingsViewModelProvider.select((settings) => settings.telemetryEnabled),
  );
});
