import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../state/settings_state.dart';

class SettingsViewModel extends Notifier<SettingsState> {
  @override
  SettingsState build() => const SettingsState();

  void setTelemetryEnabled(bool value) {
    state = state.copyWith(telemetryEnabled: value);
  }

  void setHighContrast(bool value) {
    state = state.copyWith(highContrast: value);
  }
}
