import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../di/data_providers.dart';
import '../../../domain/entities/alert.dart';
import '../../../domain/entities/mission_log.dart';
import '../../../domain/entities/telemetry.dart';
import '../../../domain/repositories/alert_repository.dart';
import '../../../domain/repositories/mission_log_repository.dart';
import '../../settings/providers/settings_providers.dart';
import '../state/logs_state.dart';

class LogsViewModel extends Notifier<LogsState> {
  static const _maxTelemetryEntries = 50;

  late final AlertRepository _alertRepository;
  late final MissionLogRepository _missionLogRepository;
  StreamSubscription<Telemetry>? _telemetrySubscription;
  StreamSubscription<List<Alert>>? _alertSubscription;
  StreamSubscription<List<MissionLog>>? _missionSubscription;
  bool _telemetryEnabled = true;

  @override
  LogsState build() {
    _alertRepository = ref.read(alertRepositoryProvider);
    _missionLogRepository = ref.read(missionLogRepositoryProvider);
    _telemetryEnabled = ref.read(telemetryEnabledProvider);

    _telemetrySubscription?.cancel();
    _alertSubscription?.cancel();
    _missionSubscription?.cancel();

    _telemetrySubscription = ref
        .read(telemetryRepositoryProvider)
        .watchTelemetry()
        .listen(_onTelemetry);
    _alertSubscription = _alertRepository.historyStream.listen(_onAlerts);
    _missionSubscription =
        _missionLogRepository.historyStream.listen(_onMissions);

    ref.listen<bool>(telemetryEnabledProvider, (_, enabled) {
      setTelemetryEnabled(enabled);
    });
    ref.onDispose(() {
      _telemetrySubscription?.cancel();
      _alertSubscription?.cancel();
      _missionSubscription?.cancel();
    });

    return LogsState(
      telemetry: [Telemetry.initial()],
      alerts: _alertRepository.history,
      missions: _missionLogRepository.history,
    );
  }

  void setTelemetryEnabled(bool enabled) {
    _telemetryEnabled = enabled;
  }

  void _onTelemetry(Telemetry packet) {
    if (!_telemetryEnabled || !ref.mounted) return;

    final entries = [packet, ...state.telemetry];
    state = state.copyWith(
      telemetry: List.unmodifiable(
        entries.length > _maxTelemetryEntries
            ? entries.sublist(0, _maxTelemetryEntries)
            : entries,
      ),
    );
  }

  void _onAlerts(List<Alert> history) {
    if (ref.mounted) state = state.copyWith(alerts: history);
  }

  void _onMissions(List<MissionLog> history) {
    if (ref.mounted) state = state.copyWith(missions: history);
  }
}
