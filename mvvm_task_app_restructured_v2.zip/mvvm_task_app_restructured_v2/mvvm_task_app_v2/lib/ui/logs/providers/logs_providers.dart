import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../state/logs_state.dart';
import '../view_models/logs_view_model.dart';

final logsViewModelProvider =
    NotifierProvider<LogsViewModel, LogsState>(LogsViewModel.new);
