import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../state/mission_state.dart';
import '../view_models/mission_view_model.dart';

final missionViewModelProvider =
    NotifierProvider<MissionViewModel, MissionState>(MissionViewModel.new);
