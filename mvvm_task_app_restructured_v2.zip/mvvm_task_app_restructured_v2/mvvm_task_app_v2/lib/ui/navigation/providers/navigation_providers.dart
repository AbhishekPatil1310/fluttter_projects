import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../view_models/navigation_view_model.dart';

final navigationViewModelProvider =
    NotifierProvider<NavigationViewModel, int>(NavigationViewModel.new);
