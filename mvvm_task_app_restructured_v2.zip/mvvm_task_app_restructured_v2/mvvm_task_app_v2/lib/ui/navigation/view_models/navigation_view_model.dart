import 'package:flutter_riverpod/flutter_riverpod.dart';

/// UI-local navigation state.
class NavigationViewModel extends Notifier<int> {
  @override
  int build() => 0;

  void select(int index) {
    if (state == index) return;
    state = index;
  }
}
