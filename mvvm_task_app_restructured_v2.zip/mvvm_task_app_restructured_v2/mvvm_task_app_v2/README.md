# NOMAD / UGV Control (mvvm_task_app)

Flutter UGV field-operations console, structured with **MVVM** + **Riverpod**
dependency injection, following SOLID principles.

## Structure

```
lib/
  main.dart                     ProviderScope + MaterialApp (theme follows settings)
  config/app_config.dart
  di/data_providers.dart        Riverpod providers = dependency injection for services + repositories
  domain/
    entities/                   alert, telemetry, mission_log, waypoint
    repositories/               small interfaces the UI may request
    services/                   route_calculator (pure mission math)
  data/
    services/                   telemetry_service (mock server), file_service (interface),
                                file_selector_file_service (implementation)
    mappers/                    waypoint_mapper (JSON <-> Waypoint)
    repositories/               *_repository_impl
  ui/
    core/                       shared widgets and helpers
    <feature>/                  dashboard, mission, alerts, logs, settings, navigation
      providers/                UI-layer providers: DI repositories -> view model
      view_models/              presentation logic; exposes an immutable State
      state/                    immutable state class (navigation state is a plain int)
      screens/                  render the state, compose widgets
      widgets/                  small, dumb, reusable sub-parts
```

Every feature has a view model: dashboard, mission, alerts, logs, settings and
navigation. Screens never talk to repositories or providers other than their
own view model.

## Dependency flow

`screen -> view model -> domain repository interface <- data repository impl -> service`

- Screens `ref.watch` the view model's state and call its methods.
- `ui/<feature>/providers/*` read repositories from `di/data_providers.dart`
  and inject them into the view model.
- View models depend only on domain interfaces, never on `data/`.
- Cross-feature input (the telemetry on/off setting) is injected as a
  `ProviderListenable<bool>`, so dashboard and logs do not import the settings
  view model.

## Repository interfaces (Interface Segregation)

| Interface | Responsibility |
|---|---|
| `TelemetryRepository` | read latest telemetry + stream |
| `VehicleControlRepository` | arm / disarm commands |
| `AlertRepository` | alert history, emit, acknowledge by id |
| `MissionRepository` | waypoint plan, save, load |
| `MissionLogRepository` | read-only mission event history |

`MissionRepositoryImpl` implements both mission interfaces; consumers only see
the one they need.

## SOLID

- **S** - services do I/O, mappers serialize, repositories coordinate, view models hold presentation logic, `RouteCalculator` holds mission math, widgets draw.
- **O** - swap a data source by overriding a provider; no other code changes.
- **L** - any repository implementation is substitutable (see `test/fakes`); unknown alert ids are ignored by real and fake alike.
- **I** - five small, focused repository interfaces.
- **D** - upper layers depend on domain abstractions; `MissionRepositoryImpl` depends on the `FileService` interface; DI wires implementations.

## Behaviour notes

- Critical/emergency alerts open a non-dismissible dialog; pressing ACKNOWLEDGE
  marks that alert acknowledged (by id) in the history.
- Alerts and waypoints carry stable ids, used for acknowledging and as list keys.
- The mission log records only save/load events, not every waypoint edit.
- Settings: "Telemetry stream" off freezes the dashboard and telemetry log at
  the last received values; "High contrast mode" switches the app theme.

## Run / test

```
flutter pub get
flutter run -d linux
flutter test
```
