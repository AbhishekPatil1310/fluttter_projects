import 'dart:async';

import 'package:mvvm_task_app/data/services/file_service.dart';
import 'package:mvvm_task_app/domain/entities/alert.dart';
import 'package:mvvm_task_app/domain/entities/mission_log.dart';
import 'package:mvvm_task_app/domain/entities/telemetry.dart';
import 'package:mvvm_task_app/domain/entities/waypoint.dart';
import 'package:mvvm_task_app/domain/repositories/alert_repository.dart';
import 'package:mvvm_task_app/domain/repositories/mission_log_repository.dart';
import 'package:mvvm_task_app/domain/repositories/mission_repository.dart';
import 'package:mvvm_task_app/domain/repositories/telemetry_repository.dart';
import 'package:mvvm_task_app/domain/repositories/vehicle_control_repository.dart';

class FakeTelemetryRepository implements TelemetryRepository {
  final _controller = StreamController<Telemetry>.broadcast();
  Telemetry _latest = Telemetry.initial();

  Telemetry get latest => _latest;

  @override
  Stream<Telemetry> watchTelemetry() => _controller.stream;

  void push(Telemetry telemetry) {
    _latest = telemetry;
    _controller.add(telemetry);
  }
}

class FakeVehicleControlRepository implements VehicleControlRepository {
  FakeVehicleControlRepository(this._telemetry);

  final FakeTelemetryRepository _telemetry;

  @override
  void setArmed(bool armed) =>
      _telemetry.push(_telemetry.latest.copyWith(armed: armed));
}

class FakeAlertRepository implements AlertRepository {
  final _controller = StreamController<List<Alert>>.broadcast();
  final List<Alert> _history = [];
  int _nextId = 0;

  @override
  List<Alert> get history => List.unmodifiable(_history);

  @override
  Stream<List<Alert>> get historyStream => _controller.stream;

  @override
  Alert emit(String message, AlertLevel level) {
    final alert = Alert(
      id: 'fake-${_nextId++}',
      message: message,
      level: level,
      timestamp: DateTime.now(),
    );
    _history.insert(0, alert);
    _controller.add(history);
    return alert;
  }

  /// Ignores unknown ids, like the real implementation.
  @override
  void acknowledge(String id) {
    final index = _history.indexWhere((alert) => alert.id == id);
    if (index == -1) return;
    _history[index] = _history[index].copyWith(acknowledged: true);
    _controller.add(history);
  }
}

class FakeMissionRepository implements MissionRepository {
  List<Waypoint> _waypoints = const [];
  List<Waypoint>? nextLoadResult;
  bool nextSaveResult = true;

  @override
  List<Waypoint> get waypoints => _waypoints;

  @override
  void replace(List<Waypoint> waypoints) => _waypoints = waypoints;

  @override
  Future<bool> save() async => nextSaveResult;

  @override
  Future<List<Waypoint>?> load() async {
    final result = nextLoadResult;
    if (result != null) _waypoints = result;
    return result;
  }
}

class FakeMissionLogRepository implements MissionLogRepository {
  final _controller = StreamController<List<MissionLog>>.broadcast();
  List<MissionLog> _history = const [];

  @override
  List<MissionLog> get history => _history;

  @override
  Stream<List<MissionLog>> get historyStream => _controller.stream;

  void push(MissionLog log) {
    _history = [log, ..._history];
    _controller.add(_history);
  }
}

class FakeFileService implements FileService {
  /// Text returned by [loadMission]; `null` simulates a cancelled dialog.
  String? nextLoadContents;
  bool nextSaveResult = true;
  String? savedContents;

  @override
  Future<bool> saveMission(String contents) async {
    if (nextSaveResult) savedContents = contents;
    return nextSaveResult;
  }

  @override
  Future<String?> loadMission() async => nextLoadContents;
}
