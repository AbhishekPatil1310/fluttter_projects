import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'package:mvvm_task_app/data/mappers/waypoint_mapper.dart';
import 'package:mvvm_task_app/data/repositories/alert_repository_impl.dart';
import 'package:mvvm_task_app/data/repositories/mission_repository_impl.dart';
import 'package:mvvm_task_app/domain/entities/alert.dart';
import 'package:mvvm_task_app/domain/entities/mission_log.dart';
import 'package:mvvm_task_app/domain/entities/waypoint.dart';
import 'package:mvvm_task_app/domain/services/route_calculator.dart';

import 'fakes/fake_repositories.dart';

void main() {
  group('AlertRepositoryImpl', () {
    test('acknowledges by id even after the list shifted', () {
      final repository = AlertRepositoryImpl();
      addTearDown(repository.dispose);

      final first = repository.emit('GPS signal lost', AlertLevel.critical);
      repository.emit('Battery below 50%', AlertLevel.warning);
      repository.acknowledge(first.id);

      final history = repository.history;
      expect(history.firstWhere((a) => a.id == first.id).acknowledged, isTrue);
      expect(history.where((a) => a.id != first.id).single.acknowledged, isFalse);
    });

    test('ignores unknown ids', () {
      final repository = AlertRepositoryImpl();
      addTearDown(repository.dispose);
      repository.emit('Geofence breach detected', AlertLevel.emergency);

      expect(() => repository.acknowledge('nope'), returnsNormally);
      expect(repository.history.single.acknowledged, isFalse);
    });

    test('keeps only the 10 most recent alerts with unique ids', () {
      final repository = AlertRepositoryImpl();
      addTearDown(repository.dispose);
      for (var i = 0; i < 15; i++) {
        repository.emit('alert $i', AlertLevel.info);
      }

      expect(repository.history.length, 10);
      expect(repository.history.map((a) => a.id).toSet().length, 10);
      expect(repository.history.first.message, 'alert 14');
    });
  });

  group('MissionRepositoryImpl', () {
    late FakeFileService files;
    late MissionRepositoryImpl repository;

    setUp(() {
      files = FakeFileService();
      repository = MissionRepositoryImpl(files);
      addTearDown(repository.dispose);
    });

    test('editing the plan does not flood the mission log', () {
      repository.replace([Waypoint(position: const LatLng(18, 77))]);
      repository.replace([
        Waypoint(position: const LatLng(18, 77)),
        Waypoint(position: const LatLng(18.1, 77.1)),
      ]);

      expect(repository.history, isEmpty);
    });

    test('save and load are logged', () async {
      repository.replace([Waypoint(position: const LatLng(18, 77))]);
      await repository.save();
      expect(repository.history.single.type, MissionLogType.missionSaved);

      files.nextLoadContents = files.savedContents;
      final loaded = await repository.load();
      expect(loaded, isNotNull);
      expect(repository.history.first.type, MissionLogType.missionLoaded);
      expect(repository.history.length, 2);
    });

    test('a cancelled save is not logged', () async {
      files.nextSaveResult = false;
      expect(await repository.save(), isFalse);
      expect(repository.history, isEmpty);
    });

    test('a cancelled load returns null and keeps the plan', () async {
      repository.replace([Waypoint(position: const LatLng(18, 77))]);
      files.nextLoadContents = null;

      expect(await repository.load(), isNull);
      expect(repository.waypoints.length, 1);
    });

    test('an invalid mission file throws FormatException', () async {
      files.nextLoadContents = '{"not": "a list"}';
      expect(repository.load(), throwsFormatException);
    });
  });

  group('WaypointMapper', () {
    test('round-trips waypoints', () {
      final original = [
        Waypoint(position: const LatLng(18.5, 77.5), altitude: 40, speed: 3),
      ];

      final decoded = WaypointMapper.decode(WaypointMapper.encode(original));

      expect(decoded.single.position, original.single.position);
      expect(decoded.single.altitude, 40);
      expect(decoded.single.speed, 3);
    });
  });

  group('RouteCalculator', () {
    test('fewer than two waypoints has no route', () {
      expect(RouteCalculator.calculate(const []).distanceKm, 0);
      final single = [Waypoint(position: const LatLng(18, 77))];
      expect(RouteCalculator.calculate(single).estimatedMinutes, 0);
    });

    test('computes distance and time from average speed', () {
      final route = [
        Waypoint(position: const LatLng(18.0, 77.0), speed: 2),
        Waypoint(position: const LatLng(18.01, 77.0), speed: 2),
      ];

      final metrics = RouteCalculator.calculate(route);

      expect(metrics.distanceKm, closeTo(1.11, 0.02));
      expect(metrics.estimatedMinutes, closeTo(metrics.distanceKm * 1000 / 2 / 60, 0.001));
    });

    test('zero speed yields no estimate', () {
      final route = [
        Waypoint(position: const LatLng(18.0, 77.0), speed: 0),
        Waypoint(position: const LatLng(18.01, 77.0), speed: 0),
      ];

      final metrics = RouteCalculator.calculate(route);

      expect(metrics.distanceKm, greaterThan(0));
      expect(metrics.estimatedMinutes, 0);
    });
  });
}
