import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'package:mvvm_task_app/di/data_providers.dart';
import 'package:mvvm_task_app/domain/entities/alert.dart';
import 'package:mvvm_task_app/domain/entities/mission_log.dart';
import 'package:mvvm_task_app/domain/entities/telemetry.dart';
import 'package:mvvm_task_app/domain/entities/waypoint.dart';
import 'package:mvvm_task_app/ui/alerts/providers/alerts_providers.dart';
import 'package:mvvm_task_app/ui/dashboard/providers/dashboard_providers.dart';
import 'package:mvvm_task_app/ui/logs/providers/logs_providers.dart';
import 'package:mvvm_task_app/ui/mission/providers/mission_providers.dart';
import 'package:mvvm_task_app/ui/navigation/providers/navigation_providers.dart';
import 'package:mvvm_task_app/ui/settings/providers/settings_providers.dart';

import 'fakes/fake_repositories.dart';

Future<void> settle() => Future<void>.delayed(Duration.zero);

void main() {
  late FakeTelemetryRepository telemetry;
  late FakeAlertRepository alerts;
  late FakeMissionRepository missions;
  late FakeMissionLogRepository missionLogs;
  late ProviderContainer container;

  setUp(() {
    telemetry = FakeTelemetryRepository();
    alerts = FakeAlertRepository();
    missions = FakeMissionRepository();
    missionLogs = FakeMissionLogRepository();
    container = ProviderContainer(
      overrides: [
        telemetryRepositoryProvider.overrideWithValue(telemetry),
        vehicleControlRepositoryProvider.overrideWithValue(
          FakeVehicleControlRepository(telemetry),
        ),
        alertRepositoryProvider.overrideWithValue(alerts),
        missionRepositoryProvider.overrideWithValue(missions),
        missionLogRepositoryProvider.overrideWithValue(missionLogs),
      ],
    );
    addTearDown(container.dispose);
  });

  group('DashboardViewModel', () {
    test('starts from the latest repository snapshot', () {
      final state = container.read(dashboardViewModelProvider);
      expect(state.telemetry.connection, telemetry.latest.connection);
      expect(state.isOnline, isTrue);
      expect(state.telemetryPaused, isFalse);
    });

    test('follows the telemetry stream and derives online status', () async {
      container.read(dashboardViewModelProvider);

      telemetry.push(Telemetry.initial().copyWith(connection: 30));
      await settle();

      final state = container.read(dashboardViewModelProvider);
      expect(state.telemetry.connection, 30);
      expect(state.isOnline, isFalse);
    });

    test('arm and disarm go through the vehicle control repository', () async {
      final viewModel = container.read(dashboardViewModelProvider.notifier);

      viewModel.arm();
      await settle();
      expect(container.read(dashboardViewModelProvider).telemetry.armed, isTrue);

      viewModel.disarm();
      await settle();
      expect(
        container.read(dashboardViewModelProvider).telemetry.armed,
        isFalse,
      );
    });

    test('freezes while the telemetry setting is off', () async {
      container.read(dashboardViewModelProvider);
      container
          .read(settingsViewModelProvider.notifier)
          .setTelemetryEnabled(false);
      await settle();

      telemetry.push(Telemetry.initial().copyWith(connection: 30));
      await settle();

      final state = container.read(dashboardViewModelProvider);
      expect(state.telemetryPaused, isTrue);
      expect(state.telemetry.connection, Telemetry.initial().connection);
    });
  });

  group('AlertsViewModel', () {
    test('critical alert becomes pending, warning becomes a notice', () {
      final viewModel = container.read(alertsViewModelProvider.notifier);

      viewModel.triggerLowBattery();
      var state = container.read(alertsViewModelProvider);
      expect(state.notice, 'Battery below 50%');
      expect(state.pendingCriticalAlert, isNull);

      viewModel.triggerGpsLost();
      state = container.read(alertsViewModelProvider);
      expect(state.pendingCriticalAlert?.message, 'GPS signal lost');

      viewModel.clearPendingCriticalAlert();
      expect(
        container.read(alertsViewModelProvider).pendingCriticalAlert,
        isNull,
      );
    });

    test('acknowledging by id survives new alerts shifting the list',
        () async {
      final viewModel = container.read(alertsViewModelProvider.notifier);
      viewModel.triggerGpsLost();
      final critical =
          container.read(alertsViewModelProvider).pendingCriticalAlert!;

      viewModel.triggerLowBattery(); // pushes the critical alert down
      viewModel.acknowledge(critical.id);
      await settle();

      final history = container.read(alertsViewModelProvider).history;
      expect(history.firstWhere((a) => a.id == critical.id).acknowledged, isTrue);
      expect(
        history.where((a) => a.id != critical.id).every((a) => !a.acknowledged),
        isTrue,
      );
    });
  });

  group('MissionViewModel', () {
    const a = LatLng(18.0, 77.0);
    const b = LatLng(18.01, 77.01);
    const c = LatLng(18.02, 77.02);

    test('add, remove and metrics', () {
      final viewModel = container.read(missionViewModelProvider.notifier);
      viewModel.addWaypoint(a);
      viewModel.addWaypoint(b);

      var state = container.read(missionViewModelProvider);
      expect(state.waypoints.length, 2);
      expect(state.totalDistanceKm, greaterThan(0));
      expect(state.estimatedMinutes, greaterThan(0));

      viewModel.removeWaypoint(0);
      state = container.read(missionViewModelProvider);
      expect(state.waypoints.length, 1);
      expect(state.totalDistanceKm, 0);
    });

    test('reorder follows ReorderableListView convention', () {
      final viewModel = container.read(missionViewModelProvider.notifier);
      viewModel
        ..addWaypoint(a)
        ..addWaypoint(b)
        ..addWaypoint(c);
      final idsBefore =
          container.read(missionViewModelProvider).waypoints.map((w) => w.id);

      // Drag first item to the end (newIndex == length).
      viewModel.reorderWaypoint(0, 3);
      final waypoints = container.read(missionViewModelProvider).waypoints;
      expect(waypoints.map((w) => w.position).toList(), [b, c, a]);
      // Identity travels with the waypoint, so list keys stay stable.
      expect(waypoints.map((w) => w.id).toSet(), idsBefore.toSet());
      expect(waypoints.last.id, idsBefore.first);
    });

    test('editing keeps the waypoint id', () {
      final viewModel = container.read(missionViewModelProvider.notifier);
      viewModel.addWaypoint(a);
      final id = container.read(missionViewModelProvider).waypoints.first.id;

      viewModel.updateWaypoint(0, altitude: 55);

      final waypoint = container.read(missionViewModelProvider).waypoints.first;
      expect(waypoint.id, id);
      expect(waypoint.altitude, 55);
    });

    test('load replaces waypoints and reports feedback', () async {
      missions.nextLoadResult = [Waypoint(position: a)];
      final viewModel = container.read(missionViewModelProvider.notifier);

      await viewModel.loadMission();
      final state = container.read(missionViewModelProvider);
      expect(state.waypoints.length, 1);
      expect(state.message, 'Mission loaded.');
      expect(state.busy, isFalse);
    });

    test('cancelled save reports feedback', () async {
      missions.nextSaveResult = false;
      await container.read(missionViewModelProvider.notifier).saveMission();
      expect(
        container.read(missionViewModelProvider).message,
        'Save cancelled.',
      );
    });
  });

  group('LogsViewModel', () {
    test('starts with the latest telemetry sample', () {
      final state = container.read(logsViewModelProvider);
      expect(state.telemetry.length, 1);
      expect(state.alerts, isEmpty);
      expect(state.missions, isEmpty);
    });

    test('keeps only the 50 most recent telemetry samples', () async {
      container.read(logsViewModelProvider);

      for (var i = 0; i < 60; i++) {
        telemetry.push(Telemetry.initial().copyWith(battery: i));
        await settle();
      }

      final entries = container.read(logsViewModelProvider).telemetry;
      expect(entries.length, 50);
      expect(entries.first.battery, 59); // newest first
    });

    test('mirrors alert and mission histories', () async {
      container.read(logsViewModelProvider);

      alerts.emit('GPS signal lost', AlertLevel.critical);
      missionLogs.push(
        MissionLog(
          message: 'Mission saved (2 waypoints)',
          type: MissionLogType.missionSaved,
          timestamp: DateTime.now(),
        ),
      );
      await settle();

      final state = container.read(logsViewModelProvider);
      expect(state.alerts.single.message, 'GPS signal lost');
      expect(state.missions.single.type, MissionLogType.missionSaved);
    });

    test('ignores telemetry while the setting is off', () async {
      container.read(logsViewModelProvider);
      container
          .read(settingsViewModelProvider.notifier)
          .setTelemetryEnabled(false);
      await settle();

      telemetry.push(Telemetry.initial().copyWith(battery: 5));
      await settle();

      expect(container.read(logsViewModelProvider).telemetry.length, 1);
    });
  });

  group('NavigationViewModel', () {
    test('selects a destination', () {
      expect(container.read(navigationViewModelProvider), 0);
      container.read(navigationViewModelProvider.notifier).select(3);
      expect(container.read(navigationViewModelProvider), 3);
    });
  });
}
