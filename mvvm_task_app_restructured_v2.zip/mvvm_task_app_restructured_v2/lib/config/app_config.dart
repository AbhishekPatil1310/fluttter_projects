import 'package:flutter/material.dart';

abstract final class AppConfig {
  static const appName = 'NOMAD / UGV CONTROL';
  static const primary = Color(0xFF54D1B0);
  static const background = Color(0xFF101820);
  static const panel = Color(0xFF192832);

  static ThemeData theme({bool highContrast = false}) =>
      ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: highContrast ? Colors.black : background,
        colorScheme: ColorScheme.fromSeed(
          seedColor: primary,
          brightness: Brightness.dark,
          contrastLevel: highContrast ? 1.0 : 0.0,
        ),
      );
}
