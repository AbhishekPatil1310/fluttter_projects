import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart'; // Required for StateNotifierProvider

import '../state/settings_state.dart';
import '../view_models/settings_view_model.dart';

/// Settings are UI-local state, so this ViewModel needs no dependencies.
final settingsViewModelProvider =
    StateNotifierProvider<SettingsViewModel, SettingsState>(
      (ref) => SettingsViewModel(),
    );

final telemetryEnabledProvider = Provider<bool>(
  (ref) => ref.watch(
    settingsViewModelProvider.select((settings) => settings.telemetryEnabled),
  ),
);
