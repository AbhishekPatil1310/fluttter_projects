import 'package:flutter_riverpod/legacy.dart';

import '../state/settings_state.dart';

/// UI-local settings state. It has no external dependencies.
class SettingsViewModel extends StateNotifier<SettingsState> {
  SettingsViewModel() : super(const SettingsState());

  void setTelemetryEnabled(bool value) =>
      state = state.copyWith(telemetryEnabled: value);

  void setHighContrast(bool value) =>
      state = state.copyWith(highContrast: value);
}
