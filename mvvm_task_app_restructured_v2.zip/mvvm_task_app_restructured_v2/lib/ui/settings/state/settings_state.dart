class SettingsState {
  const SettingsState({
    this.telemetryEnabled = true,
    this.highContrast = false,
  });

  final bool telemetryEnabled;
  final bool highContrast;

  SettingsState copyWith({bool? telemetryEnabled, bool? highContrast}) =>
      SettingsState(
        telemetryEnabled: telemetryEnabled ?? this.telemetryEnabled,
        highContrast: highContrast ?? this.highContrast,
      );
}
