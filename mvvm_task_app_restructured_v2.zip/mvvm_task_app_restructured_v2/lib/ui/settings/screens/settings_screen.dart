import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/settings_providers.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(settingsViewModelProvider);
    final viewModel = ref.read(settingsViewModelProvider.notifier);

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          'SETTINGS',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        SwitchListTile(
          value: state.telemetryEnabled,
          onChanged: viewModel.setTelemetryEnabled,
          title: const Text('Telemetry stream'),
        ),
        SwitchListTile(
          value: state.highContrast,
          onChanged: viewModel.setHighContrast,
          title: const Text('High contrast mode'),
        ),
      ],
    );
  }
}
