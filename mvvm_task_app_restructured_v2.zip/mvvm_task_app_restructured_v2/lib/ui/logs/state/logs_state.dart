import '../../../domain/entities/alert.dart';
import '../../../domain/entities/mission_log.dart';
import '../../../domain/entities/telemetry.dart';

class LogsState {
  const LogsState({
    this.telemetry = const [],
    this.alerts = const [],
    this.missions = const [],
  });

  /// Most recent telemetry samples, newest first.
  final List<Telemetry> telemetry;

  /// Alert history, newest first.
  final List<Alert> alerts;

  /// Mission events, newest first.
  final List<MissionLog> missions;

  LogsState copyWith({
    List<Telemetry>? telemetry,
    List<Alert>? alerts,
    List<MissionLog>? missions,
  }) =>
      LogsState(
        telemetry: telemetry ?? this.telemetry,
        alerts: alerts ?? this.alerts,
        missions: missions ?? this.missions,
      );
}
