import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/logs_providers.dart';
import '../widgets/alert_log_list.dart';
import '../widgets/mission_log_list.dart';
import '../widgets/telemetry_log_list.dart';

class LogsScreen extends StatelessWidget {
  const LogsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DefaultTabController(
      length: 3,
      child: Column(
        children: [
          TabBar(tabs: [
            Tab(text: 'Telemetry'),
            Tab(text: 'Alerts'),
            Tab(text: 'Missions'),
          ]),
          Expanded(
            child: TabBarView(
              children: [
                _TelemetryLogsTab(),
                _AlertLogsTab(),
                _MissionLogsTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TelemetryLogsTab extends ConsumerWidget {
  const _TelemetryLogsTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final entries = ref.watch(logsViewModelProvider.select((s) => s.telemetry));
    return TelemetryLogList(entries: entries);
  }
}

class _AlertLogsTab extends ConsumerWidget {
  const _AlertLogsTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final alerts = ref.watch(logsViewModelProvider.select((s) => s.alerts));
    return AlertLogList(alerts: alerts);
  }
}

class _MissionLogsTab extends ConsumerWidget {
  const _MissionLogsTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final logs = ref.watch(logsViewModelProvider.select((s) => s.missions));
    return MissionLogList(logs: logs);
  }
}
