import 'package:flutter_riverpod/legacy.dart';

// 1. Verify this path points to where telemetryRepositoryProvider is defined
import '../../../di/data_providers.dart';
import '../../settings/providers/settings_providers.dart';
import '../state/logs_state.dart';
import '../view_models/logs_view_model.dart';

/// Presentation DI. All provider resolution happens here, not in the
/// ViewModel.
final logsViewModelProvider = StateNotifierProvider<LogsViewModel, LogsState>((
  ref,
) {
  final alerts = ref.watch(alertRepositoryProvider);
  final missions = ref.watch(missionLogRepositoryProvider);
  final telemetryStream = ref
      .watch(telemetryRepositoryProvider) // Now resolved cleanly
      .watchTelemetry();
  final telemetryEnabled = ref.watch(telemetryEnabledProvider);

  return LogsViewModel(
    alertRepository: alerts,
    missionLogRepository: missions,
    telemetryStream: telemetryStream,
    telemetryEnabled: telemetryEnabled,
  );
});
