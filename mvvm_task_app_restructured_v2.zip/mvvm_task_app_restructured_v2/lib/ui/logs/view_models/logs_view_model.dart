import 'dart:async';

import 'package:flutter_riverpod/legacy.dart';

import '../../../domain/entities/alert.dart';
import '../../../domain/entities/mission_log.dart';
import '../../../domain/entities/telemetry.dart';
import '../../../domain/repositories/alert_repository.dart';
import '../../../domain/repositories/mission_log_repository.dart';
import '../state/logs_state.dart';

/// Combines telemetry, alert and mission histories for the logs screen.
///
/// Dependencies are constructor-injected. This class does not resolve
/// Riverpod providers itself.
class LogsViewModel extends StateNotifier<LogsState> {
  LogsViewModel({
    required AlertRepository alertRepository,
    required MissionLogRepository missionLogRepository,
    required Stream<Telemetry> telemetryStream,
    required bool telemetryEnabled,
  }) : _telemetryEnabled = telemetryEnabled,
       super(
         LogsState(
           telemetry: [Telemetry.initial()],
           alerts: alertRepository.history,
           missions: missionLogRepository.history,
         ),
       ) {
    _telemetrySubscription = telemetryStream.listen(_onTelemetry);
    _alertSubscription = alertRepository.historyStream.listen(_onAlerts);
    _missionSubscription = missionLogRepository.historyStream.listen(
      _onMissions,
    );
  }

  static const _maxTelemetryEntries = 50;

  bool _telemetryEnabled;

  late final StreamSubscription<Telemetry> _telemetrySubscription;
  late final StreamSubscription<List<Alert>> _alertSubscription;
  late final StreamSubscription<List<MissionLog>> _missionSubscription;

  void setTelemetryEnabled(bool enabled) {
    _telemetryEnabled = enabled;
  }

  void _onTelemetry(Telemetry packet) {
    if (!_telemetryEnabled) return;

    final entries = [packet, ...state.telemetry];
    state = state.copyWith(
      telemetry: List.unmodifiable(
        entries.length > _maxTelemetryEntries
            ? entries.sublist(0, _maxTelemetryEntries)
            : entries,
      ),
    );
  }

  void _onAlerts(List<Alert> history) {
    state = state.copyWith(alerts: history);
  }

  void _onMissions(List<MissionLog> history) {
    state = state.copyWith(missions: history);
  }

  @override
  void dispose() {
    _telemetrySubscription.cancel();
    _alertSubscription.cancel();
    _missionSubscription.cancel();
    super.dispose();
  }
}
