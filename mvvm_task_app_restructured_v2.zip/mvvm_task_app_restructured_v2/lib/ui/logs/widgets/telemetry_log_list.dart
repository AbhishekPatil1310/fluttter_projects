import 'package:flutter/material.dart';

import '../../../domain/entities/telemetry.dart';
import '../../core/utils/time_formatter.dart';

class TelemetryLogList extends StatelessWidget {
  const TelemetryLogList({super.key, required this.entries});

  final List<Telemetry> entries;

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) {
      return const Center(child: Text('No telemetry received yet'));
    }

    return ListView.builder(
      itemCount: entries.length,
      itemBuilder: (_, index) {
        final t = entries[index];
        return ListTile(
          title: Text(formatTime(t.timestamp)),
          subtitle: Text(
            'Battery ${t.battery}% • '
            'GPS ${t.satellites} • '
            'Link ${t.connection}% • '
            'Speed ${t.speed.toStringAsFixed(1)} m/s',
          ),
        );
      },
    );
  }
}
