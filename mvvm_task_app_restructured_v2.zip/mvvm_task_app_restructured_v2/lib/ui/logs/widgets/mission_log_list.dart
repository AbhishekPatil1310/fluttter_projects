import 'package:flutter/material.dart';

import '../../../domain/entities/mission_log.dart';
import '../../core/utils/time_formatter.dart';

class MissionLogList extends StatelessWidget {
  const MissionLogList({super.key, required this.logs});

  final List<MissionLog> logs;

  @override
  Widget build(BuildContext context) {
    if (logs.isEmpty) {
      return const Center(child: Text('No mission history available'));
    }

    return ListView.builder(
      itemCount: logs.length,
      itemBuilder: (_, index) {
        final mission = logs[index];
        return ListTile(
          leading: const Icon(Icons.route),
          title: Text(mission.message),
          subtitle: Text(
            '${mission.type.name} • ${formatTime(mission.timestamp)}',
          ),
        );
      },
    );
  }
}
