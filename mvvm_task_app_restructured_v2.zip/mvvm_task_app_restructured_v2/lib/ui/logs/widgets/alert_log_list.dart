import 'package:flutter/material.dart';

import '../../../domain/entities/alert.dart';
import '../../core/utils/time_formatter.dart';

class AlertLogList extends StatelessWidget {
  const AlertLogList({super.key, required this.alerts});

  final List<Alert> alerts;

  @override
  Widget build(BuildContext context) {
    if (alerts.isEmpty) {
      return const Center(child: Text('No alerts recorded'));
    }

    return ListView.builder(
      itemCount: alerts.length,
      itemBuilder: (_, index) {
        final a = alerts[index];
        return ListTile(
          title: Text(formatTime(a.timestamp)),
          subtitle: Text('${a.level.name.toUpperCase()}: ${a.message}'),
        );
      },
    );
  }
}
