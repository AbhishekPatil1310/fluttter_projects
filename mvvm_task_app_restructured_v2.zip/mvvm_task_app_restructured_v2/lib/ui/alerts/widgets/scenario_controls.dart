import 'package:flutter/material.dart';

/// Buttons that simulate alert scenarios.
class ScenarioControls extends StatelessWidget {
  const ScenarioControls({
    super.key,
    required this.onLowBattery,
    required this.onGpsLost,
    required this.onGeofenceBreach,
  });

  final VoidCallback onLowBattery;
  final VoidCallback onGpsLost;
  final VoidCallback onGeofenceBreach;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('SCENARIO CONTROLS', style: TextStyle(letterSpacing: 2)),
        const SizedBox(height: 14),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            FilledButton(
              onPressed: onLowBattery,
              child: const Text('LOW BATTERY'),
            ),
            FilledButton(
              onPressed: onGpsLost,
              child: const Text('GPS LOST'),
            ),
            FilledButton(
              onPressed: onGeofenceBreach,
              child: const Text('GEOFENCE BREACH'),
            ),
          ],
        ),
      ],
    );
  }
}
