import 'package:flutter/material.dart';

import '../../../domain/entities/alert.dart';
import '../../core/utils/time_formatter.dart';

/// Scrollable list of recorded alerts with an ACK action for critical ones.
class AlertHistory extends StatelessWidget {
  const AlertHistory({
    super.key,
    required this.alerts,
    required this.onAcknowledge,
  });

  final List<Alert> alerts;
  final ValueChanged<String> onAcknowledge;

  @override
  Widget build(BuildContext context) {
    if (alerts.isEmpty) {
      return const Center(child: Text('No alerts recorded'));
    }

    return ListView.builder(
      itemCount: alerts.length,
      itemBuilder: (context, index) {
        final alert = alerts[index];
        return Card(
          key: ValueKey(alert.id),
          child: ListTile(
            leading: Icon(Icons.circle, color: _color(alert.level)),
            title: Text(alert.message),
            subtitle: Text(
              '${alert.level.name.toUpperCase()} • ${formatTime(alert.timestamp)}'
              '${alert.acknowledged ? ' • ACKNOWLEDGED' : ''}',
            ),
            trailing: alert.requiresAcknowledgement && !alert.acknowledged
                ? TextButton(
                    onPressed: () => onAcknowledge(alert.id),
                    child: const Text('ACK'),
                  )
                : null,
          ),
        );
      },
    );
  }

  static Color _color(AlertLevel level) => switch (level) {
        AlertLevel.info => Colors.lightBlue,
        AlertLevel.warning => Colors.amber,
        AlertLevel.critical => Colors.orange,
        AlertLevel.emergency => Colors.redAccent,
      };
}
