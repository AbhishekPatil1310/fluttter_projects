import 'package:flutter_riverpod/legacy.dart';

import '../../../di/data_providers.dart';
import '../state/alert_state.dart';
import '../view_models/alerts_view_model.dart';

/// Presentation DI. The ViewModel receives a domain abstraction and does not
/// resolve Riverpod providers itself.
final alertsViewModelProvider =
    StateNotifierProvider<AlertsViewModel, AlertsState>((ref) {
  final repository = ref.watch(alertRepositoryProvider);
  return AlertsViewModel(repository: repository);
});
