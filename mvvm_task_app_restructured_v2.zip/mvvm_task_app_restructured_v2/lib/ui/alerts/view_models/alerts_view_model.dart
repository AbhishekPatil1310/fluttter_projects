import 'dart:async';

import 'package:flutter_riverpod/legacy.dart';

import '../../../domain/entities/alert.dart';
import '../../../domain/repositories/alert_repository.dart';
import '../state/alert_state.dart';

/// Presentation logic for alerts.
///
/// Dependencies are injected by the presentation provider. This class does
/// not resolve Riverpod providers and does not depend on [Ref].
class AlertsViewModel extends StateNotifier<AlertsState> {
  AlertsViewModel({required AlertRepository repository})
      : _repository = repository,
        super(AlertsState(history: repository.history)) {
    _historySubscription = repository.historyStream.listen(
      (history) => state = state.copyWith(history: history),
    );
  }

  final AlertRepository _repository;
  late final StreamSubscription<List<Alert>> _historySubscription;

  void triggerLowBattery() =>
      _trigger(AlertLevel.warning, 'Battery below 50%');

  void triggerGpsLost() => _trigger(AlertLevel.critical, 'GPS signal lost');

  void triggerGeofenceBreach() =>
      _trigger(AlertLevel.emergency, 'Geofence breach detected');

  void acknowledge(String id) => _repository.acknowledge(id);

  void clearPendingCriticalAlert() =>
      state = state.copyWith(clearPendingCriticalAlert: true);

  void clearNotice() => state = state.copyWith(clearNotice: true);

  void _trigger(AlertLevel level, String message) {
    final alert = _repository.emit(message, level);
    state = alert.requiresAcknowledgement
        ? state.copyWith(pendingCriticalAlert: alert)
        : state.copyWith(notice: message);
  }

  @override
  void dispose() {
    _historySubscription.cancel();
    super.dispose();
  }
}
