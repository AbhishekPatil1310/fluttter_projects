import '../../../domain/entities/alert.dart';

class AlertsState {
  const AlertsState({
    this.history = const [],
    this.pendingCriticalAlert,
    this.notice,
  });

  final List<Alert> history;

  /// Critical/emergency alert the screen must show in a dialog.
  final Alert? pendingCriticalAlert;

  /// One-shot feedback the screen should show in a snackbar.
  final String? notice;

  AlertsState copyWith({
    List<Alert>? history,
    Alert? pendingCriticalAlert,
    bool clearPendingCriticalAlert = false,
    String? notice,
    bool clearNotice = false,
  }) {
    return AlertsState(
      history: history ?? this.history,
      pendingCriticalAlert: clearPendingCriticalAlert
          ? null
          : (pendingCriticalAlert ?? this.pendingCriticalAlert),
      notice: clearNotice ? null : (notice ?? this.notice),
    );
  }
}
