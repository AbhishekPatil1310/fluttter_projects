import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../../core/widgets/app_panel.dart';

/// Live map that follows the vehicle's current location.
class LiveMap extends StatefulWidget {
  const LiveMap({
    super.key,
    required this.position,
    required this.heading,
  });

  final LatLng position;

  /// Vehicle heading in degrees (0 = north).
  final int heading;

  @override
  State<LiveMap> createState() => _LiveMapState();
}

class _LiveMapState extends State<LiveMap> {
  final _controller = MapController();
  bool _ready = false;

  @override
  void didUpdateWidget(covariant LiveMap oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (_ready && oldWidget.position != widget.position) {
      _controller.move(widget.position, _controller.camera.zoom);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final position = widget.position;

    return AppPanel(
      title: 'LIVE MAP',
      child: Stack(
        children: [
          FlutterMap(
            mapController: _controller,
            options: MapOptions(
              initialCenter: position,
              initialZoom: 16,
              onMapReady: () => _ready = true,
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.nomad_control',
              ),
              MarkerLayer(
                markers: [
                  Marker(
                    point: position,
                    width: 44,
                    height: 44,
                    child: Transform.rotate(
                      angle: widget.heading * math.pi / 180,
                      child: const Icon(
                        Icons.navigation,
                        size: 36,
                        color: Colors.redAccent,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          Positioned(
            left: 8,
            bottom: 8,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: Text(
                  '${position.latitude.toStringAsFixed(5)}, '
                  '${position.longitude.toStringAsFixed(5)}',
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
