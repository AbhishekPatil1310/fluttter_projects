import 'package:flutter/material.dart';

import '../../../domain/entities/telemetry.dart';
import '../../core/widgets/app_panel.dart';
import '../../core/widgets/status_metric.dart';

/// Displays the telemetry data (battery, speed, GPS, heading).
class TelemetryTab extends StatelessWidget {
  const TelemetryTab({
    super.key,
    required this.telemetry,
    this.paused = false,
  });

  final Telemetry telemetry;

  /// Shown in the panel title while the telemetry stream is switched off.
  final bool paused;

  @override
  Widget build(BuildContext context) {
    return AppPanel(
      title: paused ? 'TELEMETRY (PAUSED)' : 'TELEMETRY',
      child: GridView.count(
        crossAxisCount: 1,
        childAspectRatio: 3.1,
        mainAxisSpacing: 8,
        children: [
          StatusMetric(
            label: 'Battery',
            value: '${telemetry.battery}%',
            icon: Icons.battery_6_bar,
            color: _batteryColor(telemetry.battery),
          ),
          StatusMetric(
            label: 'Speed',
            value: '${telemetry.speed.toStringAsFixed(1)} m/s',
            icon: Icons.speed,
            color: Colors.white,
          ),
          StatusMetric(
            label: 'GPS satellites',
            value: '${telemetry.satellites} FIX',
            icon: Icons.gps_fixed,
            color: Colors.lightBlueAccent,
          ),
          StatusMetric(
            label: 'Heading',
            value: '${telemetry.heading.toString().padLeft(3, '0')}°',
            icon: Icons.explore,
            color: Colors.orangeAccent,
          ),
        ],
      ),
    );
  }

  static Color _batteryColor(int battery) {
    if (battery < 20) return Colors.redAccent;
    if (battery < 50) return Colors.amber;
    return Colors.greenAccent;
  }
}
