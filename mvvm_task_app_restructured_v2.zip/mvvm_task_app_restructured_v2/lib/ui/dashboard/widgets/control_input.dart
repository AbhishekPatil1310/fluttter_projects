import 'package:flutter/material.dart';

import '../../core/widgets/app_panel.dart';

/// Arm / disarm buttons plus the vehicle online/offline indicator.
class ControlInput extends StatelessWidget {
  const ControlInput({
    super.key,
    required this.isArmed,
    required this.isOnline,
    required this.onArm,
    required this.onDisarm,
    this.vehicleName = 'NOMAD-07',
  });

  final bool isArmed;
  final bool isOnline;
  final VoidCallback onArm;
  final VoidCallback onDisarm;
  final String vehicleName;

  @override
  Widget build(BuildContext context) {
    return AppPanel(
      title: 'CONTROL INPUTS',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            height: 44,
            child: FilledButton.icon(
              onPressed: isArmed ? null : onArm,
              icon: const Icon(Icons.lock_open),
              label: const Text('ARM VEHICLE'),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 44,
            child: OutlinedButton.icon(
              onPressed: isArmed ? onDisarm : null,
              icon: const Icon(Icons.lock),
              label: const Text('DISARM VEHICLE'),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            isArmed ? 'STATUS: ARMED' : 'STATUS: DISARMED',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
              color: isArmed ? Colors.orangeAccent : Colors.white70,
            ),
          ),
          const Spacer(),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(
              Icons.circle,
              size: 12,
              color: isOnline ? Colors.green : Colors.red,
            ),
            title: Text(isOnline ? 'Vehicle online' : 'Vehicle offline'),
            subtitle: Text(vehicleName),
          ),
        ],
      ),
    );
  }
}
