import 'package:flutter_riverpod/legacy.dart';

import '../../../di/data_providers.dart';
import '../../settings/providers/settings_providers.dart';
import '../state/dashboard_state.dart';
import '../view_models/dashboard_view_model.dart';

final dashboardViewModelProvider =
    StateNotifierProvider<DashboardViewModel, DashboardState>((ref) {
  final controls = ref.watch(vehicleControlRepositoryProvider);
  final telemetryStream = ref
      .watch(telemetryRepositoryProvider)
      .watchTelemetry();
  final telemetryEnabled = ref.watch(telemetryEnabledProvider);

  return DashboardViewModel(
    controls: controls,
    telemetryStream: telemetryStream,
    telemetryEnabled: telemetryEnabled,
  );
});