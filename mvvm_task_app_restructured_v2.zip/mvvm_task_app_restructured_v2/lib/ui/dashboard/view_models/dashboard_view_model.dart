import 'dart:async';

import 'package:flutter_riverpod/legacy.dart';

import '../../../domain/entities/telemetry.dart';
import '../../../domain/repositories/vehicle_control_repository.dart';
import '../state/dashboard_state.dart';

/// Presentation logic for the dashboard.
///
/// All dependencies are constructor-injected. Riverpod dependency resolution
/// belongs in the presentation provider, not in this class.
class DashboardViewModel extends StateNotifier<DashboardState> {
  DashboardViewModel({
    required VehicleControlRepository controls,
    required Stream<Telemetry> telemetryStream,
    required bool telemetryEnabled,
  })  : _controls = controls,
        _telemetryEnabled = telemetryEnabled,
        super(_initialState(telemetryEnabled)) {
    _telemetrySubscription = telemetryStream.listen(_onTelemetry);
  }

  static const _onlineThreshold = 50;

  final VehicleControlRepository _controls;
  bool _telemetryEnabled;
  late final StreamSubscription<Telemetry> _telemetrySubscription;

  static DashboardState _initialState(bool enabled) => DashboardState(
        telemetry: Telemetry.initial(),
        isOnline: false,
        telemetryPaused: !enabled,
      );

  void setTelemetryEnabled(bool enabled) {
    _telemetryEnabled = enabled;
    state = state.copyWith(telemetryPaused: !enabled);
  }

  void arm() => _controls.setArmed(true);

  void disarm() => _controls.setArmed(false);

  void _onTelemetry(Telemetry telemetry) {
    if (!_telemetryEnabled) return;

    state = DashboardState(
      telemetry: telemetry,
      isOnline: telemetry.connection > _onlineThreshold,
      telemetryPaused: false,
    );
  }

  @override
  void dispose() {
    _telemetrySubscription.cancel();
    super.dispose();
  }
}
