import '../../../domain/entities/telemetry.dart';

class DashboardState {
  const DashboardState({
    required this.telemetry,
    required this.isOnline,
    this.telemetryPaused = false,
  });

  final Telemetry telemetry;

  /// Whether the vehicle link is strong enough to consider it online.
  final bool isOnline;

  /// True while the telemetry stream is switched off in the settings; the
  /// values shown are then the last ones received.
  final bool telemetryPaused;

  DashboardState copyWith({
    Telemetry? telemetry,
    bool? isOnline,
    bool? telemetryPaused,
  }) =>
      DashboardState(
        telemetry: telemetry ?? this.telemetry,
        isOnline: isOnline ?? this.isOnline,
        telemetryPaused: telemetryPaused ?? this.telemetryPaused,
      );
}
