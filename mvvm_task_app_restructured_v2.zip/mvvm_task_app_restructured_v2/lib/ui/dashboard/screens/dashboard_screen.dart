import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/dashboard_providers.dart';
import '../widgets/control_input.dart';
import '../widgets/live_map.dart';
import '../widgets/telemetry_tab.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(dashboardViewModelProvider);
    final viewModel = ref.read(dashboardViewModelProvider.notifier);
    final telemetry = state.telemetry;

    final controlInput = ControlInput(
      isArmed: telemetry.armed,
      isOnline: state.isOnline,
      onArm: viewModel.arm,
      onDisarm: viewModel.disarm,
    );
    final liveMap = LiveMap(
      position: telemetry.position,
      heading: telemetry.heading,
    );
    final telemetryTab = TelemetryTab(
      telemetry: telemetry,
      paused: state.telemetryPaused,
    );

    return LayoutBuilder(
      builder: (context, constraints) {
        final narrow = constraints.maxWidth < 850;
        if (narrow) {
          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              SizedBox(height: 260, child: liveMap),
              const SizedBox(height: 12),
              SizedBox(height: 290, child: controlInput),
              const SizedBox(height: 12),
              SizedBox(height: 300, child: telemetryTab),
            ],
          );
        }
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                width: constraints.maxWidth < 1100 ? 210 : 250,
                child: controlInput,
              ),
              const SizedBox(width: 16),
              Expanded(child: liveMap),
              const SizedBox(width: 16),
              SizedBox(
                width: constraints.maxWidth < 1100 ? 240 : 290,
                child: telemetryTab,
              ),
            ],
          ),
        );
      },
    );
  }
}
