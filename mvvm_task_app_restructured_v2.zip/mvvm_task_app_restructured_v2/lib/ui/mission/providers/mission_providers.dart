import 'package:flutter_riverpod/legacy.dart';

import '../../../di/data_providers.dart';
import '../state/mission_state.dart';
import '../view_models/mission_view_model.dart';

/// Presentation DI. The ViewModel receives the domain repository abstraction.
final missionViewModelProvider =
    StateNotifierProvider<MissionViewModel, MissionState>((ref) {
  final repository = ref.watch(missionRepositoryProvider);
  return MissionViewModel(repository: repository);
});
