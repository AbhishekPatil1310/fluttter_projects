import 'package:flutter/material.dart';

import '../../../domain/entities/waypoint.dart';

/// Values entered in [WaypointEditDialog].
class WaypointEditResult {
  const WaypointEditResult({required this.altitude, required this.speed});

  final double altitude;
  final double speed;
}

/// Dialog for editing a waypoint's altitude and speed.
/// Pops with a [WaypointEditResult], or `null` when cancelled.
class WaypointEditDialog extends StatefulWidget {
  const WaypointEditDialog({
    super.key,
    required this.index,
    required this.waypoint,
  });

  final int index;
  final Waypoint waypoint;

  @override
  State<WaypointEditDialog> createState() => _WaypointEditDialogState();
}

class _WaypointEditDialogState extends State<WaypointEditDialog> {
  late final TextEditingController _altitude = TextEditingController(
    text: widget.waypoint.altitude.toString(),
  );
  late final TextEditingController _speed = TextEditingController(
    text: widget.waypoint.speed.toString(),
  );
  bool _invalid = false;

  @override
  void dispose() {
    _altitude.dispose();
    _speed.dispose();
    super.dispose();
  }

  void _apply() {
    final altitude = double.tryParse(_altitude.text);
    final speed = double.tryParse(_speed.text);

    if (altitude == null || speed == null) {
      setState(() => _invalid = true);
      return;
    }
    Navigator.pop(
      context,
      WaypointEditResult(altitude: altitude, speed: speed),
    );
  }

  @override
  Widget build(BuildContext context) {
    const numeric = TextInputType.numberWithOptions(decimal: true);

    return AlertDialog(
      title: Text('Edit Waypoint ${widget.index + 1}'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _altitude,
            keyboardType: numeric,
            decoration: const InputDecoration(labelText: 'Altitude (m)'),
          ),
          TextField(
            controller: _speed,
            keyboardType: numeric,
            decoration: const InputDecoration(labelText: 'Speed (m/s)'),
          ),
          if (_invalid) ...[
            const SizedBox(height: 12),
            Text(
              'Enter valid altitude and speed values.',
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(onPressed: _apply, child: const Text('Apply')),
      ],
    );
  }
}
