import 'dart:math' as math;

import 'package:flutter_riverpod/legacy.dart';
import 'package:latlong2/latlong.dart';

import '../../../domain/entities/waypoint.dart';
import '../../../domain/repositories/mission_repository.dart';
import '../../../domain/services/route_calculator.dart';
import '../state/mission_state.dart';

/// Presentation logic for mission editing.
///
/// The repository is injected by the presentation provider. This class does
/// not resolve Riverpod providers and does not depend on [Ref].
class MissionViewModel extends StateNotifier<MissionState> {
  MissionViewModel({required MissionRepository repository})
      : _repository = repository,
        super(_initialState(repository));

  final MissionRepository _repository;

  static MissionState _initialState(MissionRepository repository) =>
      _withWaypoints(const MissionState(), repository.waypoints);

  void addWaypoint(LatLng position) {
    _commit([...state.waypoints, Waypoint(position: position)]);
  }

  void updateWaypoint(int index, {double? altitude, double? speed}) {
    if (!_isValidIndex(index)) return;
    final next = [...state.waypoints]
      ..[index] = state.waypoints[index].copyWith(
        altitude: altitude,
        speed: speed,
      );
    _commit(next);
  }

  void removeWaypoint(int index) {
    if (!_isValidIndex(index)) return;
    _commit([...state.waypoints]..removeAt(index));
  }

  void reorderWaypoint(int oldIndex, int newIndex) {
    if (!_isValidIndex(oldIndex)) return;
    final next = [...state.waypoints];
    final item = next.removeAt(oldIndex);
    final adjusted = newIndex > oldIndex ? newIndex - 1 : newIndex;
    next.insert(math.min(math.max(adjusted, 0), next.length), item);
    _commit(next);
  }

  Future<void> saveMission() async {
    state = state.copyWith(busy: true, clearError: true, clearMessage: true);
    try {
      final saved = await _repository.save();
      state = state.copyWith(
        message: saved ? 'Mission saved.' : 'Save cancelled.',
      );
    } catch (e) {
      final error = 'Unable to save mission: $e';
      state = state.copyWith(error: error, message: error);
    } finally {
      state = state.copyWith(busy: false);
    }
  }

  Future<void> loadMission() async {
    state = state.copyWith(busy: true, clearError: true, clearMessage: true);
    try {
      final loaded = await _repository.load();
      if (loaded == null) {
        state = state.copyWith(message: 'No mission file selected.');
      } else {
        state = _withWaypoints(state, loaded).copyWith(
          message: 'Mission loaded.',
        );
      }
    } on FormatException {
      const error = 'Invalid mission JSON';
      state = state.copyWith(error: error, message: error);
    } catch (e) {
      final error = 'Unable to load mission: $e';
      state = state.copyWith(error: error, message: error);
    } finally {
      state = state.copyWith(busy: false);
    }
  }

  void clearMessage() => state = state.copyWith(clearMessage: true);

  bool _isValidIndex(int index) =>
      index >= 0 && index < state.waypoints.length;

  void _commit(List<Waypoint> waypoints) {
    _repository.replace(waypoints);
    state = _withWaypoints(state, waypoints);
  }

  static MissionState _withWaypoints(
    MissionState base,
    List<Waypoint> waypoints,
  ) {
    final metrics = RouteCalculator.calculate(waypoints);
    return base.copyWith(
      waypoints: List.unmodifiable(waypoints),
      totalDistanceKm: metrics.distanceKm,
      estimatedMinutes: metrics.estimatedMinutes,
    );
  }
}
