import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/mission_providers.dart';
import '../widgets/mission_map.dart';
import '../widgets/waypoint_edit_dialog.dart';
import '../widgets/waypoint_panel.dart';

/// Renders the mission state: map on the left, waypoint panel on the right.
class MissionScreen extends ConsumerWidget {
  const MissionScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(missionViewModelProvider);
    final viewModel = ref.read(missionViewModelProvider.notifier);

    ref.listen<String?>(
      missionViewModelProvider.select((s) => s.message),
      (previous, message) {
        if (message == null) return;
        viewModel.clearMessage();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(message)),
        );
      },
    );

    Future<void> editWaypoint(int index) async {
      if (index < 0 || index >= state.waypoints.length) return;

      final result = await showDialog<WaypointEditResult>(
        context: context,
        builder: (_) => WaypointEditDialog(
          index: index,
          waypoint: state.waypoints[index],
        ),
      );

      if (result != null) {
        viewModel.updateWaypoint(
          index,
          altitude: result.altitude,
          speed: result.speed,
        );
      }
    }

    return Scaffold(
      body: Row(
        children: [
          Expanded(
            child: MissionMap(
              waypoints: state.waypoints,
              onMapTap: viewModel.addWaypoint,
              onWaypointTap: editWaypoint,
            ),
          ),
          WaypointPanel(
            waypoints: state.waypoints,
            totalDistanceKm: state.totalDistanceKm,
            estimatedMinutes: state.estimatedMinutes,
            busy: state.busy,
            error: state.error,
            onEdit: editWaypoint,
            onRemove: viewModel.removeWaypoint,
            onReorder: viewModel.reorderWaypoint,
            onSave: viewModel.saveMission,
            onLoad: viewModel.loadMission,
          ),
        ],
      ),
    );
  }
}
