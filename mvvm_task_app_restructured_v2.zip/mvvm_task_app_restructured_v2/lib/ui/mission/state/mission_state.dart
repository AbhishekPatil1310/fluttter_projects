import '../../../domain/entities/waypoint.dart';

class MissionState {
  const MissionState({
    this.waypoints = const [],
    this.totalDistanceKm = 0,
    this.estimatedMinutes = 0,
    this.busy = false,
    this.error,
    this.message,
  });

  final List<Waypoint> waypoints;
  final double totalDistanceKm;
  final double estimatedMinutes;
  final bool busy;

  /// Last error, shown in the waypoint panel.
  final String? error;

  /// One-shot feedback the screen should show in a snackbar.
  final String? message;

  MissionState copyWith({
    List<Waypoint>? waypoints,
    double? totalDistanceKm,
    double? estimatedMinutes,
    bool? busy,
    String? error,
    bool clearError = false,
    String? message,
    bool clearMessage = false,
  }) =>
      MissionState(
        waypoints: waypoints ?? this.waypoints,
        totalDistanceKm: totalDistanceKm ?? this.totalDistanceKm,
        estimatedMinutes: estimatedMinutes ?? this.estimatedMinutes,
        busy: busy ?? this.busy,
        error: clearError ? null : (error ?? this.error),
        message: clearMessage ? null : (message ?? this.message),
      );
}
