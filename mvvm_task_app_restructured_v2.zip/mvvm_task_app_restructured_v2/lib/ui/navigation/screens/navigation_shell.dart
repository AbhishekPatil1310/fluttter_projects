import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../alerts/screens/alerts_screen.dart';
import '../../dashboard/screens/dashboard_screen.dart';
import '../../logs/screens/logs_screen.dart';
import '../../mission/screens/mission_screen.dart';
import '../../settings/screens/settings_screen.dart';
import '../providers/navigation_providers.dart';

class _Destination {
  const _Destination({
    required this.title,
    required this.label,
    required this.icon,
    required this.page,
  });

  final String title;
  final String label;
  final IconData icon;
  final Widget page;
}

class NavigationShell extends ConsumerWidget {
  const NavigationShell({super.key});

  static const _destinations = [
    _Destination(
      title: 'DASHBOARD',
      label: 'Dashboard',
      icon: Icons.dashboard_outlined,
      page: DashboardScreen(),
    ),
    _Destination(
      title: 'MISSION PLANNER',
      label: 'Mission',
      icon: Icons.route_outlined,
      page: MissionScreen(),
    ),
    _Destination(
      title: 'ALERT CENTER',
      label: 'Alerts',
      icon: Icons.warning_amber_outlined,
      page: AlertsScreen(),
    ),
    _Destination(
      title: 'SYSTEM LOGS',
      label: 'Logs',
      icon: Icons.list_alt,
      page: LogsScreen(),
    ),
    _Destination(
      title: 'SETTINGS',
      label: 'Settings',
      icon: Icons.settings_outlined,
      page: SettingsScreen(),
    ),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedIndex = ref.watch(navigationViewModelProvider);
    final viewModel = ref.read(navigationViewModelProvider.notifier);

    return Scaffold(
      appBar: AppBar(
        title: Text('NOMAD / ${_destinations[selectedIndex].title}'),
      ),
      body: IndexedStack(
        index: selectedIndex,
        children: [for (final destination in _destinations) destination.page],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: viewModel.select,
        destinations: [
          for (final destination in _destinations)
            NavigationDestination(
              icon: Icon(destination.icon),
              label: destination.label,
            ),
        ],
      ),
    );
  }
}
