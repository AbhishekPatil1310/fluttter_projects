import 'package:flutter_riverpod/legacy.dart';

import '../view_models/navigation_view_model.dart';

/// Navigation is UI-local state, so this ViewModel needs no dependencies.
final navigationViewModelProvider =
    StateNotifierProvider<NavigationViewModel, int>(
  (ref) => NavigationViewModel(),
);
