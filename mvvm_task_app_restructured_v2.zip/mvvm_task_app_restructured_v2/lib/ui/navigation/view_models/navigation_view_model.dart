import 'package:flutter_riverpod/legacy.dart';

/// UI-local presentation state. It has no external dependencies.
class NavigationViewModel extends StateNotifier<int> {
  NavigationViewModel() : super(0);

  void select(int index) {
    if (state == index) return;
    state = index;
  }
}
