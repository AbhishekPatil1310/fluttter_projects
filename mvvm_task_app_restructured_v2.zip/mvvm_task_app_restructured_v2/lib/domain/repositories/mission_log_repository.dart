import '../entities/mission_log.dart';

/// Read-only access to the mission event history.
abstract interface class MissionLogRepository {
  /// Mission event history, newest first.
  List<MissionLog> get history;

  /// Emits the full history every time it changes.
  Stream<List<MissionLog>> get historyStream;
}
