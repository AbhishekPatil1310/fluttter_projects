import '../entities/telemetry.dart';

/// Domain abstraction for consuming vehicle telemetry.
///
/// Presentation code depends on this contract, not on UDP, sockets,
/// mappers, or concrete repositories.
abstract interface class TelemetryRepository {
  Stream<Telemetry> watchTelemetry();
}
