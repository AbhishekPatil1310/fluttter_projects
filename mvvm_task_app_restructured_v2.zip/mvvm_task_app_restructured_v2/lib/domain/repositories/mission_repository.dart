import '../entities/waypoint.dart';

/// What the UI layer may request about the mission plan.
abstract interface class MissionRepository {
  List<Waypoint> get waypoints;

  void replace(List<Waypoint> waypoints);

  /// Returns `false` when the user cancelled the save dialog.
  Future<bool> save();

  /// Returns `null` when the user cancelled the open dialog.
  /// Throws [FormatException] when the file is not a valid mission.
  Future<List<Waypoint>?> load();
}
