/// Commands the UI may send to the vehicle.
abstract interface class VehicleControlRepository {
  void setArmed(bool armed);
}
