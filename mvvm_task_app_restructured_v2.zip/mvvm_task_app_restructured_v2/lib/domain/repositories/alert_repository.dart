import '../entities/alert.dart';

/// What the UI layer may request about alerts.
abstract interface class AlertRepository {
  /// Alert history, newest first.
  List<Alert> get history;

  /// Emits the full history every time it changes.
  Stream<List<Alert>> get historyStream;

  /// Records a new alert and returns it.
  Alert emit(String message, AlertLevel level);

  /// Marks the alert with [id] as acknowledged. Unknown ids are ignored.
  void acknowledge(String id);
}
