import 'package:latlong2/latlong.dart';

class Telemetry {
  const Telemetry({
    required this.battery,
    required this.satellites,
    required this.connection,
    required this.speed,
    required this.heading,
    required this.armed,
    required this.position,
    required this.timestamp,
  });

  /// Vehicle state before the first telemetry packet arrives.
  factory Telemetry.initial({DateTime? timestamp}) => Telemetry(
        battery: 76,
        satellites: 14,
        connection: 90,
        speed: 0,
        heading: 84,
        armed: false,
        position: const LatLng(18.01915726783933, 77.00772518934573),
        timestamp: timestamp ?? DateTime.now(),
      );

  final int battery;
  final int satellites;
  final int connection;
  final double speed;
  final int heading;
  final bool armed;
  final LatLng position;
  final DateTime timestamp;

  Telemetry copyWith({
    int? battery,
    int? satellites,
    int? connection,
    double? speed,
    int? heading,
    bool? armed,
    LatLng? position,
    DateTime? timestamp,
  }) =>
      Telemetry(
        battery: battery ?? this.battery,
        satellites: satellites ?? this.satellites,
        connection: connection ?? this.connection,
        speed: speed ?? this.speed,
        heading: heading ?? this.heading,
        armed: armed ?? this.armed,
        position: position ?? this.position,
        timestamp: timestamp ?? this.timestamp,
      );
}
