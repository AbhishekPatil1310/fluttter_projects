enum AlertLevel { info, warning, critical, emergency }

class Alert {
  const Alert({
    required this.id,
    required this.message,
    required this.level,
    required this.timestamp,
    this.acknowledged = false,
  });

  /// Stable identity, so an alert can be acknowledged even after the
  /// history list has shifted.
  final String id;
  final String message;
  final AlertLevel level;
  final DateTime timestamp;
  final bool acknowledged;

  /// Critical and emergency alerts must be explicitly acknowledged.
  bool get requiresAcknowledgement => level.index >= AlertLevel.critical.index;

  Alert copyWith({bool? acknowledged}) => Alert(
        id: id,
        message: message,
        level: level,
        timestamp: timestamp,
        acknowledged: acknowledged ?? this.acknowledged,
      );
}
