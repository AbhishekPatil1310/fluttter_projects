import 'package:latlong2/latlong.dart';

class Waypoint {
  Waypoint({
    required this.position,
    this.altitude = 30,
    this.speed = 2,
    String? id,
  }) : id = id ?? _generateId();

  static int _counter = 0;
  static String _generateId() => 'wp-${_counter++}';

  /// Stable identity used as a list key, so reorder/remove animations and
  /// dismissals stay attached to the right waypoint.
  final String id;
  final LatLng position;
  final double altitude;
  final double speed;

  Waypoint copyWith({LatLng? position, double? altitude, double? speed}) =>
      Waypoint(
        id: id,
        position: position ?? this.position,
        altitude: altitude ?? this.altitude,
        speed: speed ?? this.speed,
      );
}
