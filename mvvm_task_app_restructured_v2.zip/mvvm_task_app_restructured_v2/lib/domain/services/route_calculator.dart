import 'package:latlong2/latlong.dart';

import '../entities/waypoint.dart';

/// Distance and estimated travel time for a waypoint route.
class RouteMetrics {
  const RouteMetrics({required this.distanceKm, required this.estimatedMinutes});

  static const empty = RouteMetrics(distanceKm: 0, estimatedMinutes: 0);

  final double distanceKm;
  final double estimatedMinutes;
}

/// Pure mission-planning math, kept out of the view model.
abstract final class RouteCalculator {
  static const _distance = Distance();

  static RouteMetrics calculate(List<Waypoint> waypoints) {
    if (waypoints.length < 2) return RouteMetrics.empty;

    var totalKm = 0.0;
    for (var i = 1; i < waypoints.length; i++) {
      totalKm += _distance.as(
        LengthUnit.Kilometer,
        waypoints[i - 1].position,
        waypoints[i].position,
      );
    }

    final averageSpeed =
        waypoints.fold<double>(0, (sum, item) => sum + item.speed) /
            waypoints.length;
    if (averageSpeed <= 0) {
      return RouteMetrics(distanceKm: totalKm, estimatedMinutes: 0);
    }
    return RouteMetrics(
      distanceKm: totalKm,
      estimatedMinutes: (totalKm * 1000 / averageSpeed) / 60,
    );
  }
}
