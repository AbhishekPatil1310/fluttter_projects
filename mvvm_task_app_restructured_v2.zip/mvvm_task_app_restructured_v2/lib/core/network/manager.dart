import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import '../config/telemetry_config.dart';

/// Owns the application's UDP connection.
///
/// This class knows only about UDP transport. It does not parse telemetry,
/// create domain entities, or contain UI/application state.
class Manager {
  Manager({
    InternetAddress? host,
    int port = TelemetryConfig.port,
  })  : _host = host ?? TelemetryConfig.host,
        _port = port;

  final InternetAddress _host;
  final int _port;

  final StreamController<Uint8List> _dataController =
      StreamController<Uint8List>.broadcast();

  RawDatagramSocket? _socket;
  StreamSubscription<RawSocketEvent>? _subscription;
  InternetAddress? _lastSenderAddress;
  int? _lastSenderPort;
  bool _connecting = false;

  Stream<Uint8List> get dataStream => _dataController.stream;

  bool get isConnected => _socket != null;

  Future<void> connect() async {
    if (_socket != null || _connecting) return;

    _connecting = true;
    try {
      final socket = await RawDatagramSocket.bind(_host, _port);
      _socket = socket;

      _subscription = socket.listen((event) {
        if (event != RawSocketEvent.read) return;

        Datagram? datagram;
        while ((datagram = socket.receive()) != null) {
          final packet = datagram!;
          _lastSenderAddress = packet.address;
          _lastSenderPort = packet.port;

          if (!_dataController.isClosed) {
            _dataController.add(Uint8List.fromList(packet.data));
          }
        }
      });
    } finally {
      _connecting = false;
    }
  }

  /// Sends a command to the most recent UDP producer.
  Future<bool> sendCommand(Map<String, Object?> command) async {
    final socket = _socket;
    final address = _lastSenderAddress;
    final port = _lastSenderPort;

    if (socket == null || address == null || port == null) {
      return false;
    }

    final payload = utf8.encode(jsonEncode(command));
    socket.send(payload, address, port);
    return true;
  }

  Future<void> dispose() async {
    await _subscription?.cancel();
    _subscription = null;
    _socket?.close();
    _socket = null;

    if (!_dataController.isClosed) {
      await _dataController.close();
    }
  }
}
