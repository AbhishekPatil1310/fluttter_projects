import 'dart:io';

/// Configuration for the external telemetry producer.
///
/// The Flutter application is the UDP consumer. The mock/vehicle producer
/// sends telemetry datagrams to this endpoint.
abstract final class TelemetryConfig {
  static final InternetAddress host = InternetAddress.loopbackIPv4;
  static const int port = 5001;
}
