import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'config/app_config.dart';
import 'ui/navigation/screens/navigation_shell.dart';
import 'ui/settings/providers/settings_providers.dart';

void main() {
  runApp(const ProviderScope(child: NomadControlApp()));
}

class NomadControlApp extends ConsumerWidget {
  const NomadControlApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final highContrast = ref.watch(
      settingsViewModelProvider.select((s) => s.highContrast),
    );

    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      theme: AppConfig.theme(highContrast: highContrast),
      home: const NavigationShell(),
    );
  }
}
