import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core_providers.dart';
import '../data/mappers/telemetry_mapper.dart'; // Import TelemetryMapper
import '../data/providers/telemetry_data_provider.dart';
import '../data/repositories/alert_repository_impl.dart';
import '../data/repositories/mission_repository_impl.dart';
import '../data/repositories/telemetry_repository_impl.dart';
import '../data/repositories/vehicle_control_repository_impl.dart';
import '../data/services/file_selector_file_service.dart';
import '../data/services/file_service.dart';
import '../domain/entities/telemetry.dart';
import '../domain/repositories/alert_repository.dart';
import '../domain/repositories/mission_log_repository.dart';
import '../domain/repositories/mission_repository.dart';
import '../domain/repositories/telemetry_repository.dart';
import '../domain/repositories/vehicle_control_repository.dart';

// =========================
// MAPPERS
// =========================

final telemetryMapperProvider = Provider<TelemetryMapper>((ref) {
  return TelemetryMapper();
});

// =========================
// DOMAIN REPOSITORIES
// =========================

/// Telemetry Repository Interface Provider
final telemetryRepositoryProvider = Provider<TelemetryRepository>((ref) {
  return TelemetryRepositoryImpl(
    manager: ref.watch(managerProvider),
    mapper: ref.watch(telemetryMapperProvider),
  );
});

// =========================
// DOMAIN REPOSITORY STREAMS
// =========================

/// Stream provider used by presentation.
///
/// The provider depends on the domain repository abstraction, not on the
/// concrete data repository or the UDP manager.
final telemetryRepositoryStreamProvider = StreamProvider<Telemetry>((ref) {
  final repository = ref.watch(telemetryRepositoryProvider);
  return repository.watchTelemetry();
});

// =========================
// OTHER REPOSITORIES
// =========================

final vehicleControlRepositoryProvider =
    Provider<VehicleControlRepository>((ref) {
  return VehicleControlRepositoryImpl(ref.watch(managerProvider));
});

final fileServiceProvider =
    Provider<FileService>((ref) => FileSelectorFileService());

final alertRepositoryProvider = Provider<AlertRepository>((ref) {
  final repository = AlertRepositoryImpl();
  ref.onDispose(repository.dispose);
  return repository;
});

final _missionRepositoryImplProvider = Provider<MissionRepositoryImpl>((ref) {
  final repository = MissionRepositoryImpl(ref.watch(fileServiceProvider));
  ref.onDispose(repository.dispose);
  return repository;
});

final missionRepositoryProvider = Provider<MissionRepository>(
  (ref) => ref.watch(_missionRepositoryImplProvider),
);

final missionLogRepositoryProvider = Provider<MissionLogRepository>(
  (ref) => ref.watch(_missionRepositoryImplProvider),
);