import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/network/manager.dart';
import '../data/mappers/telemetry_mapper.dart';

/// DI provider for the transport manager.
///
/// The manager owns the UDP socket and exposes raw datagrams. It knows
/// nothing about telemetry fields or presentation state.
final managerProvider = Provider<Manager>((ref) {
  final manager = Manager();
  unawaited(manager.connect());
  ref.onDispose(manager.dispose);
  return manager;
});

/// DI provider for the data-layer mapper.
final telemetryMapperProvider = Provider<TelemetryMapper>(
  (ref) => TelemetryMapper(),
);
