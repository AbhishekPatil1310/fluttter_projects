import 'package:flutter/foundation.dart';

import '../../core/network/manager.dart';
import '../../domain/entities/telemetry.dart';
import '../../domain/repositories/telemetry_repository.dart';
import '../mappers/telemetry_mapper.dart';


class TelemetryRepositoryImpl implements TelemetryRepository {
  TelemetryRepositoryImpl({
    required Manager manager,
    required TelemetryMapper mapper,
  })  : _manager = manager,
        _mapper = mapper;

  final Manager _manager;
  final TelemetryMapper _mapper;

  @override
  Stream<Telemetry> watchTelemetry() {
    return _manager.dataStream.map((bytes) {
      try {
        return _mapper.map(bytes);
      } catch (error, stackTrace) {
        debugPrint('Failed to map telemetry packet: $error\n$stackTrace');
        rethrow;
      }
    });
  }
}
