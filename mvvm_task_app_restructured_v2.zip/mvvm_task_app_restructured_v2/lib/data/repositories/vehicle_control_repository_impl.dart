import '../../core/network/manager.dart';
import '../../domain/repositories/vehicle_control_repository.dart';

/// Sends vehicle commands through the transport manager.
class VehicleControlRepositoryImpl implements VehicleControlRepository {
  const VehicleControlRepositoryImpl(this._manager);

  final Manager _manager;

  @override
  void setArmed(bool armed) {
    _manager.sendCommand({
      'type': 'vehicle_command',
      'command': 'set_armed',
      'armed': armed,
    });
  }
}
