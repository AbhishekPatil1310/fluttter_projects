import 'dart:async';

import '../../domain/entities/mission_log.dart';
import '../../domain/entities/waypoint.dart';
import '../../domain/repositories/mission_log_repository.dart';
import '../../domain/repositories/mission_repository.dart';
import '../mappers/waypoint_mapper.dart';
import '../services/file_service.dart';

/// Holds the mission plan and records save/load events. Implements both the
/// plan interface and the read-only log interface, so consumers depend only
/// on the part they need.
class MissionRepositoryImpl implements MissionRepository, MissionLogRepository {
  MissionRepositoryImpl(this._fileService);

  static const _maxHistory = 100;

  final FileService _fileService;
  final List<MissionLog> _history = [];
  final _controller = StreamController<List<MissionLog>>.broadcast();
  List<Waypoint> _waypoints = const [];

  @override
  List<Waypoint> get waypoints => List.unmodifiable(_waypoints);

  @override
  List<MissionLog> get history => List.unmodifiable(_history);

  @override
  Stream<List<MissionLog>> get historyStream => _controller.stream;

  /// Editing the plan is not logged; only save/load are mission events.
  @override
  void replace(List<Waypoint> waypoints) {
    _waypoints = List.unmodifiable(waypoints);
  }

  @override
  Future<bool> save() async {
    final saved = await _fileService.saveMission(
      WaypointMapper.encode(_waypoints),
    );
    if (saved) {
      _record(
        MissionLogType.missionSaved,
        'Mission saved (${_waypoints.length} waypoints)',
      );
    }
    return saved;
  }

  @override
  Future<List<Waypoint>?> load() async {
    final contents = await _fileService.loadMission();
    if (contents == null) return null;

    final loaded = WaypointMapper.decode(contents);
    _waypoints = List.unmodifiable(loaded);
    _record(
      MissionLogType.missionLoaded,
      'Mission loaded (${loaded.length} waypoints)',
    );
    return _waypoints;
  }

  void _record(MissionLogType type, String message) {
    _history.insert(
      0,
      MissionLog(message: message, type: type, timestamp: DateTime.now()),
    );
    if (_history.length > _maxHistory) _history.removeLast();
    if (!_controller.isClosed) _controller.add(history);
  }

  void dispose() => _controller.close();
}
