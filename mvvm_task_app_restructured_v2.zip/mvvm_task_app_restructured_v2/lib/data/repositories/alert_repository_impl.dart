import 'dart:async';

import '../../domain/entities/alert.dart';
import '../../domain/repositories/alert_repository.dart';

/// Keeps the alert history in memory (most recent 10 alerts).
class AlertRepositoryImpl implements AlertRepository {
  static const _maxEntries = 15;

  final List<Alert> _history = [];
  final _controller = StreamController<List<Alert>>.broadcast();
  int _nextId = 0;

  /// What alerts exist right now.
  @override
  List<Alert> get history => List.unmodifiable(_history);

  /// What alert updates happen from now on.
  @override
  Stream<List<Alert>> get historyStream => _controller.stream;

  @override
  Alert emit(String message, AlertLevel level) {
    final alert = Alert(
      id: 'alert-${_nextId++}',
      message: message,
      level: level,
      timestamp: DateTime.now(),
    );
    _history.insert(0, alert);
    if (_history.length > _maxEntries) _history.removeLast();
    _publish();
    return alert;
  }

  @override
  void acknowledge(String id) {
    final index = _history.indexWhere((alert) => alert.id == id);
    if (index == -1) return;
    _history[index] = _history[index].copyWith(acknowledged: true);
    _publish();
  }

  void _publish() {
    if (!_controller.isClosed) _controller.add(history);
  }

  void dispose() => _controller.close();
}
