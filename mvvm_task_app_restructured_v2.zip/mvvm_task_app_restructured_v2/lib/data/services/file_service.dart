/// Raw file access for missions. Knows nothing about waypoints or JSON:
/// it only picks a file and reads/writes its text contents.
abstract interface class FileService {
  /// Asks the user where to save and writes [contents].
  /// Returns `false` if the user cancelled.
  Future<bool> saveMission(String contents);

  /// Asks the user to pick a mission file and returns its text,
  /// or `null` if the user cancelled.
  Future<String?> loadMission();
}
