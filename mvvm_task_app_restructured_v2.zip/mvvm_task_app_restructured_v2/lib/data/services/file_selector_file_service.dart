import 'dart:io';

import 'package:file_selector/file_selector.dart';

import 'file_service.dart';

/// [FileService] backed by the desktop file picker and `dart:io`.
class FileSelectorFileService implements FileService {
  static const _missionTypeGroup = XTypeGroup(
    label: 'Mission JSON',
    extensions: ['json'],
  );

  @override
  Future<bool> saveMission(String contents) async {
    final location = await getSaveLocation(
      suggestedName: 'nomad_mission.json',
      acceptedTypeGroups: const [_missionTypeGroup],
    );
    if (location == null) return false;
    await File(location.path).writeAsString(contents);
    return true;
  }

  @override
  Future<String?> loadMission() async {
    final file = await openFile(
      acceptedTypeGroups: const [_missionTypeGroup],
    );
    if (file == null) return null;
    return file.readAsString();
  }
}
