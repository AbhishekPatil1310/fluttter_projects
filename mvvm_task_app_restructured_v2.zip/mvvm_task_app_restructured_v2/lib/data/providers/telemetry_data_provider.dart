import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../di/core_providers.dart';
import '../../domain/repositories/telemetry_repository.dart';
import '../repositories/telemetry_repository_impl.dart';

/// Data-layer dependency provider.
///
/// This provider receives the transport manager and mapper through the DI
/// layer and constructs the concrete repository. No presentation code
/// depends on this concrete implementation.
final telemetryRepositoryProvider = Provider<TelemetryRepository>((ref) {
  final manager = ref.watch(managerProvider);
  final mapper = ref.watch(telemetryMapperProvider);

  return TelemetryRepositoryImpl(
    manager: manager,
    mapper: mapper,
  );
});
