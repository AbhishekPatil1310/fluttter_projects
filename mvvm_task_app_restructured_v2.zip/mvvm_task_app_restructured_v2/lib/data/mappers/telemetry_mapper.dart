import 'dart:convert';
import 'dart:typed_data';

import 'package:latlong2/latlong.dart';

import '../../domain/entities/telemetry.dart';

/// Converts the transport representation (UDP JSON bytes) into a domain
/// telemetry entity. No socket/network code belongs here.
class TelemetryMapper {
  Telemetry map(Uint8List bytes) {
    final decoded = jsonDecode(utf8.decode(bytes));
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('Telemetry payload must be a JSON object.');
    }

    final position = decoded['position'];
    final latitude = position is Map<String, dynamic>
        ? position['latitude']
        : decoded['latitude'];
    final longitude = position is Map<String, dynamic>
        ? position['longitude']
        : decoded['longitude'];

    return Telemetry(
      battery: _int(decoded['battery'], 'battery'),
      satellites: _int(decoded['satellites'], 'satellites'),
      connection: _int(decoded['connection'], 'connection'),
      speed: _double(decoded['speed'], 'speed'),
      heading: _int(decoded['heading'], 'heading'),
      armed: _bool(decoded['armed'], 'armed'),
      position: LatLng(
        _double(latitude, 'position.latitude'),
        _double(longitude, 'position.longitude'),
      ),
      timestamp: DateTime.tryParse('${decoded['timestamp']}') ?? DateTime.now(),
    );
  }

  int _int(Object? value, String field) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    throw FormatException('Telemetry field "$field" must be a number.');
  }

  double _double(Object? value, String field) {
    if (value is num) return value.toDouble();
    throw FormatException('Telemetry field "$field" must be a number.');
  }

  bool _bool(Object? value, String field) {
    if (value is bool) return value;
    throw FormatException('Telemetry field "$field" must be a boolean.');
  }
}
