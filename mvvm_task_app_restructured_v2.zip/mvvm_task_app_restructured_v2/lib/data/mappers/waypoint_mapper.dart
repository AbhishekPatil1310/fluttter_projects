import 'dart:convert';

import 'package:latlong2/latlong.dart';

import '../../domain/entities/waypoint.dart';

/// Converts waypoints to and from the mission file JSON format, keeping
/// serialization out of the domain entity.
abstract final class WaypointMapper {
  static String encode(List<Waypoint> waypoints) {
    return const JsonEncoder.withIndent('  ').convert(
      waypoints
          .map(
            (waypoint) => {
              'lat': waypoint.position.latitude,
              'lng': waypoint.position.longitude,
              'altitude': waypoint.altitude,
              'speed': waypoint.speed,
            },
          )
          .toList(),
    );
  }

  /// Throws [FormatException] if [source] is not a valid mission file.
  static List<Waypoint> decode(String source) {
    try {
      final decoded = jsonDecode(source) as List<dynamic>;
      return decoded.map((item) {
        final json = item as Map<String, dynamic>;
        return Waypoint(
          position: LatLng(
            (json['lat'] as num).toDouble(),
            (json['lng'] as num).toDouble(),
          ),
          altitude: (json['altitude'] as num).toDouble(),
          speed: (json['speed'] as num).toDouble(),
        );
      }).toList();
    } on FormatException {
      rethrow;
    } catch (_) {
      throw const FormatException('Invalid mission file');
    }
  }
}
