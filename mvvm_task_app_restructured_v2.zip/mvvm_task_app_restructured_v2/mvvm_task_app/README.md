# NOMAD / UGV Control (mvvm_task_app)

Flutter UGV field-operations console, structured with **MVVM** + **Riverpod**
dependency injection, following SOLID principles.

## Structure

```
lib/
  main.dart                     ProviderScope + MaterialApp
  config/app_config.dart
  routing/app_router.dart
  di/injection_container.dart   Riverpod providers = dependency injection
  domain/
    entities/                   alert, telemetry, mission_log, waypoint
    repositories/               interfaces the UI may request
  data/
    services/                   telemetry_service (mock server), file_service (I/O)
    mappers/                    waypoint_mapper (JSON <-> Waypoint)
    repositories/               *_repository_impl (alert, mission, telemetry)
  ui/
    core/                       shared widgets and helpers
    <feature>/                  dashboard, mission, alerts, logs, settings, navigation
      providers/                UI-layer providers: DI repositories -> view model
      view_models/              business logic; exposes an immutable State
      screens/                  render the state, compose widgets
      widgets/                  small, dumb, reusable sub-parts
```

Dashboard screen composes only `ControlInput`, `LiveMap` and `TelemetryTab`.

## Dependency flow

`screen -> view model -> domain repository interface <- data repository impl -> service`

- Screens `ref.watch` the view model's state and call its methods.
- `ui/<feature>/providers/*` read repositories from `di/injection_container.dart`
  and inject them into the view model.
- View models depend only on domain interfaces, never on `data/`.

## SOLID

- **S** - services do I/O, mappers serialize, repositories coordinate, view models hold logic, widgets draw.
- **O** - swap a data source by overriding a provider; no other code changes.
- **L** - any `TelemetryRepository`/`AlertRepository`/`MissionRepository` implementation is substitutable (see `test/fakes`).
- **I** - three small, focused repository interfaces.
- **D** - upper layers depend on domain abstractions; DI wires implementations.

## Run / test

```
flutter pub get
flutter run -d linux
flutter test
```
