import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mvvm_task_app/ui/dashboard/widgets/control_input.dart';

void main() {
  Widget host({required bool armed, required bool online, VoidCallback? onArm}) {
    return MaterialApp(
      home: Scaffold(
        body: SizedBox(
          height: 400,
          width: 300,
          child: ControlInput(
            isArmed: armed,
            isOnline: online,
            onArm: onArm ?? () {},
            onDisarm: () {},
          ),
        ),
      ),
    );
  }

  testWidgets('shows online status and lets you arm when disarmed',
      (tester) async {
    var armed = false;
    await tester.pumpWidget(
      host(armed: false, online: true, onArm: () => armed = true),
    );

    expect(find.text('Vehicle online'), findsOneWidget);
    await tester.tap(find.text('ARM VEHICLE'));
    expect(armed, isTrue);
  });

  testWidgets('shows offline status', (tester) async {
    await tester.pumpWidget(host(armed: true, online: false));
    expect(find.text('Vehicle offline'), findsOneWidget);
  });
}
