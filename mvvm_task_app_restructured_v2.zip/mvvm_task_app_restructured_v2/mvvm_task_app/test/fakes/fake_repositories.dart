import 'dart:async';

import 'package:mvvm_task_app/domain/entities/alert.dart';
import 'package:mvvm_task_app/domain/entities/mission_log.dart';
import 'package:mvvm_task_app/domain/entities/telemetry.dart';
import 'package:mvvm_task_app/domain/entities/waypoint.dart';
import 'package:mvvm_task_app/domain/repositories/alert_repository.dart';
import 'package:mvvm_task_app/domain/repositories/mission_repository.dart';
import 'package:mvvm_task_app/domain/repositories/telemetry_repository.dart';

class FakeTelemetryRepository implements TelemetryRepository {
  final _controller = StreamController<Telemetry>.broadcast();
  Telemetry _latest = Telemetry.initial();

  @override
  Telemetry get latest => _latest;

  @override
  Stream<Telemetry> get stream => _controller.stream;

  @override
  void setArmed(bool armed) => push(_latest.copyWith(armed: armed));

  void push(Telemetry telemetry) {
    _latest = telemetry;
    _controller.add(telemetry);
  }
}

class FakeAlertRepository implements AlertRepository {
  final _controller = StreamController<List<Alert>>.broadcast();
  final List<Alert> _history = [];

  @override
  List<Alert> get history => List.unmodifiable(_history);

  @override
  Stream<List<Alert>> get historyStream => _controller.stream;

  @override
  Alert emit(String message, AlertLevel level) {
    final alert = Alert(
      message: message,
      level: level,
      timestamp: DateTime.now(),
    );
    _history.insert(0, alert);
    _controller.add(history);
    return alert;
  }

  @override
  void acknowledge(int index) {
    _history[index] = _history[index].copyWith(acknowledged: true);
    _controller.add(history);
  }
}

class FakeMissionRepository implements MissionRepository {
  final _controller = StreamController<List<MissionLog>>.broadcast();
  List<Waypoint> _waypoints = const [];
  List<Waypoint>? nextLoadResult;
  bool nextSaveResult = true;

  @override
  List<Waypoint> get waypoints => _waypoints;

  @override
  List<MissionLog> get history => const [];

  @override
  Stream<List<MissionLog>> get historyStream => _controller.stream;

  @override
  void replace(List<Waypoint> waypoints) => _waypoints = waypoints;

  @override
  Future<bool> save() async => nextSaveResult;

  @override
  Future<List<Waypoint>?> load() async {
    final result = nextLoadResult;
    if (result != null) _waypoints = result;
    return result;
  }
}
