import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'package:mvvm_task_app/di/injection_container.dart';
import 'package:mvvm_task_app/domain/entities/telemetry.dart';
import 'package:mvvm_task_app/ui/logs/providers/logs_providers.dart';
import 'package:mvvm_task_app/domain/entities/waypoint.dart';
import 'package:mvvm_task_app/ui/alerts/providers/alerts_providers.dart';
import 'package:mvvm_task_app/ui/dashboard/providers/dashboard_providers.dart';
import 'package:mvvm_task_app/ui/mission/providers/mission_providers.dart';

import 'fakes/fake_repositories.dart';

void main() {
  late FakeTelemetryRepository telemetry;
  late FakeAlertRepository alerts;
  late FakeMissionRepository missions;
  late ProviderContainer container;

  setUp(() {
    telemetry = FakeTelemetryRepository();
    alerts = FakeAlertRepository();
    missions = FakeMissionRepository();
    container = ProviderContainer(
      overrides: [
        telemetryRepositoryProvider.overrideWithValue(telemetry),
        alertRepositoryProvider.overrideWithValue(alerts),
        missionRepositoryProvider.overrideWithValue(missions),
      ],
    );
    addTearDown(container.dispose);
  });

  group('Dashboard providers', () {
    test('telemetry provider exposes the repository snapshot', () async {
      final subscription = container.listen(telemetryProvider, (_, __) {});
      addTearDown(subscription.close);
      await Future<void>.delayed(Duration.zero);

      expect(
        container.read(telemetryProvider).value?.connection,
        telemetry.latest.connection,
      );
    });

    test('arming command delegates to the repository', () async {
      container.read(setVehicleArmedProvider)(true);
      expect(telemetry.latest.armed, isTrue);
    });

    test('telemetry provider emits subsequent telemetry', () async {
      final subscription = container.listen(telemetryProvider, (_, __) {});
      addTearDown(subscription.close);
      await Future<void>.delayed(Duration.zero);

      telemetry.push(Telemetry.initial().copyWith(connection: 30));
      await Future<void>.delayed(Duration.zero);

      expect(container.read(telemetryProvider).value?.connection, 30);
    });
  });

  group('AlertsViewModel', () {
    test('critical alert becomes pending, warning becomes a notice', () {
      final viewModel = container.read(alertsViewModelProvider.notifier);

      viewModel.triggerLowBattery();
      var state = container.read(alertsViewModelProvider);
      expect(state.notice, 'Battery below 50%');
      expect(state.pendingCriticalAlert, isNull);

      viewModel.triggerGpsLost();
      state = container.read(alertsViewModelProvider);
      expect(state.pendingCriticalAlert?.message, 'GPS signal lost');

      viewModel.clearPendingCriticalAlert();
      expect(
        container.read(alertsViewModelProvider).pendingCriticalAlert,
        isNull,
      );
    });
  });

  group('MissionViewModel', () {
    const a = LatLng(18.0, 77.0);
    const b = LatLng(18.01, 77.01);
    const c = LatLng(18.02, 77.02);

    test('add, remove and metrics', () {
      final viewModel = container.read(missionViewModelProvider.notifier);
      viewModel.addWaypoint(a);
      viewModel.addWaypoint(b);

      var state = container.read(missionViewModelProvider);
      expect(state.waypoints.length, 2);
      expect(state.totalDistanceKm, greaterThan(0));
      expect(state.estimatedMinutes, greaterThan(0));

      viewModel.removeWaypoint(0);
      state = container.read(missionViewModelProvider);
      expect(state.waypoints.length, 1);
      expect(state.totalDistanceKm, 0);
    });

    test('reorder follows ReorderableListView convention', () {
      final viewModel = container.read(missionViewModelProvider.notifier);
      viewModel
        ..addWaypoint(a)
        ..addWaypoint(b)
        ..addWaypoint(c);

      // Drag first item to the end (newIndex == length).
      viewModel.reorderWaypoint(0, 3);
      final positions = container
          .read(missionViewModelProvider)
          .waypoints
          .map((w) => w.position)
          .toList();
      expect(positions, [b, c, a]);
    });

    test('load replaces waypoints and reports feedback', () async {
      missions.nextLoadResult = [const Waypoint(position: a)];
      final viewModel = container.read(missionViewModelProvider.notifier);

      await viewModel.loadMission();
      final state = container.read(missionViewModelProvider);
      expect(state.waypoints.length, 1);
      expect(state.message, 'Mission loaded.');
      expect(state.busy, isFalse);
    });

    test('cancelled save reports feedback', () async {
      missions.nextSaveResult = false;
      await container.read(missionViewModelProvider.notifier).saveMission();
      expect(
        container.read(missionViewModelProvider).message,
        'Save cancelled.',
      );
    });
  });
}
