import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../di/injection_container.dart';
import '../state/mission_state.dart';
import '../view_models/mission_view_model.dart';

/// UI-layer provider: takes the repository from the DI container and
/// injects it into the view model.
final missionViewModelProvider =
    NotifierProvider<MissionViewModel, MissionState>(
  () => MissionViewModel(missionRepository: missionRepositoryProvider),
);
