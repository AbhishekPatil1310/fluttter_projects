import 'dart:math' as math;

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:latlong2/latlong.dart';

import '../../../domain/entities/waypoint.dart';
import '../state/mission_state.dart';
import '../../../domain/repositories/mission_repository.dart';

class MissionViewModel extends Notifier<MissionState> {
  MissionViewModel({required Provider<MissionRepository> missionRepository})
      : _missionRepositoryProvider = missionRepository;

  final Provider<MissionRepository> _missionRepositoryProvider;
  late MissionRepository _repository;

  @override
  MissionState build() {
    _repository = ref.watch(_missionRepositoryProvider);
    return _withWaypoints(const MissionState(), _repository.waypoints);
  }

  void addWaypoint(LatLng position) {
    _commit([...state.waypoints, Waypoint(position: position)]);
  }

  void updateWaypoint(int index, {double? altitude, double? speed}) {
    if (!_isValidIndex(index)) return;
    final next = [...state.waypoints]..[index] = state.waypoints[index].copyWith(
        altitude: altitude,
        speed: speed,
      );
    _commit(next);
  }

  void removeWaypoint(int index) {
    if (!_isValidIndex(index)) return;
    _commit([...state.waypoints]..removeAt(index));
  }

  /// [newIndex] follows Flutter's `ReorderableListView` convention (it is
  /// expressed before the dragged item is removed from the list).
  void reorderWaypoint(int oldIndex, int newIndex) {
    if (!_isValidIndex(oldIndex)) return;
    final next = [...state.waypoints];
    final item = next.removeAt(oldIndex);
    final adjusted = newIndex > oldIndex ? newIndex - 1 : newIndex;
    next.insert(math.min(math.max(adjusted, 0), next.length), item);
    _commit(next);
  }

  Future<void> saveMission() async {
    state = state.copyWith(busy: true, clearError: true, clearMessage: true);
    try {
      final saved = await _repository.save();
      state = state.copyWith(
        message: saved ? 'Mission saved.' : 'Save cancelled.',
      );
    } catch (e) {
      final error = 'Unable to save mission: $e';
      state = state.copyWith(error: error, message: error);
    } finally {
      state = state.copyWith(busy: false);
    }
  }

  Future<void> loadMission() async {
    state = state.copyWith(busy: true, clearError: true, clearMessage: true);
    try {
      final loaded = await _repository.load();
      if (loaded == null) {
        state = state.copyWith(message: 'No mission file selected.');
      } else {
        state = _withWaypoints(state, loaded).copyWith(
          message: 'Mission loaded.',
        );
      }
    } on FormatException {
      const error = 'Invalid mission JSON';
      state = state.copyWith(error: error, message: error);
    } catch (e) {
      final error = 'Unable to load mission: $e';
      state = state.copyWith(error: error, message: error);
    } finally {
      state = state.copyWith(busy: false);
    }
  }

  void clearMessage() => state = state.copyWith(clearMessage: true);

  bool _isValidIndex(int index) => index >= 0 && index < state.waypoints.length;

  /// Applies a user edit: updates the repository and the state.
  void _commit(List<Waypoint> waypoints) {
    _repository.replace(waypoints);
    state = _withWaypoints(state, waypoints);
  }

  MissionState _withWaypoints(MissionState base, List<Waypoint> waypoints) {
    final distance = _totalDistanceKm(waypoints);
    return base.copyWith(
      waypoints: List.unmodifiable(waypoints),
      totalDistanceKm: distance,
      estimatedMinutes: _estimatedMinutes(waypoints, distance),
    );
  }

  static double _totalDistanceKm(List<Waypoint> waypoints) {
    const distance = Distance();
    var total = 0.0;
    for (var i = 1; i < waypoints.length; i++) {
      total += distance.as(
        LengthUnit.Kilometer,
        waypoints[i - 1].position,
        waypoints[i].position,
      );
    }
    return total;
  }

  static double _estimatedMinutes(List<Waypoint> waypoints, double distanceKm) {
    if (waypoints.isEmpty) return 0;
    final averageSpeed =
        waypoints.fold<double>(0, (sum, item) => sum + item.speed) /
            waypoints.length;
    if (averageSpeed <= 0) return 0;
    return (distanceKm * 1000 / averageSpeed) / 60;
  }
}
