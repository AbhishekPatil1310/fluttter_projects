import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../state/settings_state.dart';
import '../view_models/settings_view_model.dart';

/// Settings are UI-local state, so this view model needs no repository.
final settingsViewModelProvider =
    NotifierProvider<SettingsViewModel, SettingsState>(SettingsViewModel.new);
