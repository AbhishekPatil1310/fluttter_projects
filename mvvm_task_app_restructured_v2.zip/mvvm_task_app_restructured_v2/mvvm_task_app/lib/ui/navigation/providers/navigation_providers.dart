import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../state/navigation_state.dart';
import '../view_models/navigation_view_model.dart';

/// Navigation is UI-local state, so this view model needs no repository.
final navigationViewModelProvider =
    NotifierProvider<NavigationViewModel, NavigationState>(
  NavigationViewModel.new,
);
