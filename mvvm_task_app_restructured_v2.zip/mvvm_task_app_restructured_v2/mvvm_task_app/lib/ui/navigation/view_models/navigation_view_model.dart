import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../state/navigation_state.dart';

class NavigationViewModel extends Notifier<NavigationState> {
  @override
  NavigationState build() => const NavigationState();

  void select(int index) {
    if (state.selectedIndex == index) return;
    state = NavigationState(selectedIndex: index);
  }
}
