import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../alerts/screens/alerts_screen.dart';
import '../../dashboard/screens/dashboard_screen.dart';
import '../../logs/screens/logs_screen.dart';
import '../../mission/screens/mission_screen.dart';
import '../../settings/screens/settings_screen.dart';
import '../providers/navigation_providers.dart';

class NavigationShell extends ConsumerWidget {
  const NavigationShell({super.key});

  static const _pages = [
    DashboardScreen(),
    MissionScreen(),
    AlertsScreen(),
    LogsScreen(),
    SettingsScreen(),
  ];

  static const _titles = [
    'DASHBOARD',
    'MISSION PLANNER',
    'ALERT CENTER',
    'SYSTEM LOGS',
    'SETTINGS',
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedIndex = ref.watch(navigationViewModelProvider).selectedIndex;
    final viewModel = ref.read(navigationViewModelProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: Text('NOMAD / ${_titles[selectedIndex]}')),
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              child: Text(
                'NOMAD-07\nFIELD VEHICLE',
                style: TextStyle(fontSize: 22),
              ),
            ),
            for (var i = 0; i < _titles.length; i++)
              ListTile(
                selected: selectedIndex == i,
                title: Text(_titles[i]),
                onTap: () {
                  viewModel.select(i);
                  Navigator.pop(context);
                },
              ),
          ],
        ),
      ),
      body: IndexedStack(index: selectedIndex, children: _pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: viewModel.select,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.route_outlined),
            label: 'Mission',
          ),
          NavigationDestination(
            icon: Icon(Icons.warning_amber_outlined),
            label: 'Alerts',
          ),
          NavigationDestination(icon: Icon(Icons.list_alt), label: 'Logs'),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}
