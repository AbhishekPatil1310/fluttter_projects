class NavigationState {
  const NavigationState({this.selectedIndex = 0});

  final int selectedIndex;
}
