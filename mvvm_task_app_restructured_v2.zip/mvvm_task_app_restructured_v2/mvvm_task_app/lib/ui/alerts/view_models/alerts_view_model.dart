import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../domain/entities/alert.dart';
import '../../../domain/repositories/alert_repository.dart';
import '../state/alert_state.dart';


class AlertsViewModel extends Notifier<AlertsState> {
  AlertsViewModel({required Provider<AlertRepository> alertRepository})
      : _alertRepositoryProvider = alertRepository;

  final Provider<AlertRepository> _alertRepositoryProvider;
  late AlertRepository _repository;

  @override
  AlertsState build() {
    _repository = ref.watch(_alertRepositoryProvider);
    final subscription = _repository.historyStream.listen(
      (history) => state = state.copyWith(history: history),
    );
    ref.onDispose(subscription.cancel);
    return AlertsState(history: _repository.history);
  }

  void triggerLowBattery() =>
      _trigger(AlertLevel.warning, 'Battery below 50%');

  void triggerGpsLost() => _trigger(AlertLevel.critical, 'GPS signal lost');

  void triggerGeofenceBreach() =>
      _trigger(AlertLevel.emergency, 'Geofence breach detected');

  void acknowledge(int index) => _repository.acknowledge(index);

  void clearPendingCriticalAlert() =>
      state = state.copyWith(clearPendingCriticalAlert: true);

  void clearNotice() => state = state.copyWith(clearNotice: true);

  void _trigger(AlertLevel level, String message) {
    final alert = _repository.emit(message, level);
    state = alert.requiresAcknowledgement
        ? state.copyWith(pendingCriticalAlert: alert)
        : state.copyWith(notice: message);
  }
}
