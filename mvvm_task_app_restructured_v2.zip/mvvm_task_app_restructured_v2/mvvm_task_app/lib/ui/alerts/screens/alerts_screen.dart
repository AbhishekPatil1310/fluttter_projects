import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../domain/entities/alert.dart';
import '../providers/alerts_providers.dart';
import '../widgets/alert_history.dart';
import '../widgets/scenario_controls.dart';

/// Renders the alerts state. Dialogs/snackbars are driven by state changes
/// emitted from the view model.
class AlertsScreen extends ConsumerWidget {
  const AlertsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(alertsViewModelProvider);
    final viewModel = ref.read(alertsViewModelProvider.notifier);

    ref.listen<Alert?>(
      alertsViewModelProvider.select((s) => s.pendingCriticalAlert),
      (previous, alert) {
        if (alert == null) return;
        viewModel.clearPendingCriticalAlert();
        showDialog<void>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: Text(alert.level.name.toUpperCase()),
            content: Text(alert.message),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('ACKNOWLEDGE'),
              ),
            ],
          ),
        );
      },
    );

    ref.listen<String?>(
      alertsViewModelProvider.select((s) => s.notice),
      (previous, notice) {
        if (notice == null) return;
        viewModel.clearNotice();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(notice)),
        );
      },
    );

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ScenarioControls(
            onLowBattery: viewModel.triggerLowBattery,
            onGpsLost: viewModel.triggerGpsLost,
            onGeofenceBreach: viewModel.triggerGeofenceBreach,
          ),
          const SizedBox(height: 28),
          const Text(
            'ALERT HISTORY',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: AlertHistory(
              alerts: state.history,
              onAcknowledge: viewModel.acknowledge,
            ),
          ),
        ],
      ),
    );
  }
}
