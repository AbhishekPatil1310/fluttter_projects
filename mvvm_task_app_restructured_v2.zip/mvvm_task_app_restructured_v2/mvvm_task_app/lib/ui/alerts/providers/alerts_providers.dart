import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../di/injection_container.dart';
import '../view_models/alerts_view_model.dart';
import '../state/alert_state.dart';

/// UI-layer provider: takes the repository from the DI container and
/// injects it into the view model.
final alertsViewModelProvider = NotifierProvider<AlertsViewModel, AlertsState>(
  () => AlertsViewModel(alertRepository: alertRepositoryProvider),
);
