import '../../../domain/entities/alert.dart';

class AlertsState {
  final List<Alert> history;
  final Alert? pendingCriticalAlert;
  final String? notice;
  final bool isLoading;
  final String? errorMessage;

  AlertsState({
    required this.history,
    this.pendingCriticalAlert,
    this.notice,
    this.isLoading = false,
    this.errorMessage,
  });

  factory AlertsState.initial() {
    return AlertsState(
      history: [],
      isLoading: false,
    );
  }

  AlertsState copyWith({
    List<Alert>? history,
    Alert? pendingCriticalAlert,
    bool clearPendingCriticalAlert = false,
    String? notice,
    bool clearNotice = false,
    bool? isLoading,
    String? errorMessage,
  }) {
    return AlertsState(
      history: history ?? this.history,
      pendingCriticalAlert: clearPendingCriticalAlert
          ? null
          : (pendingCriticalAlert ?? this.pendingCriticalAlert),
      notice: clearNotice ? null : (notice ?? this.notice),
      isLoading: isLoading ?? this.isLoading,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }
}