import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../di/injection_container.dart';
import '../../../domain/entities/telemetry.dart';

/// Reactive telemetry state sourced directly from the repository.
/// The initial snapshot prevents the dashboard from waiting for the first tick.
final telemetryProvider = StreamProvider<Telemetry>((ref) async* {
  final repository = ref.watch(telemetryRepositoryProvider);
  yield repository.latest;
  yield* repository.stream;
});

/// Derived dashboard presentation state.
final vehicleOnlineProvider = Provider<bool>((ref) {
  return ref.watch(telemetryProvider).maybeWhen(
        data: (telemetry) => telemetry.connection > 50,
        orElse: () => false,
      );
});

/// Command provider keeps repository access out of the widget tree.
final setVehicleArmedProvider = Provider<void Function(bool)>((ref) {
  final repository = ref.watch(telemetryRepositoryProvider);
  return repository.setArmed;
});

