import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../di/injection_container.dart';
import '../../../domain/entities/alert.dart';
import '../../../domain/entities/mission_log.dart';
import '../../../domain/entities/telemetry.dart';

/// Keeps the most recent 50 telemetry samples for the log view.
final telemetryLogProvider = StreamProvider<List<Telemetry>>((ref) async* {
  final repository = ref.watch(telemetryRepositoryProvider);
  var entries = <Telemetry>[repository.latest];
  yield List.unmodifiable(entries);

  await for (final telemetry in repository.stream) {
    entries = [telemetry, ...entries];
    if (entries.length > 50) entries = entries.sublist(0, 50);
    yield List.unmodifiable(entries);
  }
});

final alertLogProvider = StreamProvider<List<Alert>>((ref) async* {
  final repository = ref.watch(alertRepositoryProvider);
  yield repository.history;
  yield* repository.historyStream;
});

final missionLogProvider = StreamProvider<List<MissionLog>>((ref) async* {
  final repository = ref.watch(missionRepositoryProvider);
  yield repository.history;
  yield* repository.historyStream;
});
