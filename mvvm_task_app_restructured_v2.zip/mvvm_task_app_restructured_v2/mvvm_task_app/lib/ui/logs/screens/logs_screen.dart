import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/logs_providers.dart';
import '../widgets/alert_log_list.dart';
import '../widgets/mission_log_list.dart';
import '../widgets/telemetry_log_list.dart';

class LogsScreen extends StatelessWidget {
  const LogsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const DefaultTabController(
      length: 3,
      child: Column(
        children: [
          TabBar(tabs: [
            Tab(text: 'Telemetry'),
            Tab(text: 'Alerts'),
            Tab(text: 'Missions'),
          ]),
          Expanded(
            child: TabBarView(
              children: [
                _TelemetryLogsTab(),
                _AlertLogsTab(),
                _MissionLogsTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TelemetryLogsTab extends ConsumerWidget {
  const _TelemetryLogsTab();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watch(telemetryLogProvider).when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stack) => Center(child: Text('Telemetry error: $error')),
      data: (entries) => TelemetryLogList(entries: entries),
    );
  }
}

class _AlertLogsTab extends ConsumerWidget {
  const _AlertLogsTab();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watch(alertLogProvider).when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stack) => Center(child: Text('Alert error: $error')),
      data: (alerts) => AlertLogList(alerts: alerts),
    );
  }
}

class _MissionLogsTab extends ConsumerWidget {
  const _MissionLogsTab();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ref.watch(missionLogProvider).when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stack) => Center(child: Text('Mission log error: $error')),
      data: (logs) => MissionLogList(logs: logs),
    );
  }
}
