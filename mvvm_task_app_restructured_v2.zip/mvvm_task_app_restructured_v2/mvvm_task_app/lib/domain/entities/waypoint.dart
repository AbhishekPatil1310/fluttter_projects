import 'package:latlong2/latlong.dart';

class Waypoint {
  const Waypoint({
    required this.position,
    this.altitude = 30,
    this.speed = 2,
  });

  final LatLng position;
  final double altitude;
  final double speed;

  Waypoint copyWith({LatLng? position, double? altitude, double? speed}) =>
      Waypoint(
        position: position ?? this.position,
        altitude: altitude ?? this.altitude,
        speed: speed ?? this.speed,
      );
}
