import '../entities/telemetry.dart';

/// What the UI layer may request about vehicle telemetry.
abstract interface class TelemetryRepository {
  /// Most recent known telemetry (never null; starts from a default state).
  Telemetry get latest;

  /// Live telemetry packets.
  Stream<Telemetry> get stream;

  void setArmed(bool armed);
}
