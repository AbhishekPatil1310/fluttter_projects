import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/repositories/alert_repository_impl.dart';
import '../data/repositories/mission_repository_impl.dart';
import '../data/repositories/telemetry_repository_impl.dart';
import '../data/services/file_service.dart';
import '../data/services/telemetry_service.dart';
import '../domain/repositories/alert_repository.dart';
import '../domain/repositories/mission_repository.dart';
import '../domain/repositories/telemetry_repository.dart';

// =========================
// SERVICES
// =========================

/// Mock telemetry server; started as soon as it is first requested.
final telemetryServiceProvider = Provider<TelemetryService>((ref) {
  final service = TelemetryService()..start();
  ref.onDispose(service.dispose);
  return service;
});

final fileServiceProvider = Provider<FileService>((ref) => FileService());

// =========================
// REPOSITORIES
// Exposed as domain interfaces so upper layers never see the
// implementations (and tests can override them with fakes).
// =========================

final telemetryRepositoryProvider = Provider<TelemetryRepository>((ref) {
  final repository = TelemetryRepositoryImpl(
    ref.watch(telemetryServiceProvider),
  );
  ref.onDispose(repository.dispose);
  return repository;
});

final alertRepositoryProvider = Provider<AlertRepository>((ref) {
  final repository = AlertRepositoryImpl();
  ref.onDispose(repository.dispose);
  return repository;
});

final missionRepositoryProvider = Provider<MissionRepository>((ref) {
  final repository = MissionRepositoryImpl(ref.watch(fileServiceProvider));
  ref.onDispose(repository.dispose);
  return repository;
});
