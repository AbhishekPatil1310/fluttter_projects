import 'dart:async';

import '../../domain/entities/mission_log.dart';
import '../../domain/entities/waypoint.dart';
import '../../domain/repositories/mission_repository.dart';
import '../mappers/waypoint_mapper.dart';
import '../services/file_service.dart';

class MissionRepositoryImpl implements MissionRepository {
  MissionRepositoryImpl(this._fileService);

  static const _maxHistory = 100;

  final FileService _fileService;
  final List<MissionLog> _history = [];
  final _controller = StreamController<List<MissionLog>>.broadcast();
  List<Waypoint> _waypoints = const [];

  @override
  List<Waypoint> get waypoints => List.unmodifiable(_waypoints);

  @override
  List<MissionLog> get history => List.unmodifiable(_history);

  @override
  Stream<List<MissionLog>> get historyStream => _controller.stream;

  @override
  void replace(List<Waypoint> waypoints) {
    _waypoints = List.unmodifiable(waypoints);
    _record(
      MissionLogType.waypointUpdated,
      'Mission waypoints updated (${waypoints.length} waypoints)',
    );
  }

  @override
  Future<bool> save() async {
    final saved = await _fileService.saveMission(
      WaypointMapper.encode(_waypoints),
    );
    if (saved) {
      _record(
        MissionLogType.missionSaved,
        'Mission saved (${_waypoints.length} waypoints)',
      );
    }
    return saved;
  }

  @override
  Future<List<Waypoint>?> load() async {
    final contents = await _fileService.loadMission();
    if (contents == null) return null;

    final loaded = WaypointMapper.decode(contents);
    _waypoints = List.unmodifiable(loaded);
    _record(
      MissionLogType.missionLoaded,
      'Mission loaded (${loaded.length} waypoints)',
    );
    return _waypoints;
  }


//this is for the mission log to display on the mission log in the log screen
  void _record(MissionLogType type, String message) {
    _history.insert(
      0,
      MissionLog(message: message, type: type, timestamp: DateTime.now()),
    );
    if (_history.length > _maxHistory) _history.removeLast();
    if (!_controller.isClosed) _controller.add(history);
  }

  void dispose() => _controller.close();
}
