import 'dart:async';

import '../../domain/entities/alert.dart';
import '../../domain/repositories/alert_repository.dart';

/// Keeps the alert history in memory (most recent 10 alerts).
class AlertRepositoryImpl implements AlertRepository {
  static const _maxEntries = 10;

  final List<Alert> _history = [];
  final _controller = StreamController<List<Alert>>.broadcast();

  @override
  List<Alert> get history => List.unmodifiable(_history);   //what alerts exist right now

  @override
  Stream<List<Alert>> get historyStream => _controller.stream;    //what alert updates happens from now

  @override
  Alert emit(String message, AlertLevel level) {
    final alert = Alert(
      message: message,
      level: level,
      timestamp: DateTime.now(),
    );
    _history.insert(0, alert);
    if (_history.length > _maxEntries) _history.removeLast();
    _publish();
    return alert;
  }

  @override
  void acknowledge(int index) {
    if (index < 0 || index >= _history.length) return;
    _history[index] = _history[index].copyWith(acknowledged: true);
    _publish();
  }

  void _publish() {
    if (!_controller.isClosed) _controller.add(history);
  }

  void dispose() => _controller.close();
}



//adding the new object which is Alert to the stream (_controller)