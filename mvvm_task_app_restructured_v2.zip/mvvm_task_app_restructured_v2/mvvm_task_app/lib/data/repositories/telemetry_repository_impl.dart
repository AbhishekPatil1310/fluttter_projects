import 'dart:async';

import '../../domain/entities/telemetry.dart';
import '../../domain/repositories/telemetry_repository.dart';
import '../services/telemetry_service.dart';

class TelemetryRepositoryImpl implements TelemetryRepository {
  TelemetryRepositoryImpl(this._service) : _latest = _service.current {
    _subscription = _service.stream.listen((telemetry) => _latest = telemetry);
  }

  final TelemetryService _service;
  late final StreamSubscription<Telemetry> _subscription;
  Telemetry _latest;

  @override
  Telemetry get latest => _latest;

  @override
  Stream<Telemetry> get stream => _service.stream;

  @override
  void setArmed(bool armed) => _service.setArmed(armed);

  void dispose() => _subscription.cancel();
}
