import 'dart:io';

import 'package:file_selector/file_selector.dart';

/// Raw file I/O for missions. Knows nothing about waypoints or JSON:
/// it only picks a file and reads/writes its text contents.
class FileService {
  static const _missionTypeGroup = XTypeGroup(
    label: 'Mission JSON',
    extensions: ['json'],
  );

  /// Asks the user where to save and writes [contents].
  /// Returns `false` if the user cancelled.
  Future<bool> saveMission(String contents) async {
    final location = await getSaveLocation(
      suggestedName: 'nomad_mission.json',
      acceptedTypeGroups: const [_missionTypeGroup],
    );
    if (location == null) return false;
    await File(location.path).writeAsString(contents);
    return true;
  }

  /// Asks the user to pick a mission file and returns its text,
  /// or `null` if the user cancelled.
  Future<String?> loadMission() async {
    final file = await openFile(
      acceptedTypeGroups: const [_missionTypeGroup],
    );
    if (file == null) return null;
    return file.readAsString();
  }
}
