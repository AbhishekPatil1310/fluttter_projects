import 'dart:async';
import 'dart:math' as math;

import 'package:latlong2/latlong.dart';

import '../../domain/entities/telemetry.dart';

/// Mock telemetry server. Produces simulated vehicle telemetry (battery,
/// GPS, link quality and a moving position while armed).
class TelemetryService {
  TelemetryService({this.interval = const Duration(seconds: 2)})
      : _current = Telemetry.initial();

  static const double _cruiseSpeed = 4.2; // m/s while armed
  static const double _metersPerDegreeLat = 111320;

  final Duration interval;
  final _controller = StreamController<Telemetry>.broadcast();
  Timer? _timer;
  Telemetry _current;

  Telemetry get current => _current;
  Stream<Telemetry> get stream => _controller.stream;

  void start() {
    _timer ??= Timer.periodic(interval, (_) => _tick());
  }

  void setArmed(bool armed) {
    _publish(
      _current.copyWith(
        armed: armed,
        speed: armed ? _cruiseSpeed : 0,
        satellites: 14,
        connection: 90,
        timestamp: DateTime.now(),
      ),
    );
  }

  void _tick() {
    final now = DateTime.now();
    final battery = _current.battery > 15 ? _current.battery - 1 : 76;
    _publish(
      _current.copyWith(
        battery: battery,
        satellites: 12 + (now.second % 4),
        connection: 82 + (now.second % 16),
        speed: _current.armed ? _cruiseSpeed : 0,
        position: _advance(_current, interval.inMilliseconds / 1000),
        timestamp: now,
      ),
    );
  }

  /// Moves the vehicle along its heading while armed.
  LatLng _advance(Telemetry from, double seconds) {
    if (!from.armed) return from.position;
    final meters = _cruiseSpeed * seconds;
    final radians = from.heading * math.pi / 180;
    final latitude = from.position.latitude;
    final dLat = meters * math.cos(radians) / _metersPerDegreeLat;
    final dLng = meters *
        math.sin(radians) /
        (_metersPerDegreeLat * math.cos(latitude * math.pi / 180));
    return LatLng(latitude + dLat, from.position.longitude + dLng);
  }

  void _publish(Telemetry telemetry) {
    _current = telemetry;
    if (!_controller.isClosed) _controller.add(telemetry);
  }

  void dispose() {
    _timer?.cancel();
    _timer = null;
    _controller.close();
  }
}
