import json
import math
import time

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import BatteryState
from geometry_msgs.msg import Twist
from std_msgs.msg import String


class TelemetryPublisher(Node):
    def __init__(self):
        super().__init__('telemetry_publisher')

        self.battery_pub = self.create_publisher(BatteryState, '/robot/battery', 10)
        self.velocity_pub = self.create_publisher(Twist, '/robot/velocity', 10)
        self.status_pub = self.create_publisher(String, '/robot/status', 10)
        self.command_sub = self.create_subscription(
            String, '/robot/command', self.command_callback, 10
        )

        self.start_time = time.monotonic()
        self.drive_mode = 'MANUAL'
        self.mission_mode = 'IDLE'
        self.armed = False
        self.hand_controller_enabled = True
        self.speed_limit = 1.0
        self.emergency_stop = False
        self.timer = self.create_timer(0.2, self.publish_telemetry)

        self.get_logger().info('ROS Flutter demo publisher/controller started.')

    def command_callback(self, message):
        try:
            command = json.loads(message.data)
            action = command.get('action')

            if action == 'ARM':
                self.armed = True
            elif action == 'DISARM':
                self.armed = False
                self.mission_mode = 'IDLE'
            elif action == 'SET_DRIVE_MODE':
                self.drive_mode = command.get('drive_mode', self.drive_mode)
            elif action == 'SET_MISSION_MODE':
                self.mission_mode = command.get('mission_mode', self.mission_mode)
            elif action == 'SET_SPEED_LIMIT':
                self.speed_limit = float(command.get('speed_limit', self.speed_limit))
            elif action == 'SET_HAND_CONTROLLER':
                self.hand_controller_enabled = bool(command.get('enabled', True))
            elif action == 'EMERGENCY_STOP':
                self.emergency_stop = True
                self.armed = False
                self.mission_mode = 'IDLE'

            self.get_logger().info(f'Received command: {command}')
        except (json.JSONDecodeError, TypeError, ValueError) as exc:
            self.get_logger().warning(f'Invalid command: {message.data} ({exc})')

    def publish_telemetry(self):
        elapsed = time.monotonic() - self.start_time
        percentage = max(0.0, 0.95 - elapsed / 180.0)

        battery = BatteryState()
        battery.voltage = 24.5 + 0.3 * math.sin(elapsed)
        battery.current = -2.0 + 0.4 * math.sin(elapsed * 0.7)
        battery.percentage = percentage
        self.battery_pub.publish(battery)

        velocity = Twist()
        if self.emergency_stop or not self.armed:
            velocity.linear.x = 0.0
        else:
            velocity.linear.x = min(
                self.speed_limit,
                self.speed_limit * (0.75 + 0.25 * math.sin(elapsed)),
            )
        velocity.angular.z = 0.15 * math.sin(elapsed * 0.5) if self.armed else 0.0
        self.velocity_pub.publish(velocity)

        if self.emergency_stop:
            state = 'EMERGENCY_STOP'
        elif not self.armed:
            state = 'DISARMED'
        elif self.mission_mode == 'PAUSE':
            state = 'PAUSED'
        elif self.mission_mode == 'ABORT':
            state = 'ABORTED'
        elif self.mission_mode in ('START', 'RESUME'):
            state = f'{self.drive_mode}:{self.mission_mode}'
        else:
            state = self.drive_mode

        status = String()
        status.data = state
        self.status_pub.publish(status)


def main(args=None):
    rclpy.init(args=args)
    node = TelemetryPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()