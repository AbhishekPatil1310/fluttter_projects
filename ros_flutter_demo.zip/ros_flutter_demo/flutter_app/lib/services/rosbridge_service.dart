
import 'dart:convert';
import 'dart:async';

import 'package:web_socket_channel/web_socket_channel.dart';

class RosbridgeService {
  RosbridgeService({this.url = 'ws://localhost:9090'});

  final String url;

  WebSocketChannel? _channel;

  final _batteryController =
      StreamController<Map<String, dynamic>>.broadcast();
  final _velocityController =
      StreamController<Map<String, dynamic>>.broadcast();
  final _statusController =
      StreamController<Map<String, dynamic>>.broadcast();

  final _connectionController = StreamController<bool>.broadcast();

  Stream<Map<String, dynamic>> get batteryStream =>
      _batteryController.stream;

  Stream<Map<String, dynamic>> get velocityStream =>
      _velocityController.stream;

  Stream<Map<String, dynamic>> get statusStream =>
      _statusController.stream;

  Stream<bool> get connectionStream => _connectionController.stream;

  void connect() {
    _channel = WebSocketChannel.connect(Uri.parse(url));
    _connectionController.add(true);

    _channel!.stream.listen(
      _handleMessage,
      onDone: () => _connectionController.add(false),
      onError: (_) => _connectionController.add(false),
      cancelOnError: true,
    );

    _subscribe(
      topic: '/robot/battery',
      type: 'sensor_msgs/msg/BatteryState',
    );

    _subscribe(
      topic: '/robot/velocity',
      type: 'geometry_msgs/msg/Twist',
    );

    _subscribe(
      topic: '/robot/status',
      type: 'std_msgs/msg/String',
    );
  }

  void _subscribe({
    required String topic,
    required String type,
  }) {
    final request = {
      'op': 'subscribe',
      'topic': topic,
      'type': type,
      'queue_length': 1,
    };

    _channel?.sink.add(jsonEncode(request));
  }

  void _handleMessage(dynamic raw) {
    try {
      final decoded = jsonDecode(raw as String);

      if (decoded['op'] != 'publish') {
        return;
      }

      final topic = decoded['topic'];
      final msg = Map<String, dynamic>.from(decoded['msg'] ?? {});

      switch (topic) {
        case '/robot/battery':
          _batteryController.add(msg);
          break;
        case '/robot/velocity':
          _velocityController.add(msg);
          break;
        case '/robot/status':
          _statusController.add(msg);
          break;
      }
    } catch (_) {
      // Ignore malformed/non-JSON WebSocket messages.
    }
  }

  void dispose() {
    _channel?.sink.close();
    _batteryController.close();
    _velocityController.close();
    _statusController.close();
    _connectionController.close();
  }
  void publish({
  required String topic,
  required Map<String, dynamic> msg,
}) {
  final request = {
    "op": "publish",
    "topic": topic,
    "msg": {
      "data": jsonEncode(msg),
    }
  };

  _channel?.sink.add(jsonEncode(request));
}
}


