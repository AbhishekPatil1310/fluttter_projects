import 'dart:convert';

import 'package:flutter/material.dart';
import '../services/rosbridge_service.dart';

class ControlScreen extends StatefulWidget {
  final RosbridgeService ros;

  const ControlScreen({
    super.key,
    required this.ros,
  });

  @override
  State<ControlScreen> createState() => _ControlScreenState();
}

class _ControlScreenState extends State<ControlScreen> {
  bool armed = false;
  bool handController = true;

  String driveMode = "MANUAL";
  String missionMode = "IDLE";

  double speedLimit = 2.0;

  void sendCommand(Map<String, dynamic> data) {
    widget.ros.publish(
      topic: "/robot/command",
      msg: data,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: ListView(
        children: [
          const Text(
            "Robot Controls",
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 30),

          //---------------------------------
          // ARM
          //---------------------------------

          SwitchListTile(
            title: const Text("Arm Vehicle"),
            value: armed,
            onChanged: (value) {
              setState(() {
                armed = value;
              });

              sendCommand({
                "action": value ? "ARM" : "DISARM",
              });
            },
          ),

          const SizedBox(height: 20),

          //---------------------------------
          // Drive Mode
          //---------------------------------

          DropdownButtonFormField(
            value: driveMode,
            decoration: const InputDecoration(
              labelText: "Drive Mode",
            ),
            items: const [
              DropdownMenuItem(
                value: "MANUAL",
                child: Text("MANUAL"),
              ),
              DropdownMenuItem(
                value: "AUTONOMOUS",
                child: Text("AUTONOMOUS"),
              ),
              DropdownMenuItem(
                value: "REMOTE",
                child: Text("REMOTE"),
              ),
              DropdownMenuItem(
                value: "SAFE",
                child: Text("SAFE"),
              ),
            ],
            onChanged: (value) {
              setState(() {
                driveMode = value!;
              });

              sendCommand({
                "action": "SET_DRIVE_MODE",
                "drive_mode": driveMode,
              });
            },
          ),

          const SizedBox(height: 20),

          //---------------------------------
          // Mission Mode
          //---------------------------------

          DropdownButtonFormField(
            value: missionMode,
            decoration: const InputDecoration(
              labelText: "Mission Mode",
            ),
            items: const [
              DropdownMenuItem(value: "IDLE", child: Text("IDLE")),
              DropdownMenuItem(value: "START", child: Text("START")),
              DropdownMenuItem(value: "PAUSE", child: Text("PAUSE")),
              DropdownMenuItem(value: "RESUME", child: Text("RESUME")),
              DropdownMenuItem(value: "ABORT", child: Text("ABORT")),
            ],
            onChanged: (value) {
              setState(() {
                missionMode = value!;
              });

              sendCommand({
                "action": "SET_MISSION_MODE",
                "mission_mode": missionMode,
              });
            },
          ),

          const SizedBox(height: 30),

          //---------------------------------
          // Speed Limit
          //---------------------------------

          Text(
            "Speed Limit: ${speedLimit.toStringAsFixed(1)} m/s",
          ),

          Slider(
            min: 0,
            max: 10,
            value: speedLimit,
            onChanged: (value) {
              setState(() {
                speedLimit = value;
              });
            },
            onChangeEnd: (value) {
              sendCommand({
                "action": "SET_SPEED_LIMIT",
                "speed_limit": value,
              });
            },
          ),

          //---------------------------------
          // Hand Controller
          //---------------------------------

          SwitchListTile(
            title: const Text("Hand Controller"),
            value: handController,
            onChanged: (value) {
              setState(() {
                handController = value;
              });

              sendCommand({
                "action": "SET_HAND_CONTROLLER_",
                "enabled": value,
              });
            },
          ),

          const SizedBox(height: 30),

          //---------------------------------
          // E-STOP
          //---------------------------------

          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              minimumSize: const Size(double.infinity, 60),
            ),
            onPressed: () {
              sendCommand({
                "action": "EMERGENCY_STOP",
              });
            },
            child: const Text(
              "EMERGENCY STOP",
              style: TextStyle(fontSize: 20),
            ),
          ),
        ],
      ),
    );
  }
}