class VelocityData {
  final double linearX;
  final double angularZ;

  const VelocityData({
    required this.linearX,
    required this.angularZ,
  });

  factory VelocityData.fromRosMessage(Map<String, dynamic> msg) {
    final linear = Map<String, dynamic>.from(msg['linear'] ?? {});
    final angular = Map<String, dynamic>.from(msg['angular'] ?? {});

    return VelocityData(
      linearX: (linear['x'] ?? 0).toDouble(),
      angularZ: (angular['z'] ?? 0).toDouble(),
    );
  }
}
