class BatteryData {
  final double voltage;
  final double current;
  final double percentage;

  const BatteryData({
    required this.voltage,
    required this.current,
    required this.percentage,
  });

  factory BatteryData.fromRosMessage(Map<String, dynamic> msg) {
    return BatteryData(
      voltage: (msg['voltage'] ?? 0).toDouble(),
      current: (msg['current'] ?? 0).toDouble(),
      percentage: (msg['percentage'] ?? 0).toDouble(),
    );
  }
}
