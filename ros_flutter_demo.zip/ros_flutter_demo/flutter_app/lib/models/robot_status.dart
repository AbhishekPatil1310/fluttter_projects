class RobotStatus {
  final String value;

  const RobotStatus(this.value);
}
