import 'dart:async';
import 'package:flutter/material.dart';
import 'models/battery_data.dart';
import 'models/robot_status.dart';
import 'models/velocity_data.dart';
import 'services/rosbridge_service.dart';
import 'screens/control_screen.dart';

void main() => runApp(const RosFlutterApp());

class RosFlutterApp extends StatelessWidget {
  const RosFlutterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ROS 2 Flutter Dashboard',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(brightness: Brightness.dark, useMaterial3: true),
      home: const AppShell(),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  late final RosbridgeService ros;
  int index = 0;

  BatteryData battery = const BatteryData(voltage: 0, current: 0, percentage: 0);
  VelocityData velocity = const VelocityData(linearX: 0, angularZ: 0);
  RobotStatus status = const RobotStatus('DISCONNECTED');
  bool connected = false;

  StreamSubscription? batterySub;
  StreamSubscription? velocitySub;
  StreamSubscription? statusSub;
  StreamSubscription? connectionSub;

  @override
  void initState() {
    super.initState();
    ros = RosbridgeService();
    ros.connect();

    connectionSub = ros.connectionStream.listen((value) {
      if (!mounted) return;
      setState(() => connected = value);
    });
    batterySub = ros.batteryStream.listen((msg) {
      if (!mounted) return;
      setState(() => battery = BatteryData.fromRosMessage(msg));
    });
    velocitySub = ros.velocityStream.listen((msg) {
      if (!mounted) return;
      setState(() => velocity = VelocityData.fromRosMessage(msg));
    });
    statusSub = ros.statusStream.listen((msg) {
      if (!mounted) return;
      setState(() => status = RobotStatus(msg['data']?.toString() ?? 'UNKNOWN'));
    });
  }

  @override
  void dispose() {
    batterySub?.cancel();
    velocitySub?.cancel();
    statusSub?.cancel();
    connectionSub?.cancel();
    ros.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: index == 0
          ? DashboardPage(
              battery: battery,
              velocity: velocity,
              status: status,
              connected: connected,
            )
          : ControlScreen(ros: ros),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.tune), label: 'Control'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key, required this.battery, required this.velocity, required this.status, required this.connected});
  final BatteryData battery;
  final VelocityData velocity;
  final RobotStatus status;
  final bool connected;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ROS 2 → Flutter Dashboard'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 20),
            child: Row(children: [
              Icon(Icons.circle, size: 12, color: connected ? Colors.green : Colors.red),
              const SizedBox(width: 8),
              Text(connected ? 'ROS Connected' : 'ROS Disconnected'),
            ]),
          ),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1000),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Live Robot Telemetry', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('Data source: ROS 2 topics through rosbridge WebSocket', style: TextStyle(color: Colors.grey.shade400)),
              const SizedBox(height: 28),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 3,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.4,
                  children: [
                    TelemetryCard(icon: Icons.battery_full, title: 'Battery', value: '${(battery.percentage * 100).toStringAsFixed(0)}%', subtitle: '${battery.voltage.toStringAsFixed(1)} V • ${battery.current.toStringAsFixed(1)} A'),
                    TelemetryCard(icon: Icons.speed, title: 'Speed', value: '${velocity.linearX.toStringAsFixed(2)} m/s', subtitle: 'Angular: ${velocity.angularZ.toStringAsFixed(2)} rad/s'),
                    TelemetryCard(icon: Icons.smart_toy, title: 'Robot State', value: status.value, subtitle: '/robot/status'),
                  ],
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

class TelemetryCard extends StatelessWidget {
  const TelemetryCard({super.key, required this.icon, required this.title, required this.value, required this.subtitle});
  final IconData icon;
  final String title;
  final String value;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, size: 28),
      const Spacer(),
      Text(title, style: TextStyle(color: Colors.grey.shade400)),
      const SizedBox(height: 4),
      Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      Text(subtitle, style: TextStyle(color: Colors.grey.shade500)),
    ])));
  }
}