# ROS 2 + Flutter Demo

A beginner-friendly project demonstrating:

ROS 2 node
  -> ROS 2 topics
  -> rosbridge WebSocket server
  -> Flutter Linux application
  -> live robot telemetry UI

## Architecture

```text
+----------------------+       ROS 2 Topics       +----------------------+
|                      | -----------------------> |                      |
|  ROS 2 Python Node   |                          |      rosbridge       |
|  telemetry_publisher |                          |    WebSocket :9090   |
|                      |                          |                      |
+----------------------+                          +----------+-----------+
                                                            |
                                                            | WebSocket
                                                            | JSON
                                                            v
                                                +------------------------+
                                                |     Flutter Linux      |
                                                |                        |
                                                |  Battery / Speed /     |
                                                |  Status / Connection    |
                                                +------------------------+
```

## Prerequisites

This project is designed for Ubuntu 22.04 + ROS 2 Humble + Flutter Linux.

You need:

- ROS 2 Humble
- Python 3
- rosbridge_suite
- Flutter SDK with Linux desktop enabled

Check ROS:

```bash
source /opt/ros/humble/setup.bash
ros2 --version
```

Check Flutter:

```bash
flutter doctor
```

Enable Linux desktop if needed:

```bash
flutter config --enable-linux-desktop
```

## 1. Install rosbridge

```bash
sudo apt update
sudo apt install ros-humble-rosbridge-suite
```

## 2. Build the ROS package

Open a terminal:

```bash
cd ros_ws
source /opt/ros/humble/setup.bash

colcon build
source install/setup.bash
```

## 3. Start the ROS telemetry publisher

Terminal 1:

```bash
source /opt/ros/humble/setup.bash
cd ros_ws
source install/setup.bash

ros2 run ros_flutter_demo telemetry_publisher
```

The node publishes:

- `/robot/battery` -> `sensor_msgs/msg/BatteryState`
- `/robot/velocity` -> `geometry_msgs/msg/Twist`
- `/robot/status` -> `std_msgs/msg/String`

Check the topics:

```bash
ros2 topic list
```

Check battery:

```bash
ros2 topic echo /robot/battery
```

Check velocity:

```bash
ros2 topic echo /robot/velocity
```

## 4. Start rosbridge

Terminal 2:

```bash
source /opt/ros/humble/setup.bash
ros2 launch rosbridge_server rosbridge_websocket_launch.xml
```

The WebSocket server should be available at:

```text
ws://localhost:9090
```

## 5. Run Flutter

Terminal 3:

```bash
cd flutter_app
flutter pub get
flutter run -d linux
```

The Flutter application will:

1. Open a WebSocket connection to rosbridge.
2. Subscribe to the three ROS topics.
3. Receive ROS messages as JSON.
4. Parse the JSON.
5. Update the UI in real time.

## Important rosbridge concept

Flutter is NOT directly reading ROS DDS packets.

The flow is:

```text
ROS message
    ↓
ROS 2 topic
    ↓
rosbridge
    ↓
WebSocket JSON
    ↓
Flutter WebSocket
    ↓
Dart model/parser
    ↓
Flutter UI
```

For example, Flutter sends this subscription request:

```json
{
  "op": "subscribe",
  "topic": "/robot/battery",
  "type": "sensor_msgs/BatteryState"
}
```

rosbridge then sends messages such as:

```json
{
  "op": "publish",
  "topic": "/robot/battery",
  "msg": {
    "voltage": 24.8,
    "current": -2.1,
    "percentage": 0.82
  }
}
```

The Flutter app extracts:

```dart
final percentage = message["msg"]["percentage"];
```

## Useful commands

See all topics:

```bash
ros2 topic list
```

See topic type:

```bash
ros2 topic type /robot/battery
```

See publishers:

```bash
ros2 topic info /robot/battery
```

Inspect raw ROS data:

```bash
ros2 topic echo /robot/battery
```

## Project structure

```text
ros_flutter_demo/
├── README.md
├── ros_ws/
│   └── src/
│       └── ros_flutter_demo/
│           ├── package.xml
│           ├── setup.py
│           ├── setup.cfg
│           ├── resource/
│           │   └── ros_flutter_demo
│           └── ros_flutter_demo/
│               ├── __init__.py
│               └── telemetry_publisher.py
└── flutter_app/
    ├── pubspec.yaml
    └── lib/
        ├── main.dart
        ├── models/
        │   ├── battery_data.dart
        │   ├── velocity_data.dart
        │   └── robot_status.dart
        └── services/
            └── rosbridge_service.dart
```

## What to demonstrate in an interview

You can explain:

> "ROS 2 publishes robot telemetry on topics. I use rosbridge as a protocol bridge because my Flutter UI does not directly communicate with ROS 2 DDS. rosbridge exposes ROS topics over WebSocket. Flutter subscribes to those topics, receives JSON messages, maps them into Dart models, and updates the UI reactively."

## Next step

After this demo works, replace the simulated Python telemetry with your real ROS 2 node, CAN/MAVLink bridge, or UGV telemetry topics.

You can also extend it with:

- ROS 2 `/cmd_vel` publishing from Flutter
- camera/image streaming
- GPS/map display
- diagnostics
- connection watchdog
- reconnect logic
- ROS service calls
- ROS actions
