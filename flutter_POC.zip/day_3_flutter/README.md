# Day 3 Flutter State And Animation

Independent Linux status monitor with reusable animated status cards, battery thresholds, GPS, connection strength, armed/disarmed state, a pulsing armed indicator, and simulated two-second updates.

Run with `flutter pub get` then `flutter run -d linux`. Build with `flutter build linux`. Uses Flutter/Dart and Material 3 only.