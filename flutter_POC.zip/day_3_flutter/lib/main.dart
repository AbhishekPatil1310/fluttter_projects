import 'dart:async';

import 'package:flutter/material.dart';

void main() => runApp(const StatusApp());

class StatusApp extends StatelessWidget {
  const StatusApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xFF101820),
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF55D6BE),
        brightness: Brightness.dark,
      ),
    ),
    home: const StatusScreen(),
  );
}

class MyApp extends StatusApp {
  const MyApp({super.key});
}

class StatusScreen extends StatefulWidget {
  const StatusScreen({super.key});
  @override
  State<StatusScreen> createState() => _StatusScreenState();
}

class _StatusScreenState extends State<StatusScreen>
    with SingleTickerProviderStateMixin {
  Timer? timer;
  late AnimationController pulse;
  int battery = 76, satellites = 14, connection = 91;
  bool armed = false;
  @override
  void initState() {
    super.initState();
    pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat(reverse: true);
    timer = Timer.periodic(const Duration(seconds: 2), (_) {
      if (mounted) {
        setState(() {
          battery = battery > 15 ? battery - 1 : 76;
          satellites = 12 + (DateTime.now().second % 4);
          connection = 82 + (DateTime.now().second % 16);
        });
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    pulse.dispose();
    super.dispose();
  }

  Color batteryColor() => battery < 20
      ? Colors.redAccent
      : battery < 50
      ? Colors.amber
      : Colors.greenAccent;
  Widget status(String label, String value, IconData icon, Color color) =>
      AnimatedContainer(
        duration: const Duration(milliseconds: 450),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: color.withAlpha(22),
          border: Border.all(color: color.withAlpha(130)),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 30),
            const Spacer(),
            Text(label, style: const TextStyle(color: Colors.white60)),
            const SizedBox(height: 6),
            Text(
              value,
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      );
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('NOMAD / STATE MONITOR')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'LIVE STATUS',
            style: TextStyle(color: Color(0xFF55D6BE), letterSpacing: 2),
          ),
          const SizedBox(height: 8),
          const Text(
            'Realtime state and motion feedback',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 28),
          Expanded(
            child: GridView.count(
              crossAxisCount: MediaQuery.sizeOf(context).width > 700 ? 4 : 2,
              crossAxisSpacing: 14,
              mainAxisSpacing: 14,
              children: [
                status(
                  'BATTERY',
                  '$battery%',
                  Icons.battery_6_bar,
                  batteryColor(),
                ),
                status(
                  'GPS FIX',
                  '$satellites SATS',
                  Icons.gps_fixed,
                  Colors.lightBlueAccent,
                ),
                status(
                  'CONNECTION',
                  '$connection%',
                  Icons.wifi,
                  Colors.greenAccent,
                ),
                AnimatedBuilder(
                  animation: pulse,
                          builder: (context, _) => status(
                    'VEHICLE',
                    armed ? 'ARMED' : 'DISARMED',
                    Icons.shield_outlined,
                    armed
                        ? Color.lerp(Colors.orange, Colors.red, pulse.value)!
                        : Colors.white54,
                  ),
                ),
              ],
            ),
          ),
          FilledButton.icon(
            onPressed: () => setState(() => armed = !armed),
            icon: Icon(armed ? Icons.lock : Icons.lock_open),
            label: Text(armed ? 'DISARM VEHICLE' : 'ARM VEHICLE'),
          ),
        ],
      ),
    ),
  );
}
