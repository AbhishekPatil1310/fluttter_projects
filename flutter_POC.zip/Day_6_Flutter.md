# Day 6 – Mission Planning

## Task

The goal was to build a mission-planning interface using an interactive map. The application needed to allow users to create and edit waypoints, configure waypoint parameters, reorder and delete waypoints, save/load missions, and display mission statistics. fileciteturn0file5L3-L15

## How I Completed It

I added the `flutter_map` and `latlong2` packages to the Flutter project.

I created a `MissionPlannerScreen` containing an interactive OpenStreetMap view centered on a default location.

I implemented waypoint placement by detecting map taps and adding a marker at the tapped latitude and longitude.

I created a waypoint list panel containing information such as:

- Waypoint position
- Altitude
- Speed parameters

I added waypoint editing functionality so that users can:

- Reorder waypoints using drag-and-drop
- Tap a waypoint to edit its parameters
- Swipe to delete a waypoint

For mission persistence, I implemented JSON-based saving and loading. Missions can be saved to local storage and loaded using a file picker.

I also calculated and displayed mission statistics including:

- Total mission distance
- Estimated mission time

These features match the mission-planning requirements specified in the Day 6 document. fileciteturn0file5L7-L15

## What I Learned

- How to integrate interactive maps into Flutter using `flutter_map`.
- How map coordinates can be converted into application waypoints.
- How gesture handling can be used for map interaction.
- How to manage dynamic lists using add, remove, and update operations.
- How drag-and-drop can improve waypoint management.
- How JSON can be used as a lightweight format for mission persistence.
- How local file I/O can be integrated into a Flutter application.
- How mission statistics such as distance and estimated time can be derived from waypoint data.
- How a map-based UI can be combined with traditional Flutter widgets to create a practical mission-planning tool.
