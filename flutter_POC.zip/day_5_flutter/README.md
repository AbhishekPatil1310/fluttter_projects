# Day 5 Flutter Alert System

Independent Linux alert center defining AlertLevel and Alert models, retaining the latest ten alerts, SnackBar notifications for lower severity, and acknowledgment dialogs for critical/emergency scenarios. Buttons cover battery, GPS, and geofence events.

Run with `flutter pub get` then `flutter run -d linux`. Build with `flutter build linux`. Audio is documented as a remaining integration because no sound asset was supplied.