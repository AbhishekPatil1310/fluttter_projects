import 'dart:async';

import 'package:flutter/material.dart';

void main() => runApp(const AlertApp());

enum AlertLevel { info, warning, critical, emergency }

class Alert {
  Alert(this.message, this.level) : timestamp = DateTime.now();
  final String message;
  final AlertLevel level;
  final DateTime timestamp;
}

class AlertService extends ChangeNotifier {
  final List<Alert> history = [];
  void emit(String message, AlertLevel level) {
    history.insert(0, Alert(message, level));
    if (history.length > 10) history.removeLast();
    notifyListeners();
  }
}

class AlertApp extends StatelessWidget {
  const AlertApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      colorScheme: ColorScheme.fromSeed(
        seedColor: Colors.orange,
        brightness: Brightness.dark,
      ),
      scaffoldBackgroundColor: const Color(0xFF15191C),
    ),
    home: const AlertScreen(),
  );
}

class MyApp extends AlertApp {
  const MyApp({super.key});
}

class AlertScreen extends StatefulWidget {
  const AlertScreen({super.key});
  @override
  State<AlertScreen> createState() => _AlertScreenState();
}

class _AlertScreenState extends State<AlertScreen> {
  final service = AlertService();
  Timer? timer;
  @override
  void initState() {
    super.initState();
    service.addListener(() => setState(() {}));
    timer = Timer.periodic(
      const Duration(seconds: 8),
      (_) => service.emit('Battery telemetry updated', AlertLevel.info),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    service.dispose();
    super.dispose();
  }

  Color color(AlertLevel level) => switch (level) {
    AlertLevel.info => Colors.lightBlue,
    AlertLevel.warning => Colors.amber,
    AlertLevel.critical => Colors.orange,
    AlertLevel.emergency => Colors.redAccent,
  };
  void trigger(AlertLevel level, String text) {
    service.emit(text, level);
    if (level.index >= AlertLevel.critical.index) {
      showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          title: Text(level.name.toUpperCase()),
          content: Text(text),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('ACKNOWLEDGE'),
            ),
          ],
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('NOMAD / ALERT CENTER')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'SCENARIO CONTROLS',
            style: TextStyle(color: Colors.orangeAccent, letterSpacing: 2),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              FilledButton(
                onPressed: () =>
                    trigger(AlertLevel.warning, 'Battery below 50%'),
                child: const Text('LOW BATTERY'),
              ),
              FilledButton(
                onPressed: () =>
                    trigger(AlertLevel.critical, 'GPS signal lost'),
                child: const Text('GPS LOST'),
              ),
              FilledButton(
                onPressed: () =>
                    trigger(AlertLevel.emergency, 'Geofence breach detected'),
                child: const Text('GEOFENCE BREACH'),
              ),
            ],
          ),
          const SizedBox(height: 28),
          const Text(
            'ALERT HISTORY',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: service.history.isEmpty
                ? const Center(child: Text('No alerts recorded'))
                : ListView.builder(
                    itemCount: service.history.length,
                    itemBuilder: (_, index) {
                      final alert = service.history[index];
                      return Card(
                        child: ListTile(
                          leading: Icon(
                            Icons.circle,
                            color: color(alert.level),
                          ),
                          title: Text(alert.message),
                          subtitle: Text(
                            '${alert.level.name.toUpperCase()}  •  ${alert.timestamp.hour.toString().padLeft(2, '0')}:${alert.timestamp.minute.toString().padLeft(2, '0')}',
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    ),
  );
}
