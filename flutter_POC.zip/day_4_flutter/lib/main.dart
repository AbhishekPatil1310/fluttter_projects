import 'package:flutter/material.dart';

void main() => runApp(const NavigationApp());

class NavigationApp extends StatelessWidget {
  const NavigationApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'UGV Navigation',
        theme: ThemeData.dark(useMaterial3: true).copyWith(scaffoldBackgroundColor: const Color(0xFF111A20), colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF54D1B0), brightness: Brightness.dark)),
        initialRoute: '/dashboard',
        routes: {'/dashboard': (_) => const Shell(), '/mission': (_) => const MissionScreen(), '/logs': (_) => const LogsScreen(), '/settings': (_) => const SettingsScreen()},
      );
}
class MyApp extends NavigationApp { const MyApp({super.key}); }

class Shell extends StatefulWidget { const Shell({super.key}); @override State<Shell> createState() => _ShellState(); }
class _ShellState extends State<Shell> {
  int selected = 0;
  final pages = const [Dashboard(), MissionScreen(), LogsScreen()];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(['DASHBOARD', 'MISSION PLANNER', 'SYSTEM LOGS'][selected])),
    drawer: Drawer(child: ListView(children: [const DrawerHeader(child: Text('NOMAD-07\nFIELD VEHICLE', style: TextStyle(fontSize: 22))), ListTile(leading: const Icon(Icons.dashboard), title: const Text('Dashboard'), onTap: () { Navigator.pop(context); setState(() => selected = 0); }), ListTile(leading: const Icon(Icons.settings), title: const Text('Settings'), onTap: () => Navigator.pushNamed(context, '/settings'))])),
    body: pages[selected],
    bottomNavigationBar: NavigationBar(selectedIndex: selected, onDestinationSelected: (value) => setState(() => selected = value), destinations: const [NavigationDestination(icon: Icon(Icons.dashboard), label: 'Dashboard'), NavigationDestination(icon: Icon(Icons.route), label: 'Mission'), NavigationDestination(icon: Icon(Icons.list_alt), label: 'Logs')]),
  );
}
class Dashboard extends StatelessWidget { const Dashboard({super.key}); @override Widget build(BuildContext context) => const Center(child: Text('SYSTEM DASHBOARD\n\nBattery 72%    GPS 14 FIX    Link 87%', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, height: 2))); }
class MissionScreen extends StatelessWidget { const MissionScreen({super.key}); @override Widget build(BuildContext context) => const Center(child: Text('MISSION PLANNER\n\nNo active route', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, height: 2))); }
class LogsScreen extends StatelessWidget { const LogsScreen({super.key}); @override Widget build(BuildContext context) => DefaultTabController(length: 3, child: Column(children: [const TabBar(tabs: [Tab(text: 'Telemetry'), Tab(text: 'Alerts'), Tab(text: 'Missions')]), Expanded(child: TabBarView(children: [ListView(children: const [ListTile(title: Text('14:32:06'), subtitle: Text('Battery telemetry received')), ListTile(title: Text('14:31:59'), subtitle: Text('GPS fix updated'))]), const Center(child: Text('No active alerts')), const Center(child: Text('Survey perimeter / 12 waypoints'))]))])); }
class SettingsScreen extends StatelessWidget { const SettingsScreen({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: const [Text('SETTINGS', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)), SwitchListTile(value: true, onChanged: null, title: Text('Telemetry stream')), SwitchListTile(value: false, onChanged: null, title: Text('High contrast mode'))]); }
