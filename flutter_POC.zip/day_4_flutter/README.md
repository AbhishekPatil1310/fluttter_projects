# Day 4 Flutter Navigation

Independent Linux navigation app with dashboard, mission planner, logs, settings, named routes, drawer navigation, bottom navigation, and nested telemetry, alerts, and missions log tabs.

Run with `flutter pub get` then `flutter run -d linux`. Build with `flutter build linux`. Uses Flutter/Dart and Material 3 only.