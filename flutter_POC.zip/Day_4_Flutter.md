# Day 4 – Navigation and Routing

## Task

The goal was to implement a complete navigation structure for the Flutter application. The required application screens were:

- Dashboard
- Mission Planner
- Logs
- Settings

The task covered named routes, route arguments, bottom navigation, drawer navigation, screen transitions, and nested tabs. fileciteturn0file3L5-L18

## How I Completed It

I created the required screen files:

- `dashboard_screen.dart`
- `mission_planner_screen.dart`
- `logs_screen.dart`
- `settings_screen.dart`

I configured named routes in `MaterialApp` and implemented a `BottomNavigationBar` containing the primary sections:

- Dashboard
- Mission
- Logs

I added a `Drawer` to the application `AppBar` for secondary navigation options and included a user profile section.

I also implemented passing data between screens using route arguments.

For the Logs screen, I created nested tabs for:

- Telemetry
- Alerts
- Missions

This produced a navigation hierarchy where the main application sections are available through bottom navigation and drawer navigation, while related log information is organized through tabs. fileciteturn0file3L10-L18

## What I Learned

- How Flutter navigation works using routes.
- The difference between named routes and anonymous routes.
- How to pass data between screens.
- How to use `BottomNavigationBar` for primary navigation.
- How a `Drawer` can provide secondary navigation.
- How `TabBar` can organize related information within a screen.
- How nested navigation structures can be used to keep complex applications organized.
- How proper navigation architecture improves the usability and scalability of a Flutter application.
