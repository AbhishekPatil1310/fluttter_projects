# Day 2 – Dashboard Layout

## Task

The goal was to create a responsive dashboard layout for a ground-control-style Flutter application. The required layout consisted of four major areas:

- Top status bar
- Left controls panel
- Center map placeholder
- Right telemetry panel

The task also required the dashboard to adapt to desktop, tablet, and mobile screen sizes. The specification required consistent spacing, status indicators, connection status, battery information, and placeholders for GCS components. fileciteturn0file1L9-L18

## How I Completed It

I created `dashboard_screen.dart` and structured the interface using Flutter layout widgets such as:

- `Container`
- `Row`
- `Column`
- `Stack`
- `Expanded`
- `Flexible`

I implemented responsive behavior using `MediaQuery`. The dashboard changes its structure according to the available screen size:

- Desktop: four-panel layout
- Tablet: three-panel layout
- Mobile: single-column layout

I also applied consistent spacing using padding, margins, and `SizedBox`, while using color-coded status indicators for different system states. The dashboard included connection status, battery information, and placeholder areas for the remaining GCS components. fileciteturn0file1L5-L16

## What I Learned

- How `Row`, `Column`, `Stack`, `Expanded`, and `Flexible` work together to build complex Flutter layouts.
- How to make Flutter interfaces responsive using `MediaQuery`.
- How breakpoints can be used to change the UI structure for different screen sizes.
- The difference between padding, margin, and fixed spacing using `SizedBox`.
- How `SafeArea` helps prevent UI elements from being placed in unsafe screen areas.
- How Material Design principles and consistent spacing improve readability and visual hierarchy.
- How to design a dashboard that can work across different display sizes.
