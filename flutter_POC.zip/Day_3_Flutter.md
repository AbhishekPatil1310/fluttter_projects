# Day 3 – State Management and Animations

## Task

The goal was to create reusable status components and introduce dynamic state updates and animations. The main component was a custom `StatusCard` that displays values such as battery percentage, GPS satellites, connection strength, and armed/disarmed status. fileciteturn0file2L9-L17

The task required:

- Understanding Stateless and Stateful widgets
- Using `setState()`
- Creating reusable custom widgets
- Updating simulated values periodically
- Animating status changes
- Managing custom assets

## How I Completed It

I created a reusable `StatusCard` widget and made it state-aware so that its displayed information could change dynamically.

I added status cards for:

- Battery
- GPS satellites
- Connection strength
- Armed/disarmed state

For the battery indicator, I used threshold-based status colors:

- Red: below 20%
- Yellow: below 50%
- Green: 50% and above

I implemented a `Timer` to update simulated values every two seconds. I used `AnimatedContainer` to provide smooth visual transitions when the status changes and added a pulsing animation for the armed indicator.

I also created an assets directory, added custom icons, and configured the assets through `pubspec.yaml`. fileciteturn0file2L5-L15

## What I Learned

- The difference between `StatelessWidget` and `StatefulWidget`.
- How `setState()` triggers UI updates in Flutter.
- How to create reusable custom widgets instead of duplicating UI code.
- How timers and periodic callbacks can simulate real-time data updates.
- How `AnimatedContainer` can make state transitions smoother.
- How animation can improve visual feedback without adding unnecessary UI elements.
- How to add and manage custom assets through `pubspec.yaml`.
- How status thresholds can convert raw telemetry values into meaningful visual feedback.
