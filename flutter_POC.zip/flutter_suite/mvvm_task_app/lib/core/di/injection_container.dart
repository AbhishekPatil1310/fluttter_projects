import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

// Services
import '../../data/services/alert_service.dart';
import '../../data/services/file_service.dart';
import '../../data/services/telemetry_service.dart';

// Repositories
import '../../data/repositories/alert_repository.dart';
import '../../data/repositories/mission_repository.dart';
import '../../data/repositories/telemetry_repository.dart';

// ViewModels
import '../../ui/alerts/view_models/alerts_view_model.dart';
import '../../ui/dashboard/view_models/dashboard_view_model.dart';
import '../../ui/logs/view_models/logs_view_model.dart';
import '../../ui/mission/view_models/mission_view_model.dart';
import '../../ui/navigation/view_models/navigation_view_model.dart';
import '../../ui/settings/view_models/settings_view_model.dart';

class InjectionContainer {
  static Widget configure({required Widget child}) {
    return MultiProvider(
      providers: [
        // =========================
        // SERVICES
        // =========================

        Provider<TelemetryService>(
          create: (_) => TelemetryService(),
        ),

        Provider<AlertService>(
          create: (_) => AlertService(),
        ),

        Provider<FileService>(
          create: (_) => FileService(),
        ),

        // =========================
        // REPOSITORIES
        // =========================

        Provider<TelemetryRepository>(
          create: (context) => TelemetryRepository(
            context.read<TelemetryService>(),
          ),
        ),

        ChangeNotifierProvider<AlertRepository>(
          create: (context) => AlertRepository(
            context.read<AlertService>(),
          ),
        ),

        ChangeNotifierProvider<MissionRepository>(
          create: (context) => MissionRepository(
            context.read<FileService>(),
          ),
        ),

        // =========================
        // VIEWMODELS
        // =========================

        ChangeNotifierProvider(
          create: (context) => NavigationViewModel(),
        ),

        ChangeNotifierProvider(
          create: (context) => DashboardViewModel(
            context.read<TelemetryRepository>(),
          ),
        ),

        ChangeNotifierProvider(
          create: (context) => MissionViewModel(
            context.read<MissionRepository>(),
          ),
        ),

        ChangeNotifierProvider(
          create: (context) => AlertsViewModel(
            context.read<AlertRepository>(),
          ),
        ),

        ChangeNotifierProvider(
          create: (context) => LogsViewModel(
            context.read<TelemetryRepository>(),
            context.read<AlertRepository>(),
            context.read<MissionRepository>()
          ),
        ),

        ChangeNotifierProvider(
          create: (_) => SettingsViewModel(),
        ),
      ],
      child: child,
    );
  }
}