import 'package:flutter/material.dart';

import 'config/app_config.dart';
import 'core/di/injection_container.dart';
import 'routing/app_router.dart';

void main() {
  runApp(
    InjectionContainer.configure(
      child: const NomadControlApp(),
    ),
  );
}

class NomadControlApp extends StatelessWidget {
  const NomadControlApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      theme: AppConfig.theme,
      onGenerateRoute: AppRouter.onGenerateRoute,
      initialRoute: AppRouter.dashboard,
    );
  }
}