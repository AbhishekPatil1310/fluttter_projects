import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../../../domain/models/waypoint.dart';

class MissionMap extends StatelessWidget {
  const MissionMap({
    super.key,
    required this.waypoints,
    required this.onMapTap,
    required this.onWaypointTap,
  });

  final List<Waypoint> waypoints;
  final ValueChanged<LatLng> onMapTap;
  final ValueChanged<int> onWaypointTap;

  static const LatLng _initialCenter = LatLng(
    18.01915726783933,
    77.00772518934573,
  );

  @override
  Widget build(BuildContext context) {
    return FlutterMap(
      options: MapOptions(
        initialCenter: _initialCenter,
        initialZoom: 13,
        onTap: (_, point) => onMapTap(point),
      ),
      children: [
        TileLayer(
          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          userAgentPackageName: 'com.example.nomad_control',
        ),
        if (waypoints.length >= 2)
          PolylineLayer(
            polylines: [
              Polyline(
                points: waypoints.map((waypoint) => waypoint.position).toList(),
                strokeWidth: 4,
                color: Colors.blue,
              ),
            ],
          ),
        MarkerLayer(
          markers: [
            for (var index = 0; index < waypoints.length; index++)
              Marker(
                point: waypoints[index].position,
                width: 44,
                height: 44,
                child: GestureDetector(
                  onTap: () => onWaypointTap(index),
                  child: CircleAvatar(
                    backgroundColor: Colors.blue,
                    child: Text(
                      '${index + 1}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ],
    );
  }
}