import 'package:flutter/material.dart';

import '../../../domain/models/waypoint.dart';

class WaypointPanel extends StatelessWidget {
  const WaypointPanel({
    super.key,
    required this.waypoints,
    required this.totalDistanceKm,
    required this.estimatedMinutes,
    required this.busy,
    required this.error,
    required this.onEdit,
    required this.onRemove,
    required this.onReorder,
    required this.onSave,
    required this.onLoad,
  });

  final List<Waypoint> waypoints;
  final double totalDistanceKm;
  final double estimatedMinutes;
  final bool busy;
  final String? error;

  final ValueChanged<int> onEdit;
  final ValueChanged<int> onRemove;
  final void Function(int oldIndex, int newIndex) onReorder;
  final VoidCallback onSave;
  final VoidCallback onLoad;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 320,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Mission Waypoints (${waypoints.length})',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: busy ? null : onLoad,
                    icon: const Icon(Icons.folder_open),
                    label: const Text('Load'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: busy ? null : onSave,
                    icon: const Icon(Icons.save),
                    label: const Text('Save'),
                  ),
                ),
              ],
            ),

            if (busy) ...[
              const SizedBox(height: 12),
              const LinearProgressIndicator(),
            ],

            if (error != null) ...[
              const SizedBox(height: 12),
              Text(
                error!,
                style: TextStyle(
                  color: Theme.of(context).colorScheme.error,
                ),
              ),
            ],

            const Divider(height: 24),

            Expanded(
              child: waypoints.isEmpty
                  ? const Center(
                      child: Text('Tap on the map to add a waypoint.'),
                    )
                  : ReorderableListView.builder(
  itemCount: waypoints.length,
  onReorder: onReorder,
  itemBuilder: (context, index) {
    final waypoint = waypoints[index];

    return Dismissible(
      key: ValueKey('waypoint-$index'),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        color: Theme.of(context).colorScheme.error,
        child: const Icon(
          Icons.delete,
          color: Colors.white,
        ),
      ),
      onDismissed: (_) => onRemove(index),
      child: ListTile(
        leading: CircleAvatar(
          child: Text('${index + 1}'),
        ),
        title: Text(
          '${waypoint.position.latitude.toStringAsFixed(5)}, '
          '${waypoint.position.longitude.toStringAsFixed(5)}',
        ),
        subtitle: Text(
          'Altitude: ${waypoint.altitude} m\n'
          'Speed: ${waypoint.speed} m/s',
        ),
        isThreeLine: true,
        onTap: () => onEdit(index),
        trailing: const Icon(Icons.drag_handle),
      ),
    );
  },
),
            ),

            const Divider(height: 24),

            Text(
              'Distance: ${totalDistanceKm.toStringAsFixed(2)} km',
            ),
            const SizedBox(height: 4),
            Text(
              'Estimated time: ${estimatedMinutes.toStringAsFixed(1)} min',
            ),
          ],
        ),
      ),
    );
  }
}