import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:latlong2/latlong.dart';

import '../../../data/repositories/mission_repository.dart';
import '../../../domain/models/waypoint.dart';

class MissionViewModel extends ChangeNotifier {
  MissionViewModel(this._repository) {
    _waypoints = _repository.waypoints;
  }

  final MissionRepository _repository;
  List<Waypoint> _waypoints = const [];
  String? _error;
  bool _busy = false;

  List<Waypoint> get waypoints => List.unmodifiable(_waypoints);    //exposing the state to the ui
  String? get error => _error;
  bool get busy => _busy;

  double get totalDistanceKm {
    const distance = Distance();
    var total = 0.0;
    for (var i = 1; i < _waypoints.length; i++) {
      total += distance.as(
        LengthUnit.Kilometer,
        _waypoints[i - 1].position,
        _waypoints[i].position,
      );
    }
    return total;
  }

  double get estimatedMinutes {
    if (_waypoints.isEmpty) return 0;
    final averageSpeed = _waypoints.fold<double>(0, (sum, item) => sum + item.speed) /
        _waypoints.length;
    if (averageSpeed <= 0) return 0;
    return (totalDistanceKm * 1000 / averageSpeed) / 60;
  }

  void addWaypoint(LatLng position) {
    _setWaypoints([..._waypoints, Waypoint(position: position)]);
  }

  void updateWaypoint(int index, {double? altitude, double? speed}) {
    if (index < 0 || index >= _waypoints.length) return;
    final updated = _waypoints[index].copyWith(
      altitude: altitude,
      speed: speed,
    );
    final next = [..._waypoints]..[index] = updated;
    _setWaypoints(next);
  }

  void removeWaypoint(int index) {
    if (index < 0 || index >= _waypoints.length) return;
    final next = [..._waypoints]..removeAt(index);
    _setWaypoints(next);
  }

  void reorderWaypoint(int oldIndex, int newIndex) {
    final next = [..._waypoints];
    final item = next.removeAt(oldIndex);
    next.insert(math.min(newIndex, next.length), item);
    _setWaypoints(next);
  }

  Future<bool> saveMission() async {
    _busy = true;
    _error = null;
    notifyListeners();
    try {
      await _repository.save();
      return true;
    } catch (e) {
      _error = 'Unable to save mission: $e';
      return false;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  Future<bool> loadMission() async {
    _busy = true;
    _error = null;
    notifyListeners();
    try {
      final loaded = await _repository.load();
      if (loaded == null) return false;
      _waypoints = loaded;
      notifyListeners();
      return true;
    } catch (_) {
      _error = 'Invalid mission JSON';
      return false;
    } finally {
      _busy = false;
      notifyListeners();
    }
  }

  void _setWaypoints(List<Waypoint> value) {
    _waypoints = List.unmodifiable(value);
    _repository.replace(_waypoints);
    notifyListeners();
  }
}
