import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../view_models/mission_view_model.dart';
import '../widgets/mission_map.dart';
import '../widgets/waypoint_panel.dart';

class MissionScreen extends StatelessWidget {
  const MissionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<MissionViewModel>();
    final waypoints = vm.waypoints;

    return Scaffold(
      body: Row(
        children: [
          Expanded(
            child: MissionMap(
              waypoints: waypoints,
              onMapTap: vm.addWaypoint,
              onWaypointTap: (index) => _editWaypoint(context, vm, index),
            ),
          ),
          WaypointPanel(
            waypoints: waypoints,
            totalDistanceKm: vm.totalDistanceKm,
            estimatedMinutes: vm.estimatedMinutes,
            busy: vm.busy,
            error: vm.error,
            onEdit: (index) => _editWaypoint(context, vm, index),
            onRemove: vm.removeWaypoint,
            onReorder: vm.reorderWaypoint,
            onSave: () => _saveMission(context, vm),
            onLoad: () => _loadMission(context, vm),
          ),
        ],
      ),
    );
  }

  Future<void> _editWaypoint(
    BuildContext context,
    MissionViewModel vm,
    int index,
  ) async {
    if (index < 0 || index >= vm.waypoints.length) return;

    final waypoint = vm.waypoints[index];

    final altitudeController = TextEditingController(
      text: waypoint.altitude.toString(),
    );
    final speedController = TextEditingController(
      text: waypoint.speed.toString(),
    );

    final result = await showDialog<_WaypointEditResult>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text('Edit Waypoint ${index + 1}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: altitudeController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Altitude (m)',
                ),
              ),
              TextField(
                controller: speedController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Speed (m/s)',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final altitude = double.tryParse(altitudeController.text);
                final speed = double.tryParse(speedController.text);

                if (altitude == null || speed == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Enter valid altitude and speed values.'),
                    ),
                  );
                  return;
                }

                Navigator.pop(
                  dialogContext,
                  _WaypointEditResult(
                    altitude: altitude,
                    speed: speed,
                  ),
                );
              },
              child: const Text('Apply'),
            ),
          ],
        );
      },
    );

    altitudeController.dispose();
    speedController.dispose();

    if (result != null) {
      vm.updateWaypoint(
        index,
        altitude: result.altitude,
        speed: result.speed,
      );
    }
  }

  Future<void> _saveMission(
    BuildContext context,
    MissionViewModel vm,
  ) async {
    final success = await vm.saveMission();
    if (!context.mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          success ? 'Mission saved.' : vm.error ?? 'Unable to save mission.',
        ),
      ),
    );
  }

  Future<void> _loadMission(
    BuildContext context,
    MissionViewModel vm,
  ) async {
    final success = await vm.loadMission();
    if (!context.mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          success ? 'Mission loaded.' : vm.error ?? 'No saved mission found.',
        ),
      ),
    );
  }
}

class _WaypointEditResult {
  const _WaypointEditResult({
    required this.altitude,
    required this.speed,
  });

  final double altitude;
  final double speed;
}