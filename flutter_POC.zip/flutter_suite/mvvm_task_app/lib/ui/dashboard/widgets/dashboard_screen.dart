import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/ui/app_panel.dart';
import '../../core/ui/status_metric.dart';
import '../view_models/dashboard_view_model.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<DashboardViewModel>();

    return LayoutBuilder(
      builder: (context, constraints) {
        final narrow = constraints.maxWidth < 850;

        if (narrow) {
          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              const SizedBox(height: 260, child: _MapPlaceholder()),
              const SizedBox(height: 12),
              SizedBox(
                height: 250,
                child: _Controls(
                  isArmed: vm.isArmed,
                  isConnected: vm.isConnected,
                  onArmPressed: () => vm.toggleArmState(true),
                  onDisarmPressed: () => vm.toggleArmState(false),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 300,
                child: _Telemetry(telemetry: vm.telemetry),
              ),
            ],
          );
        }

        return Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                width: constraints.maxWidth < 1100 ? 210 : 250,
                child: _Controls(
                  isArmed: vm.isArmed,
                  isConnected: vm.isConnected,
                  onArmPressed: () => vm.toggleArmState(true),
                  onDisarmPressed: () => vm.toggleArmState(false),
                ),
              ),
              const SizedBox(width: 16),
              const Expanded(child: _MapPlaceholder()),
              const SizedBox(width: 16),
              SizedBox(
                width: constraints.maxWidth < 1100 ? 240 : 290,
                child: _Telemetry(telemetry: vm.telemetry),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _Controls extends StatelessWidget {
  const _Controls({
    required this.isArmed,
    required this.isConnected,
    required this.onArmPressed,
    required this.onDisarmPressed,
  });

  final bool isArmed;
  final bool isConnected;
  final VoidCallback onArmPressed;
  final VoidCallback onDisarmPressed;

  @override
  Widget build(BuildContext context) {
    return AppPanel(
      title: 'CONTROL INPUTS',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            height: 44,
            child: FilledButton.icon(
              onPressed: isArmed ? null : onArmPressed,
              icon: const Icon(Icons.lock_open),
              label: const Text('ARM VEHICLE'),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 44,
            child: OutlinedButton.icon(
              onPressed: isArmed ? onDisarmPressed : null,
              icon: const Icon(Icons.lock),
              label: const Text('DISARM VEHICLE'),
            ),
          ),
          const Spacer(),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: Icon(
              Icons.circle,
              size: 12,
              color: isConnected ? Colors.green : Colors.red,
            ),
            title: Text(isConnected ? 'Vehicle online' : 'Vehicle offline'),
            subtitle: const Text('NOMAD-07'),
          ),
        ],
      ),
    );
  }
}

class _MapPlaceholder extends StatelessWidget {
  const _MapPlaceholder();

  @override
  Widget build(BuildContext context) => AppPanel(
        title: 'LIVE MAP / PLACEHOLDER',
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFF203642),
            border: Border.all(color: Colors.white12),
          ),
          child: const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.map_outlined, size: 64),
                SizedBox(height: 12),
                Text('MAP VIEW READY'),
                Text(
                  'Position: 37.7749 N, 122.4194 W',
                  style: TextStyle(color: Colors.white54),
                ),
              ],
            ),
          ),
        ),
      );
}

class _Telemetry extends StatelessWidget {
  const _Telemetry({required this.telemetry});

  final dynamic telemetry;

  @override
  Widget build(BuildContext context) {
    return AppPanel(
      title: 'TELEMETRY',
      child: GridView.count(
        crossAxisCount: 1,
        childAspectRatio: 3.1,
        mainAxisSpacing: 8,
        children: [
          StatusMetric(
            label: 'Battery',
            value: '${telemetry.battery}%',
            icon: Icons.battery_6_bar,
            color: telemetry.battery < 20
                ? Colors.redAccent
                : telemetry.battery < 50
                    ? Colors.amber
                    : Colors.greenAccent,
          ),
          StatusMetric(
            label: 'Speed',
            value: '${telemetry.speed.toStringAsFixed(1)} m/s',
            icon: Icons.speed,
            color: Colors.white,
          ),
          StatusMetric(
            label: 'GPS satellites',
            value: '${telemetry.satellites} FIX',
            icon: Icons.gps_fixed,
            color: Colors.lightBlueAccent,
          ),
          StatusMetric(
            label: 'Heading',
            value: '${telemetry.heading.toString().padLeft(3, '0')}°',
            icon: Icons.explore,
            color: Colors.orangeAccent,
          ),
        ],
      ),
    );
  }
}