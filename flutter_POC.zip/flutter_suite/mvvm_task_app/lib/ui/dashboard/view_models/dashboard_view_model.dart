import 'dart:async';
import 'package:flutter/foundation.dart';
import '../../../data/repositories/telemetry_repository.dart';
import '../../../domain/models/telemetry.dart';

class DashboardViewModel extends ChangeNotifier {
  DashboardViewModel(this._repository) {
    _subscription = _repository.stream.listen(
      (telemetry) {
        _telemetry = telemetry;
        notifyListeners();
      },
    );
  }

  final TelemetryRepository _repository;
  StreamSubscription<Telemetry>? _subscription;
  Telemetry? _telemetry;

  // Default fallback state when repository hasn't emitted yet
  Telemetry get telemetry =>
      _telemetry ??
      Telemetry(
        battery: 76,
        satellites: 14,
        connection: 90,
        speed: 0,
        heading: 84,
        armed: false,
        timestamp: DateTime.now(),
      );

  bool get isArmed => telemetry.armed;
  bool get isConnected => telemetry.connection > 50;

  // Business Action
  void toggleArmState(bool arm) {
    _repository.setArmed(arm);
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}