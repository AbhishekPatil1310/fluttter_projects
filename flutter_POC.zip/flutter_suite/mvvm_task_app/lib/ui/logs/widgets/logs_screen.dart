import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../view_models/logs_view_model.dart';

class LogsScreen extends StatelessWidget {
  const LogsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<LogsViewModel>();

    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          const TabBar(
            tabs: [
              Tab(text: 'Telemetry'),
              Tab(text: 'Alerts'),
              Tab(text: 'Missions'),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: [
                // Telemetry logs
                ListView.builder(
                  itemCount: vm.telemetryEntries.length,
                  itemBuilder: (_, index) {
                    final t = vm.telemetryEntries[index];

                    return ListTile(
                      title: Text(_time(t.timestamp)),
                      subtitle: Text(
                        'Battery ${t.battery}% • '
                        'GPS ${t.satellites} • '
                        'Link ${t.connection}% • '
                        'Speed ${t.speed.toStringAsFixed(1)} m/s',
                      ),
                    );
                  },
                ),

                // Alert logs
                ListView.builder(
                  itemCount: vm.alerts.length,
                  itemBuilder: (_, index) {
                    final a = vm.alerts[index];

                    return ListTile(
                      title: Text(_time(a.timestamp)),
                      subtitle: Text(
                        '${a.level.name.toUpperCase()}: ${a.message}',
                      ),
                    );
                  },
                ),

                // Mission logs
                vm.missionLogs.isEmpty
                    ? const Center(
                        child: Text('No mission history available'),
                      )
                    : ListView.builder(
                        itemCount: vm.missionLogs.length,
                        itemBuilder: (_, index) {
                          final mission = vm.missionLogs[index];

                          return ListTile(
                            leading: const Icon(Icons.route),
                            title: Text(mission.message),
                            subtitle: Text(
                              '${mission.type.name} • '
                              '${_time(mission.timestamp)}',
                            ),
                          );
                        },
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static String _time(DateTime time) =>
      '${time.hour.toString().padLeft(2, '0')}:'
      '${time.minute.toString().padLeft(2, '0')}:'
      '${time.second.toString().padLeft(2, '0')}';
}