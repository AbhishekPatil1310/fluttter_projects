import 'dart:async';

import 'package:flutter/foundation.dart';

import '../../../data/repositories/alert_repository.dart';
import '../../../data/repositories/mission_repository.dart';
import '../../../data/repositories/telemetry_repository.dart';
import '../../../domain/models/alert.dart';
import '../../../domain/models/mission_log.dart';
import '../../../domain/models/telemetry.dart';

class LogsViewModel extends ChangeNotifier {
  LogsViewModel(
    this._telemetry,
    this._alerts,
    this._missions,
  ) {
    _telemetrySubscription = _telemetry.stream.listen((value) {
      _telemetryEntries.insert(0, value);

      if (_telemetryEntries.length > 50) {
        _telemetryEntries.removeLast();
      }

      notifyListeners();
    });

    _alerts.addListener(notifyListeners);
    _missions.addListener(notifyListeners);
  }

  final TelemetryRepository _telemetry;
  final AlertRepository _alerts;
  final MissionRepository _missions;

  final List<Telemetry> _telemetryEntries = [];
  StreamSubscription<Telemetry>? _telemetrySubscription;

  List<Telemetry> get telemetryEntries =>
      List.unmodifiable(_telemetryEntries);

  List<Alert> get alerts => _alerts.history;

  List<MissionLog> get missionLogs => _missions.history;

  @override
  void dispose() {
    _telemetrySubscription?.cancel();
    _alerts.removeListener(notifyListeners);
    _missions.removeListener(notifyListeners);
    super.dispose();
  }
}