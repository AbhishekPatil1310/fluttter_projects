import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../view_models/settings_view_model.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<SettingsViewModel>();
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('SETTINGS', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        SwitchListTile(
          value: vm.telemetryEnabled,
          onChanged: vm.setTelemetryEnabled,
          title: const Text('Telemetry stream'),
        ),
        SwitchListTile(
          value: vm.highContrast,
          onChanged: vm.setHighContrast,
          title: const Text('High contrast mode'),
        ),
      ],
    );
  }
}
