import 'package:flutter/foundation.dart';

class SettingsViewModel extends ChangeNotifier {
  bool _telemetryEnabled = true;
  bool _highContrast = false;

  bool get telemetryEnabled => _telemetryEnabled;
  bool get highContrast => _highContrast;

  void setTelemetryEnabled(bool value) {
    _telemetryEnabled = value;
    notifyListeners();
  }

  void setHighContrast(bool value) {
    _highContrast = value;
    notifyListeners();
  }
}
