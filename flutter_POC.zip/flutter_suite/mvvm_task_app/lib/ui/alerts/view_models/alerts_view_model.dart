import 'package:flutter/foundation.dart';

import '../../../data/repositories/alert_repository.dart';
import '../../../domain/models/alert.dart';

class AlertsViewModel extends ChangeNotifier {
  AlertsViewModel(this._repository) {
    _repository.addListener(notifyListeners);
  }

  final AlertRepository _repository;
  Alert? _pendingCriticalAlert;

  List<Alert> get history => _repository.history;
  Alert? get pendingCriticalAlert => _pendingCriticalAlert;

  void trigger(AlertLevel level, String message) {
    _repository.emit(message, level);
    if (level.index >= AlertLevel.critical.index) {
      _pendingCriticalAlert = _repository.history.first;
      notifyListeners();
    }
  }

  void clearPendingCriticalAlert() {
    _pendingCriticalAlert = null;
    notifyListeners();
  }

  void acknowledge(int index) => _repository.acknowledge(index);

  @override
  void dispose() {
    _repository.removeListener(notifyListeners);
    super.dispose();
  }
}
