import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../domain/models/alert.dart';
import '../view_models/alerts_view_model.dart';

class AlertsScreen extends StatelessWidget {
  const AlertsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<AlertsViewModel>();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final alert = vm.pendingCriticalAlert;
      if (alert == null || !context.mounted) return;
      vm.clearPendingCriticalAlert();
      showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          title: Text(alert.level.name.toUpperCase()),
          content: Text(alert.message),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('ACKNOWLEDGE'),
            ),
          ],
        ),
      );
    });
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('SCENARIO CONTROLS', style: TextStyle(letterSpacing: 2)),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              FilledButton(onPressed: () => _trigger(context, vm, AlertLevel.warning, 'Battery below 50%'), child: const Text('LOW BATTERY')),
              FilledButton(onPressed: () => _trigger(context, vm, AlertLevel.critical, 'GPS signal lost'), child: const Text('GPS LOST')),
              FilledButton(onPressed: () => _trigger(context, vm, AlertLevel.emergency, 'Geofence breach detected'), child: const Text('GEOFENCE BREACH')),
            ],
          ),
          const SizedBox(height: 28),
          const Text('ALERT HISTORY', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Expanded(
            child: vm.history.isEmpty
                ? const Center(child: Text('No alerts recorded'))
                : ListView.builder(
                    itemCount: vm.history.length,
                    itemBuilder: (context, index) {
                      final alert = vm.history[index];
                      return Card(
                        child: ListTile(
                          leading: Icon(Icons.circle, color: _color(alert.level)),
                          title: Text(alert.message),
                          subtitle: Text('${alert.level.name.toUpperCase()} • ${_time(alert.timestamp)}${alert.acknowledged ? ' • ACKNOWLEDGED' : ''}'),
                          trailing: alert.level.index >= AlertLevel.critical.index && !alert.acknowledged
                              ? TextButton(onPressed: () => vm.acknowledge(index), child: const Text('ACK'))
                              : null,
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  void _trigger(BuildContext context, AlertsViewModel vm, AlertLevel level, String message) {
    vm.trigger(level, message);
    if (level.index < AlertLevel.critical.index) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  static Color _color(AlertLevel level) => switch (level) {
        AlertLevel.info => Colors.lightBlue,
        AlertLevel.warning => Colors.amber,
        AlertLevel.critical => Colors.orange,
        AlertLevel.emergency => Colors.redAccent,
      };

  static String _time(DateTime time) => '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}:${time.second.toString().padLeft(2, '0')}';
}
