import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../alerts/widgets/alerts_screen.dart';
import '../../dashboard/widgets/dashboard_screen.dart';
import '../../logs/widgets/logs_screen.dart';
import '../../mission/screens/mission_screen.dart';
import '../../settings/widgets/settings_screen.dart';
import '../view_models/navigation_view_model.dart';

class NavigationShell extends StatelessWidget {
  const NavigationShell({super.key});

  static const _pages = [
    DashboardScreen(),
    MissionScreen(),
    AlertsScreen(),
    LogsScreen(),
    SettingsScreen(),
  ];

  static const _titles = [
    'DASHBOARD',
    'MISSION PLANNER',
    'ALERT CENTER',
    'SYSTEM LOGS',
    'SETTINGS',
  ];

  @override
  Widget build(BuildContext context) {
    final navigation = context.watch<NavigationViewModel>();
    return Scaffold(
      appBar: AppBar(title: Text('NOMAD / ${_titles[navigation.selectedIndex]}')),
      drawer: _drawer(context, navigation),
      body: IndexedStack(index: navigation.selectedIndex, children: _pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: navigation.selectedIndex,
        onDestinationSelected: navigation.select,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.route_outlined), label: 'Mission'),
          NavigationDestination(icon: Icon(Icons.warning_amber_outlined), label: 'Alerts'),
          NavigationDestination(icon: Icon(Icons.list_alt), label: 'Logs'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings'),
        ],
      ),
    );
  }

  Drawer _drawer(BuildContext context, NavigationViewModel navigation) => Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              child: Text('NOMAD-07\nFIELD VEHICLE', style: TextStyle(fontSize: 22)),
            ),
            for (var i = 0; i < _titles.length; i++)
              ListTile(
                selected: navigation.selectedIndex == i,
                title: Text(_titles[i]),
                onTap: () {
                  navigation.select(i);
                  Navigator.pop(context);
                },
              ),
          ],
        ),
      );
}
