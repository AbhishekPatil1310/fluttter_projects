import 'package:flutter/material.dart';
import '../ui/navigation/widgets/navigation_shell.dart';

abstract final class AppRouter {
  static const dashboard = '/dashboard';

  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case dashboard:
      default:
        return MaterialPageRoute(builder: (_) => const NavigationShell());
    }
  }
}
