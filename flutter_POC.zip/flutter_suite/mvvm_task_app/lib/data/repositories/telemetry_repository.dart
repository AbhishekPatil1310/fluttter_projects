import '../../domain/models/telemetry.dart';
import '../services/telemetry_service.dart';

class TelemetryRepository {
  TelemetryRepository(this._service) {
    _service.start();
  }

  final TelemetryService _service;
  Telemetry? _latest;

  Telemetry? get latest => _latest;
  Stream<Telemetry> get stream => _service.stream;

  void setArmed(bool armed) {
    _service.setArmed(armed);
  }
}
