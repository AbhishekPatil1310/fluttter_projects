import 'package:flutter/foundation.dart';

import '../../domain/models/alert.dart';
import '../services/alert_service.dart';

class AlertRepository extends ChangeNotifier {
  AlertRepository(this._service);

  final AlertService _service;

  List<Alert> get history => _service.history;

  void emit(String message, AlertLevel level) {
    _service.emit(message, level);
    notifyListeners();
  }

  void acknowledge(int index) {
    _service.acknowledge(index);
    notifyListeners();
  }
}
