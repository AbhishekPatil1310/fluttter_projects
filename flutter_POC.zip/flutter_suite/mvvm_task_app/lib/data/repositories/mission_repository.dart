import 'package:flutter/foundation.dart';

import '../../domain/models/mission_log.dart';
import '../../domain/models/waypoint.dart';
import '../services/file_service.dart';

class MissionRepository extends ChangeNotifier {
  MissionRepository(this._fileService);

  final FileService _fileService;

  List<Waypoint> _waypoints = const [];
  final List<MissionLog> _history = [];

  List<Waypoint> get waypoints => List.unmodifiable(_waypoints);
  List<MissionLog> get history => List.unmodifiable(_history);

  void _record(MissionLogType type, String message) {
    _history.insert(
      0,
      MissionLog(
        message: message,
        type: type,
        timestamp: DateTime.now(),
      ),
    );

    // Keep the most recent 100 mission events.
    if (_history.length > 100) {
      _history.removeLast();  
    }

    notifyListeners();
  }

  void replace(List<Waypoint> waypoints) {      //update the history list of events
    _waypoints = List.unmodifiable(waypoints);

    _record(
      MissionLogType.waypointUpdated,
      'Mission waypoints updated (${waypoints.length} waypoints)',
    );
  }

  Future<void> save() async {
    await _fileService.saveMission(_waypoints);

    _record(
      MissionLogType.missionSaved,
      'Mission saved (${_waypoints.length} waypoints)',
    );
  }

  Future<List<Waypoint>?> load() async {
    final loaded = await _fileService.loadMission();

    if (loaded != null) {
      _waypoints = List.unmodifiable(loaded);

      _record(
        MissionLogType.missionLoaded,
        'Mission loaded (${loaded.length} waypoints)',
      );

      return loaded;
    }

    return null;
  }
}