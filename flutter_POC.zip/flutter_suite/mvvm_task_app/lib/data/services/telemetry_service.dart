import 'dart:async';

import '../../domain/models/telemetry.dart';

class TelemetryService {
  final _controller = StreamController<Telemetry>.broadcast();
  Timer? _timer;
  int _battery = 76;
  bool _armed = false;

  Stream<Telemetry> get stream => _controller.stream;

  void start() {
    _timer ??= Timer.periodic(const Duration(seconds: 2), (_) {
      _battery = _battery > 15 ? _battery - 1 : 76;
      final now = DateTime.now();
      _controller.add(
        Telemetry(
          battery: _battery,
          satellites: 12 + (now.second % 4),
          connection: 82 + (now.second % 16),
          speed: _armed ? 4.2 : 0,
          heading: 84,
          armed: _armed,
          timestamp: now,
        ),
      );
    });
  }

  void setArmed(bool armed) {
    _armed = armed;
    final now = DateTime.now();
    _controller.add(
      Telemetry(
        battery: _battery,
        satellites: 14,
        connection: 90,
        speed: armed ? 4.2 : 0,
        heading: 84,
        armed: armed,
        timestamp: now,
      ),
    );
  }

  void dispose() {
    _timer?.cancel();
    _timer = null;
    _controller.close();
  }
}
