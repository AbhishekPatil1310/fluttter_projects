import 'dart:convert';
import 'dart:io';

import 'package:file_selector/file_selector.dart';

import '../../domain/models/waypoint.dart';

class FileService {
  Future<void> saveMission(List<Waypoint> waypoints) async {
    final location = await getSaveLocation(suggestedName: 'nomad_mission.json');
    if (location == null) return;
    final json = const JsonEncoder.withIndent('  ')
        .convert(waypoints.map((waypoint) => waypoint.toJson()).toList());
    await File(location.path).writeAsString(json);
  }

  Future<List<Waypoint>?> loadMission() async {
    final file = await openFile(
      acceptedTypeGroups: [   //a group for different file types, in this case we only want to accept json files
        XTypeGroup(label: 'Mission JSON', extensions: ['json']),  //a class that alow to filter the file type user can select
      ],
    );
    if (file == null) return null;
    final decoded = jsonDecode(await file.readAsString()) as List<dynamic>;
    return decoded
        .map((item) => Waypoint.fromJson(item as Map<String, dynamic>))
        .toList();
  }
}
