import '../../domain/models/alert.dart';

class AlertService {
  final List<Alert> _history = [];

  List<Alert> get history => List.unmodifiable(_history);

  void emit(String message, AlertLevel level) {
    _history.insert(
      0,
      Alert(message: message, level: level, timestamp: DateTime.now()),
    );
    if (_history.length > 10) _history.removeLast();
  }

  void acknowledge(int index) {
    if (index < 0 || index >= _history.length) return;
    _history[index] = _history[index].copyWith(acknowledged: true);
  }
}
