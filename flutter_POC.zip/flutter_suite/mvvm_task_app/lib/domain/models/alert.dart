enum AlertLevel { info, warning, critical, emergency }

class Alert {
  const Alert({
    required this.message,
    required this.level,
    required this.timestamp,
    this.acknowledged = false,
  });

  final String message;
  final AlertLevel level;
  final DateTime timestamp;
  final bool acknowledged;

  Alert copyWith({bool? acknowledged}) => Alert(
        message: message,
        level: level,
        timestamp: timestamp,
        acknowledged: acknowledged ?? this.acknowledged,
      );
}
