enum MissionLogType {
  waypointUpdated,
  missionSaved,
  missionLoaded,
}

class MissionLog {
  const MissionLog({
    required this.message,
    required this.type,
    required this.timestamp,
  });

  final String message;
  final MissionLogType type;
  final DateTime timestamp;
}