import 'package:latlong2/latlong.dart';

class Waypoint {
  const Waypoint({
    required this.position,
    this.altitude = 30,
    this.speed = 2,
  });

  final LatLng position;
  final double altitude;
  final double speed;

  Waypoint copyWith({LatLng? position, double? altitude, double? speed}) =>
      Waypoint(
        position: position ?? this.position,
        altitude: altitude ?? this.altitude,
        speed: speed ?? this.speed,
      );

  Map<String, dynamic> toJson() => {
        'lat': position.latitude,
        'lng': position.longitude,
        'altitude': altitude,
        'speed': speed,
      };

  factory Waypoint.fromJson(Map<String, dynamic> json) => Waypoint(
        position: LatLng(
          (json['lat'] as num).toDouble(),
          (json['lng'] as num).toDouble(),
        ),
        altitude: (json['altitude'] as num).toDouble(),
        speed: (json['speed'] as num).toDouble(),
      );
}
