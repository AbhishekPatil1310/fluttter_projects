class Telemetry {
  const Telemetry({
    required this.battery,
    required this.satellites,
    required this.connection,
    required this.speed,
    required this.heading,
    required this.armed,
    required this.timestamp,
  });

  final int battery;
  final int satellites;
  final int connection;
  final double speed;
  final int heading;
  final bool armed;
  final DateTime timestamp;
}
