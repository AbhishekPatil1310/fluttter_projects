# Day 6 Flutter Mission Planner

Independent Linux mission planner using `flutter_map`, `latlong2`, OpenStreetMap, and `file_selector`. Tap to add waypoints, tap a marker or list item to edit altitude and speed, reorder them, swipe to delete, save/load JSON files, view route lines, and see coordinate-based distance/time statistics.

Run with `flutter pub get` then `flutter run -d linux`. Build with `flutter build linux`.