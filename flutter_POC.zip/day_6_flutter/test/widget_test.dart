// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:flutter_test/flutter_test.dart';

import 'package:day_6_flutter/main.dart';

void main() {
  testWidgets('mission planner starts with an empty waypoint list', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const MyApp());

    expect(find.text('NOMAD / MISSION PLANNER'), findsOneWidget);
    expect(find.text('WAYPOINTS  0'), findsOneWidget);
    expect(find.text('Distance: 0.00 km'), findsOneWidget);
  });
}
