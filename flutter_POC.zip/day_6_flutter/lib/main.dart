import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:file_selector/file_selector.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

void main() => runApp(const MissionApp());

class Waypoint {
  Waypoint(this.position, {this.altitude = 30, this.speed = 2});
  LatLng position;
  double altitude;
  double speed;
  Map<String, dynamic> toJson() => {
    'lat': position.latitude,
    'lng': position.longitude,
    'altitude': altitude,
    'speed': speed,
  };
  factory Waypoint.fromJson(Map<String, dynamic> json) => Waypoint(
    LatLng(json['lat'] as double, json['lng'] as double),
    altitude: (json['altitude'] as num).toDouble(),
    speed: (json['speed'] as num).toDouble(),
  );
}

class MissionApp extends StatelessWidget {
  const MissionApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF54D1B0),
        brightness: Brightness.dark,
      ),
      scaffoldBackgroundColor: const Color(0xFF12191D),
    ),
    home: const MissionScreen(),
  );
}

class MyApp extends MissionApp {
  const MyApp({super.key});
}

class MissionScreen extends StatefulWidget {
  const MissionScreen({super.key});
  @override
  State<MissionScreen> createState() => _MissionScreenState();
}

class _MissionScreenState extends State<MissionScreen> {
  final mapController = MapController();
  final waypoints = <Waypoint>[];
  final center = const LatLng(18.0185,77.0108 );
  void add(LatLng point) => setState(() => waypoints.add(Waypoint(point)));
  String exportJson() =>
      const JsonEncoder.withIndent('  ')
          .convert(waypoints.map((waypoint) => waypoint.toJson()).toList());
  double get totalDistance {
    const distance = Distance();
    var total = 0.0;
    for (var index = 1; index < waypoints.length; index++) {
      total += distance.as(
        LengthUnit.Kilometer,
        waypoints[index - 1].position,
        waypoints[index].position,
      );
    }
    return total;
  }

  Future<void> saveMission() async {
    final location = await getSaveLocation(suggestedName: 'nomad_mission.json');
    if (location == null) return;
    await File(location.path).writeAsString(exportJson());
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Mission saved')));
    }
  }

  Future<void> loadMission() async {
    final file = await openFile(
      acceptedTypeGroups: [
        XTypeGroup(label: 'Mission JSON', extensions: ['json']),
      ],
    );
    if (file == null) return;
    try {
      final decoded = jsonDecode(await file.readAsString()) as List<dynamic>;
      final loaded = decoded
          .map((item) => Waypoint.fromJson(item as Map<String, dynamic>))
          .toList();
      if (mounted) {
        setState(() {
          waypoints
            ..clear()
            ..addAll(loaded);
        });
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('Invalid mission JSON')));
      }
    }
  }

  Future<void> editWaypoint(int index) async {
    final waypoint = waypoints[index];
    final altitude = TextEditingController(text: waypoint.altitude.toString());
    final speed = TextEditingController(text: waypoint.speed.toString());
    final updated = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('WAYPOINT ${index + 1}'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: altitude,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Altitude (m)'),
            ),
            TextField(
              controller: speed,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Speed (m/s)'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCEL'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('APPLY'),
          ),
        ],
      ),
    );
    if (updated == true) {
      setState(() {
        waypoint.altitude = double.tryParse(altitude.text) ?? waypoint.altitude;
        waypoint.speed = double.tryParse(speed.text) ?? waypoint.speed;
      });
    }
    altitude.dispose();
    speed.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('NOMAD / MISSION PLANNER'),
      actions: [
        IconButton(
          onPressed: saveMission,
          icon: const Icon(Icons.save_outlined),
          tooltip: 'Save mission',
        ),
        IconButton(
          onPressed: loadMission,
          icon: const Icon(Icons.folder_open),
          tooltip: 'Load mission',
        ),
      ],
    ),
    body: Row(
      children: [
        Expanded(
          child: FlutterMap(
            mapController: mapController,
            options: MapOptions(
              initialCenter: center,
              initialZoom: 13,
              onTap: (_, point) => add(point),
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.example.day_6_flutter',
              ),
              PolylineLayer(
                polylines: waypoints.length < 2
                    ? const <Polyline<Object>>[]
                    : [
                        Polyline(
                          points: waypoints
                              .map((waypoint) => waypoint.position)
                              .toList(),
                          color: Colors.orangeAccent,
                          strokeWidth: 3,
                        ),
                      ],
              ),
              MarkerLayer(
                markers: [
                  for (var i = 0; i < waypoints.length; i++)
                    Marker(
                      point: waypoints[i].position,
                      width: 42,
                      height: 42,
                      child: GestureDetector(
                        onTap: () => editWaypoint(i),
                        child: CircleAvatar(
                          backgroundColor: Colors.orangeAccent,
                          child: Text('${i + 1}'),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
        SizedBox(
          width: 300,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'WAYPOINTS  ${waypoints.length}',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
                const SizedBox(height: 10),
                Expanded(
                  child: ReorderableListView.builder(
                    itemCount: waypoints.length,
                    onReorderItem: (oldIndex, newIndex) => setState(() {
                      final item = waypoints.removeAt(oldIndex);
                      waypoints.insert(newIndex, item);
                    }),
                    itemBuilder: (_, index) => Dismissible(
                      key: ValueKey(waypoints[index]),
                      onDismissed: (_) =>
                          setState(() => waypoints.removeAt(index)),
                      child: ListTile(
                        onTap: () => editWaypoint(index),
                        leading: CircleAvatar(child: Text('${index + 1}')),
                        title: Text(
                          '${waypoints[index].position.latitude.toStringAsFixed(4)}, ${waypoints[index].position.longitude.toStringAsFixed(4)}',
                        ),
                        subtitle: Text(
                          'ALT ${waypoints[index].altitude}m  SPD ${waypoints[index].speed}m/s',
                        ),
                        trailing: const Icon(Icons.drag_handle),
                      ),
                    ),
                  ),
                ),
                const Divider(),
                Text('Distance: ${totalDistance.toStringAsFixed(2)} km'),
                Text(
                  'Est. time: ${(waypoints.length * 1.8).toStringAsFixed(1)} min',
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}
