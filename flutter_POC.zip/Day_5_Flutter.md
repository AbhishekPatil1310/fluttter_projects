# Day 5 – Alert System

## Task

The goal was to build an alert and notification system capable of providing visual and audio feedback based on the severity of an event.

The alert system needed four levels:

- Info
- Warning
- Critical
- Emergency

It also needed an alert history panel, timestamps, notifications, and audio feedback for critical events. fileciteturn0file4L5-L17

## How I Completed It

I created an `AlertService` and defined an `AlertLevel` enum with:

- `info`
- `warning`
- `critical`
- `emergency`

I also created an `Alert` model containing:

- ID
- Alert level
- Message
- Timestamp

I implemented an `AlertPanel` to display the latest ten alerts. Alerts were color-coded and displayed with icons and relative timestamps such as `"2 min ago"`.

For notification behavior, I used:

- `SnackBar` for informational and warning alerts
- `AlertDialog` for critical and emergency alerts requiring user acknowledgment

I integrated the `audioplayers` package and created an `assets/sounds/` directory for alert sounds. Critical alerts trigger audio feedback.

I tested the system using scenarios such as:

- Low battery progression
- GPS loss
- Connection loss
- Geofence breach

These requirements and scenarios are defined in the Day 5 task specification. fileciteturn0file4L9-L15

## What I Learned

- How to design a severity-based alert architecture.
- How enums can make alert levels consistent and easier to manage.
- How `SnackBar` and `AlertDialog` serve different notification purposes.
- How timestamps can make an alert history easier to understand.
- How to integrate audio feedback into a Flutter application.
- How visual and audio notifications can work together in a vehicle/ground-control interface.
- How critical events should require explicit acknowledgment while less important notifications can disappear automatically.
- How to test an alert system using realistic vehicle failure scenarios.
