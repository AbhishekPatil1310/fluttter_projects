import 'package:flutter/material.dart';

void main() => runApp(const FoundationApp());

class FoundationApp extends StatelessWidget {
  const FoundationApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'UGV Control Foundation',
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF14202B),
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF42D3A5), brightness: Brightness.dark),
          fontFamily: 'monospace',
          useMaterial3: true,
        ),
        home: const FoundationScreen(),
      );
}

class MyApp extends FoundationApp {
  const MyApp({super.key});
}

class FoundationScreen extends StatelessWidget {
  const FoundationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final modules = <(IconData, String, String)>[
      (Icons.dashboard_outlined, 'TELEMETRY', 'Live vehicle health and sensor data'),
      (Icons.route_outlined, 'NAVIGATION', 'Routes, missions, and waypoint control'),
      (Icons.notifications_none, 'ALERTS', 'Prioritized visual and audio warnings'),
      (Icons.map_outlined, 'MISSION PLANNING', 'Map-based field operations'),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('UGV / CONTROL FOUNDATION'),
        actions: const [Chip(avatar: Icon(Icons.circle, size: 10, color: Color(0xFF42D3A5)), label: Text('SYSTEM READY')), SizedBox(width: 20)],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1100),
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('FIELD OPERATIONS CONSOLE', style: Theme.of(context).textTheme.labelLarge?.copyWith(color: const Color(0xFF42D3A5), letterSpacing: 2)),
              const SizedBox(height: 10),
              Text('A modular foundation for EV / UGV control.', style: Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Text('Day 1 establishes the product architecture: each operational concern has a clear home and can evolve independently.', style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Colors.white70)),
              const SizedBox(height: 36),
              Expanded(
                child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 360, mainAxisExtent: 170, crossAxisSpacing: 16, mainAxisSpacing: 16),
                  itemCount: modules.length,
                  itemBuilder: (context, index) => Card(
                    color: const Color(0xFF1D2D39),
                    child: Padding(
                      padding: const EdgeInsets.all(22),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Icon(modules[index].$1, color: const Color(0xFF42D3A5), size: 30),
                        const Spacer(),
                        Text(modules[index].$2, style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                        const SizedBox(height: 6),
                        Text(modules[index].$3, style: const TextStyle(color: Colors.white60)),
                      ]),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              const Row(children: [Icon(Icons.info_outline, size: 16, color: Colors.white54), SizedBox(width: 8), Text('LINUX DESKTOP TARGET  /  MODULAR BY DESIGN', style: TextStyle(color: Colors.white54, fontSize: 12, letterSpacing: 1))]),
            ]),
          ),
        ),
      ),
    );
  }
}
