# Day 1 Flutter Foundation

Independent Linux Flutter app establishing the EV/UGV ground-control architecture and its core modules: telemetry, navigation, alerts, and mission planning.

Run with `flutter pub get` then `flutter run -d linux`. Build with `flutter build linux`. Uses Flutter/Dart and Material 3 only.