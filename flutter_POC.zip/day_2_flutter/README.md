# Day 2 Flutter Dashboard

Independent responsive Linux dashboard with top status, controls, map placeholder, telemetry, battery, GPS, and connection indicators. Desktop uses four regions; narrow layouts stack the panels.

Run with `flutter pub get` then `flutter run -d linux`. Build with `flutter build linux`. Uses Flutter/Dart and Material 3 only.